#!/usr/bin/env python3
"""Checks the footer mascot's cap set: 5 frames x 2 tiers, one export profile, one registration, one brim edge.

Usage: python3 scripts/mascot/verify_caps.py   (needs numpy, pillow). Exits 1 on any failure.

The cap is a layer of its own from mascot frame 02 on (see src/lib/mascotScrub.ts). Three numbers in that file are
measurements of the artwork, not choices, and this script re-derives all three from the files that ship:

  CAP_SEAT  where the cap sits when it is on his head — its top edge, in cap px, above the top edge of the frame
            crop — checked against mascot frame 01, which wears the cap in the artwork. Lift 0 has to *be* that pose:
            it is the whole handoff from frame 01 to frame 02.
  CAP_EDGE  the brim's lower edge per cap frame: above it the crown and the brim, below it the interior lining, which
            has to pass behind his head while the cap is still on it, or the handoff reads as a cap printed over a
            face.
  CAP_SIZE  the stills are square and share the frame crop's pixel scale, so one cap px is one frame px.
"""
import pathlib
import re
import sys

import numpy as np
from PIL import Image

root = pathlib.Path(__file__).resolve().parents[2]
CAP_D = root / 'public/mascot/cap'
FRAME_D = root / 'public/mascot/frames'
SRC = (root / 'src/lib/mascotScrub.ts').read_text()
SIZES = {1280: (1280, 1280), 800: (800, 800)}
fails = []


def check(ok, msg):
    print(('PASS ' if ok else 'FAIL ') + msg)
    ok or fails.append(msg)


def const(name):
    m = re.search(rf'export const {name} = ([-\d.]+)', SRC)
    return int(float(m.group(1))) if m else None


def qidx(path):  # VP8 y_ac_qi, straight out of the bitstream header
    d = path.read_bytes()
    i = d.index(b'VP8 ') + 8 + 10
    v = (d[i] << 8) | d[i + 1]
    p = i + 2
    r = 255
    bits = 0

    def rb():
        nonlocal v, r, bits, p
        sp = 1 + (((r - 1) * 128) >> 8)
        big = sp << 8
        if v >= big:
            b = 1
            r -= sp
            v -= big
        else:
            b = 0
            r = sp
        while r < 128:
            r <<= 1
            v <<= 1
            bits += 1
            if bits == 8:
                bits = 0
                v |= d[p] if p < len(d) else 0
                p += 1
        return b

    def lit(n):
        return sum(rb() << (n - 1 - k) for k in range(n))

    rb()
    rb()
    if rb():
        um = rb()
        ud = rb()
        if ud:
            rb()
            for _ in range(4):
                if rb():
                    lit(7)
                    rb()
            for _ in range(4):
                if rb():
                    lit(6)
                    rb()
        if um:
            for _ in range(3):
                if rb():
                    lit(8)
    rb()
    lit(6)
    lit(3)
    if rb() and rb():
        for _ in range(8):
            if rb():
                lit(6)
                rb()
    lit(2)
    return lit(7)


def load(i, t=1280):
    return np.array(Image.open(CAP_D / f'nemo-cap-{i}-{t}.webp').convert('RGBA'))


def white(a):
    """the near-neutral bright pixels: the brim, and the logo patch. The crown, the hoodie and the lining are not."""
    return (a[..., 3] > 150) & (a[..., :3].min(axis=2) > 175)


ids = re.findall(r"'(\d\d)'", re.search(r'CAP_IDS = \[(.*?)\]', SRC).group(1))
SHIPPED = [int(round(float(v))) for v in re.findall(r'[-\d.]+', re.search(r'CAP_EDGE = \[(.*?)\]', SRC).group(1))]
SEAT = const('CAP_SEAT')

# --------------------------------------------------------------------------- files, tiers, export profile
check(ids == [f'{i:02d}' for i in range(1, 6)], f'CAP_IDS = {ids}')
check(const('CAP_SIZE') == 2048, f"CAP_SIZE = {const('CAP_SIZE')}")
check(len(SHIPPED) == 5, f'shipped CAP_EDGE = {SHIPPED}')
for t, (w, h) in SIZES.items():
    for i in ids:
        f = CAP_D / f'nemo-cap-{i}-{t}.webp'
        if not check(f.exists(), f'{f.name} exists'):
            continue
        check(Image.open(f).size == (w, h), f'{f.name} is {w}x{h}')
        d = f.read_bytes()
        check(qidx(f) == 21 and b'ALPH' in d[:64], f'{f.name} export profile (VP8 q-index 21, alpha plane)')

# --------------------------------------------------------------------------- each still is whole
for i in ids:
    al = load(i)[..., 3]
    ys, xs = np.nonzero(al > 24)
    pad = min(ys.min(), xs.min(), al.shape[0] - 1 - ys.max(), al.shape[1] - 1 - xs.max())
    check(pad >= 8, f'cap {i}: subject clear of every edge (min padding {pad}px)')

# --------------------------------------------------------------------------- one cap, one scale
areas = [int((load(i)[..., 3] > 24).sum()) for i in ids]
spread = (max(areas) - min(areas)) / max(areas)
check(spread < 0.12, f'the five stills are the same cap at the same scale (area spread {spread * 100:.1f}%)')

# --------------------------------------------------------------------------- CAP_EDGE, re-measured
# The brim's lower edge: the deepest bright brim pixel over the columns his head covers (600..1450 of 2048 — outside
# them the mascot is transparent, so the split only has to clear the brim where his head can cover it), + 3px so the
# split never eats a sliver of white.
for i in ids:
    a = load(i)
    scale = 2048 / a.shape[1]  # the constants live in the 2048 registration space, the files ship at 1280
    m = white(a)
    x0, x1 = int(600 / 2048 * a.shape[1]), int(1450 / 2048 * a.shape[1])
    rows = np.array([np.nonzero(m[:, x])[0].max() for x in range(x0, x1, 4) if m[:, x].any()], float)
    measured = int(round(rows.max() * scale)) + 3
    want = SHIPPED[int(i) - 1]
    check(abs(measured - want) <= 8, f'cap {i}: brim edge measured {measured}, shipped {want}')

# --------------------------------------------------------------------------- CAP_SEAT, re-measured
poster_path = FRAME_D / 'nemo-01-1280.webp'
if not poster_path.exists():
    print('SKIP the registration check: public/mascot/frames is not in this checkout')
else:
    f01 = np.array(Image.open(poster_path).convert('RGBA'))
    c01 = load('01')
    seat = int(round(SEAT * c01.shape[1] / 2048))  # into the shipped 1280 scale
    fw, cw = white(f01), white(c01)

    def slip(s):
        """per column: how far the cap's first bright edge sits from frame 01's, with the cap seated at `s`"""
        d = []
        for x in range(0, cw.shape[1], 4):
            cap_y = np.nonzero(cw[:, x])[0]
            frm_y = np.nonzero(fw[:, x])[0]
            if len(cap_y) and len(frm_y):
                d.append((cap_y.min() - s) - frm_y.min())
        return np.array(d, float)

    d = slip(seat)
    med = float(np.median(d))
    mad = float(np.median(np.abs(d - med)))
    check(len(d) > 150, f'{len(d)} columns compared against frame 01')
    check(abs(med) <= 1.5, f'the seated cap lines up with the cap frame 01 wears: median slip {med:+.1f}px')
    check(mad <= 3, f'  consistent across the brim: MAD {mad:.1f}px')
    for off in (-12, -6, 6, 12):
        check(abs(float(np.median(slip(seat + off)))) > abs(med), f'  a {off:+d}px slip is worse — the fit has a peak')

print('\nALL CHECKS PASSED' if not fails else f'\n{len(fails)} CHECK(S) FAILED')
sys.exit(1 if fails else 0)
