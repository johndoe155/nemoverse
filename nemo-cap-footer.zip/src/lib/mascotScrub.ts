/**
 * Scroll-scrubbed stop-motion for the footer mascot (see components/FooterMascot.tsx).
 *
 * Everything here is framework-free and has no side effects on import: the mapping from scroll progress to a pose and
 * a camera (pure functions), the canvas painter, and the frame loader.
 *
 * Why a canvas and not eight stacked <img>s: the camera push-in scales the artwork by up to ZOOM_MAX. A canvas
 * repaints the bitmap at the zoomed size every time, so the face stays razor sharp at any zoom and any pixel ratio,
 * where a scaled DOM layer is either re-rasterised every frame or (with will-change) left blurry. A single canvas
 * also cannot cross-fade, flicker or show a half-decoded frame: a paint is "this decoded bitmap, at this scale", or
 * nothing changes at all. His cap rides in the same canvas for the same reason, and because it has to be *inside* the
 * scene: its underside goes behind his head while it still sits on it, and comes out in front of it once it has
 * cleared his crown (see paintFrame).
 */

/** Frame names, in playback order (01 is the first frame, 08 the last). 01 is the original static footer mascot. */
export const FRAME_IDS = ['01', '02', '03', '04', '05', '06', '07', '08'] as const;
export const FRAME_COUNT = FRAME_IDS.length;

/**
 * The two rendition widths in /public/mascot/frames, and the height / width of every frame. All eight frames share
 * one crop (the union of their subjects plus a little air above the highest bare crown), so the box never changes.
 * Frame 01 sits in that same crop, registered to 02 on the eye line (see scripts/mascot), so 01 -> 02 changes the cap and
 * nothing else: not a pixel of the face, the hoodie or the cords moves.
 */
export const FRAME_WIDTHS = { sm: 800, lg: 1280 } as const;
export type FrameTier = keyof typeof FRAME_WIDTHS;
export const FRAME_ASPECT = 1808 / 2048; // 0.8828. Mirrors --fm-ar in globals.css.
export const frameUrl = (id: string, tier: FrameTier) => `/mascot/frames/nemo-${id}-${FRAME_WIDTHS[tier]}.webp`;

/* ----------------------------------------------------------------------------------------------------------------
   His cap: five stills of the same cap, square 2048 x 2048, cut out of the same shoot at the same pixel scale as the
   mascot frames and cropped in that same space, so a cap frame drawn at zero lift is the cap *on his head* to the
   pixel (that registration is the whole handoff: frame 01 wears the cap in the artwork, frame 02 is the first bare
   head and gets cap frame 01 dropped straight onto it).
   ---------------------------------------------------------------------------------------------------------------- */

export const CAP_IDS = ['01', '02', '03', '04', '05'] as const;
export const CAP_COUNT = CAP_IDS.length;
export const capUrl = (id: string, tier: FrameTier) => `/mascot/cap/nemo-cap-${id}-${FRAME_WIDTHS[tier]}.webp`;

/** The cap stills are square and share the artwork's pixel scale: 2048 cap px = 2048 frame px. */
export const CAP_SIZE = 2048;
/**
 * Where the cap sits when it is on his head: its top edge, in cap px, above the top edge of the frame crop. Measured
 * off frame 01 (scripts/mascot/verify_caps.py re-checks it against the eight mascot frames), so `lift = 0` is exactly
 * the seated cap and every lifted position is a straight translation of that.
 */
export const CAP_SEAT = 240;
/**
 * The brim's lower edge, per cap frame, in cap px: the deepest bright pixel of the brim over the columns his head
 * covers, +3. Above the line are the crown and the brim, below it the cap's *interior* (the dark lining you only see
 * once the cap is off a head). paintFrame needs the two apart, because the interior has to pass behind him while the
 * cap is still on: that is what makes the handoff read as a cap sitting on a head rather than a cap printed over a
 * face. Split any higher and his head eats a sliver of the brim; any lower and a sliver of the lining lies on his
 * face. Three pixels of lining is the brim's shadow, which is the right place to err.
 * (scripts/mascot/verify_caps.py re-measures it.)
 */
export const CAP_EDGE = [913, 931, 933, 909, 904] as const;
/** The cap's centre of area, as a fraction of its square: it tips about there, so a tilt never slides it sideways. */
const CAP_PIVOT = { x: 1026 / CAP_SIZE, y: 623 / CAP_SIZE };
/** The cap's highest bare crown (frame 08's), as a fraction of the frame height: the gap opens above this line. */
const CROWN_TOP = 93 / 1808;

/* ----------------------------------------------------------------------------------------------------------------
   The choreography, in progress space.
   ---------------------------------------------------------------------------------------------------------------- */

/** Progress at which frame 02 — the first bare head — lands, and cap frame 01 takes over from the artwork's cap. */
const GROUND = 1 / FRAME_COUNT;
/**
 * The cap's five stills across frames 02-08. Deliberately not on the mascot's eighths: the cap is a loose object with
 * its own momentum, so it re-strikes off the beat, and the beats grow further apart as it slows down (0.137, 0.156,
 * 0.167, 0.167 of the range). Cap frame 01 lands on 02 and holds while it unsticks; frame 05 settles in at 0.752 and
 * rides out the last quarter as the still, hovering pose.
 */
const POSE_AT: ReadonlyArray<number> = [GROUND, 0.262, 0.418, 0.585, 0.752];
/** Cap px it is pulled up over the whole scrub, and how far it drifts into his eyeline (he looks up and to the right). */
const CAP_LIFT = 770;
const CAP_DRIFT = 16;
/** Peak tilt of the sway, in degrees. Small: the stills already carry their own tilt, this is the wobble on top. */
const CAP_SWAY = 1.4;

/* ----------------------------------------------------------------------------------------------------------------
   The camera. A push-in plus a tilt, both pure functions of progress, so reverse scroll replays them exactly.
   The push-in is gentler than the one the mascot had on his own (1.4): the shot has two subjects now, and the cap has
   to stay legible while the gap under it opens. The tilt is what makes the reveal possible at all — the shared crop
   has no room above his crown for a lifted cap, so the camera has to ride down (the artwork is drawn lower in the
   window) as the cap climbs. The aim point — the piece of artwork that sits at CAM_AIM of the window — travels from
   just above his crown down to the middle of the open gap, and it is pinned to the same fraction of the window at
   every zoom, so the framing is intentional at any progress and identical on the way back up.
   ---------------------------------------------------------------------------------------------------------------- */

/** Zoom at progress 1. */
export const ZOOM_MAX = 1.18;
/** Where the aim point sits vertically in the window, as a fraction of its height. */
const CAM_AIM = 0.26;
/** The gap's centre at progress 1, as a fraction of the frame height: between his crown and the lifted brim. */
const GAP_CENTRE = (CROWN_TOP + (CAP_EDGE[CAP_COUNT - 1] - CAP_SEAT - CAP_LIFT) / 1808) / 2;

const clamp01 = (v: number) => (v < 0 ? 0 : v > 1 ? 1 : v);
const smoothstep = (a: number, b: number, x: number) => {
  const t = clamp01((x - a) / (b - a));
  return t * t * (3 - 2 * t);
};
/** Sine in-out: no hard start or stop, the push-in eases on and settles off. */
const easeInOutSine = (p: number) => 0.5 - 0.5 * Math.cos(Math.PI * clamp01(p));
/** 0 before the ground, 0..1 across the rest of the scrub. */
const travel = (progress: number) => clamp01((progress - GROUND) / (1 - GROUND));

/**
 * Frame for a progress value. A pure function of progress, on purpose: the same scroll position always shows the
 * same frame, forward or in reverse, with no hysteresis or memory. Each frame owns an equal 1/8 of the range, and
 * progress 1 lands on the last frame.
 */
export function frameIndexAt(progress: number): number {
  return Math.min(FRAME_COUNT - 1, Math.floor(clamp01(progress) * FRAME_COUNT));
}

/**
 * Cap still for a progress value, or -1 while he is still wearing it (frame 01 carries the cap in the artwork itself).
 * A pose, never a blend: a cap caught between two stills would read as a smeared duplicate of itself.
 */
export function capIndexAt(progress: number): number {
  if (progress < GROUND) return -1;
  let i = 0;
  for (let k = 0; k < POSE_AT.length; k++) if (progress >= POSE_AT[k]) i = k;
  return i;
}

/**
 * How far the cap has been pulled up, in cap px. A decelerating rise — pulled, then coasting, then hanging — with a
 * short ease-on so it does not jerk off his head the instant frame 02 lands.
 */
export function capLiftAt(progress: number): number {
  const u = travel(progress);
  return CAP_LIFT * (1 - Math.pow(1 - u, 2.2)) * smoothstep(0, 0.075, u);
}

/** Its tilt, in degrees: a slow wobble that starts at exactly 0 on his head and never quite stops. */
export function capRotateAt(progress: number): number {
  const u = travel(progress);
  return CAP_SWAY * Math.sin(2 * Math.PI * 0.8 * u) * (0.35 + 0.65 * u);
}

/** Its sideways drift, in cap px: a couple of millimetres of lean into his eyeline. */
export function capDriftAt(progress: number): number {
  return CAP_DRIFT * (1 - Math.cos(Math.PI * travel(progress))) * 0.5;
}

/**
 * Camera zoom for a progress value. It only starts once the cap is off (at the ground, 1/8): under it — the beat where
 * he just stands there with the cap on — the camera is exactly neutral, so the canvas is a pixel-for-pixel twin of the
 * poster <img> and the handover between them cannot be caught. It also keeps the tilt below strictly one-way: both
 * halves of the camera are driven by the same eased travel, so the artwork only ever descends in the window.
 */
export function zoomAt(progress: number): number {
  return 1 + (ZOOM_MAX - 1) * easeInOutSine(travel(progress));
}

/**
 * The camera, as the two numbers the painter needs: how far in it is, and which slice of the artwork it is looking
 * at. `top` is the artwork row at the top of the window, as a fraction of the frame height (0 = the poster's own
 * framing, negative = the camera has tilted down past the top of the crop, which is where the cap gets its headroom).
 */
export type Camera = { zoom: number; top: number };

export function cameraAt(progress: number): Camera {
  const zoom = zoomAt(progress);
  const aim = CAM_AIM + (GAP_CENTRE - CAM_AIM) * easeInOutSine(travel(progress));
  return { zoom, top: aim - CAM_AIM / zoom };
}

/** Which rendition a canvas of this backing width needs: the sharpest zoom it can reach must not outgrow the file. */
export function tierFor(backingWidth: number): FrameTier {
  return backingWidth * ZOOM_MAX <= FRAME_WIDTHS.sm ? 'sm' : 'lg';
}

/* ----------------------------------------------------------------------------------------------------------------
   The painter.
   ---------------------------------------------------------------------------------------------------------------- */

export type Frame = ImageBitmap | HTMLImageElement;

/**
 * One pose of the cap: the bitmap, the brim edge that belongs to it, and the three numbers the choreography above
 * produced for this progress value.
 */
export type CapPose = { frame: Frame; edge: number; lift: number; rotate: number; drift: number };

/**
 * The photo's own lower crop (a hard edge through the hoodie) is dissolved into the footer: alpha of the mask by the
 * fraction of the frame height. Same stops as the stylesheet's .fm-poster, so poster and canvas are identical. It is
 * painted once, over the finished scene, so his cap leaves through the same hem (and through the same window mask)
 * as he does: one treatment, two layers, no way for them to disagree.
 */
const HEM_STOPS: ReadonlyArray<readonly [number, number]> = [
  [0, 1],
  [0.58, 1],
  [0.68, 0.86],
  [0.78, 0.58],
  [0.89, 0.26],
  [1, 0],
];

/**
 * Paint the scene — him, and his cap if it is off — into a canvas whose backing store is `w` x `h` px.
 *
 * The cap is drawn in two passes, split along the brim's lower edge (CAP_EDGE): the interior first, so his head
 * covers it exactly where it would in the room, then the crown and the brim over him. It is one bitmap drawn twice,
 * so the two halves are pixel-identical to a single draw and cannot drift, seam or double-expose; the only thing the
 * split changes is what the head is allowed to cover. As the cap climbs, its interior rises out from behind his crown
 * on its own — no fade, no mask animation, just the occlusion resolving.
 */
export function paintFrame(
  ctx: CanvasRenderingContext2D,
  frame: Frame,
  cap: CapPose | null,
  w: number,
  h: number,
  camera: Camera,
) {
  const { zoom, top } = camera;
  const dw = w * zoom; // the artwork, zoomed
  const dh = h * zoom;
  const dx = (w - dw) / 2; // the push-in is on the centre line...
  const dy = -top * dh; // ...and `top` rows above the crop's top edge

  ctx.globalCompositeOperation = 'source-over';
  ctx.clearRect(0, 0, w, h);
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';

  // The cap shares the artwork's scale: 1 cap px = dw / CAP_SIZE canvas px, and its square is dw wide.
  const s = dw / CAP_SIZE;
  const capX = cap ? dx + cap.drift * s : 0;
  const capY = cap ? dy + (-CAP_SEAT - cap.lift) * s : 0;
  const capSplit = cap ? capY + cap.edge * s : 0;
  if (cap) {
    ctx.save();
    // Tip it about its centre of area, then clip in the same (tipped) space so the split stays on the brim.
    const pivotX = dx + CAP_PIVOT.x * dw;
    const pivotY = capY + CAP_PIVOT.y * dw;
    ctx.translate(pivotX, pivotY);
    ctx.rotate((cap.rotate * Math.PI) / 180);
    ctx.translate(-pivotX, -pivotY);
    // 1. the interior, behind him
    ctx.save();
    ctx.beginPath();
    ctx.rect(dx, capSplit, dw, dw);
    ctx.clip();
    ctx.drawImage(cap.frame, capX, capY, dw, dw);
    ctx.restore();
  }

  // 2. him
  ctx.drawImage(frame, dx, dy, dw, dh);

  if (cap) {
    // 3. the crown and the brim, in front of him
    ctx.beginPath();
    ctx.rect(dx, capY, dw, Math.max(0, capSplit - capY));
    ctx.clip();
    ctx.drawImage(cap.frame, capX, capY, dw, dw);
    ctx.restore();
  }

  // 4. the hem, over the whole scene (see HEM_STOPS)
  const g = ctx.createLinearGradient(0, dy, 0, dy + dh);
  for (const [at, alpha] of HEM_STOPS) g.addColorStop(at, `rgba(0,0,0,${1 - alpha})`);
  ctx.globalCompositeOperation = 'destination-out';
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, w, h);
  ctx.globalCompositeOperation = 'source-over';
}

/* ----------------------------------------------------------------------------------------------------------------
   The loader.
   ---------------------------------------------------------------------------------------------------------------- */

/**
 * Loads and keeps a bank of frames. Frames are decoded into ImageBitmaps where the browser can (a bitmap stays
 * decoded, where an <img>'s decoded pixels can be evicted under memory pressure and re-decoded in the middle of a
 * paint). `pick` never returns nothing once any frame is ready: it falls back to the nearest ready frame, so a fast
 * scroll over frames that are still arriving shows the closest pose instead of a blank.
 */
export class FrameBank {
  private sets: Record<FrameTier, Array<Frame | null>> = {
    sm: new Array<Frame | null>(this.ids.length).fill(null),
    lg: new Array<Frame | null>(this.ids.length).fill(null),
  };
  private started: Record<FrameTier, boolean> = { sm: false, lg: false };
  private disposed = false;

  constructor(
    private readonly ids: readonly string[],
    private readonly url: (id: string, tier: FrameTier) => string,
    private onFrame: () => void,
  ) {}

  /** Start loading a tier (once). In playback order, so frame 01 (the poster's twin) is the first to land. */
  load(tier: FrameTier) {
    if (this.started[tier] || this.disposed) return;
    this.started[tier] = true;
    this.ids.forEach((id, i) => {
      void this.fetchOne(tier, id, i);
    });
  }

  private async fetchOne(tier: FrameTier, id: string, i: number) {
    const img = new Image();
    img.decoding = 'async';
    img.src = this.url(id, tier);
    try {
      await img.decode();
    } catch {
      // decode() can reject for a frame that is fine (or on browsers that do not implement it): fall back to onload.
      const ok = await new Promise<boolean>((resolve) => {
        if (img.complete && img.naturalWidth > 0) resolve(true);
        else {
          img.onload = () => resolve(true);
          img.onerror = () => resolve(false);
        }
      });
      if (!ok) return;
    }
    let frame: Frame = img;
    if (typeof createImageBitmap === 'function') {
      try {
        frame = await createImageBitmap(img);
      } catch {
        frame = img;
      }
    }
    if (this.disposed) {
      if ('close' in frame) frame.close();
      return;
    }
    this.sets[tier][i] = frame;
    this.onFrame();
  }

  /** The best available frame for index `i`: the wanted tier first, then the other, nearest index first. */
  pick(i: number, tier: FrameTier): Frame | null {
    const other: FrameTier = tier === 'sm' ? 'lg' : 'sm';
    for (const t of [tier, other]) {
      const set = this.sets[t];
      if (set[i]) return set[i];
    }
    for (let d = 1; d < this.ids.length; d++) {
      for (const t of [tier, other]) {
        const set = this.sets[t];
        const lo = set[i - d];
        if (lo) return lo;
        const hi = set[i + d];
        if (hi) return hi;
      }
    }
    return null;
  }

  /** True when frame `i` itself (not a stand-in) is decoded, in either tier. */
  ready(i: number) {
    return Boolean(this.sets.sm[i] || this.sets.lg[i]);
  }

  /** True once every frame of the tier is decoded. */
  complete(tier: FrameTier) {
    return this.sets[tier].every(Boolean);
  }

  dispose() {
    this.disposed = true;
    for (const t of ['sm', 'lg'] as const) {
      this.sets[t].forEach((f) => {
        if (f && 'close' in f) f.close();
      });
      this.sets[t].fill(null);
    }
  }
}
