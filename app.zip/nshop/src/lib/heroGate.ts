'use client';
import { useLayoutEffect } from 'react';

/**
 * Hero gate for the adaptive sticky elements (N tile + "Start Forging").
 *
 * Sets `data-past-hero` on <html> ONLY once the hero section has fully scrolled clear of the sticky elements,
 * i.e. no part of the hero is behind them any more. globals.css keys the whole inversion off that attribute:
 *   - attribute absent  -> pristine baseline brand colours, `mix-blend-mode: normal` (nothing is blended or composited
 *                          differently, so there is nothing to sample, mask or pay for while the hero is on screen)
 *   - attribute present -> `mix-blend-mode: difference` (compositor-side, per-pixel, zero JS)
 *
 * Cost model: layout is measured ONCE (and again on resize / hero resize). The scroll handler is a passive listener that
 * compares `window.scrollY` against a cached number and touches the DOM only on the frame the boundary is crossed.
 * No React state, no IntersectionObserver latency, no layout reads while scrolling. Because the listener runs in the same
 * frame as the scroll that crosses the boundary, the attribute and the scroll position can never be out of sync.
 *
 * SSR / first paint / no hero found: attribute absent, i.e. baseline. Always the safe state.
 */
const ATTR = 'data-past-hero';

export function useHeroGate(heroSelector = '[data-hero]', stickySelector = '.tone-blend') {
  useLayoutEffect(() => {
    const root = document.documentElement;
    const hero = document.querySelector<HTMLElement>(heroSelector);
    if (!hero) {
      root.removeAttribute(ATTR);
      return;
    }

    let gateY = Infinity; // scrollY at which the hero's bottom edge reaches the top edge of the sticky elements
    let past = false;

    const apply = () => {
      const next = window.scrollY >= gateY;
      if (next === past) return; // early return: nothing to do on 99.9% of scroll events
      past = next;
      root.toggleAttribute(ATTR, next);
    };

    const measure = () => {
      let stickyTop = Infinity;
      document.querySelectorAll<HTMLElement>(stickySelector).forEach((el) => {
        stickyTop = Math.min(stickyTop, el.getBoundingClientRect().top);
      });
      if (!isFinite(stickyTop)) stickyTop = 0;
      const heroBottomDoc = hero.getBoundingClientRect().bottom + window.scrollY;
      gateY = heroBottomDoc - stickyTop;
      apply();
    };

    measure();
    window.addEventListener('scroll', apply, { passive: true });
    window.addEventListener('resize', measure, { passive: true });
    window.addEventListener('load', measure);
    const ro = new ResizeObserver(measure);
    ro.observe(hero);

    return () => {
      window.removeEventListener('scroll', apply);
      window.removeEventListener('resize', measure);
      window.removeEventListener('load', measure);
      ro.disconnect();
      root.removeAttribute(ATTR);
    };
  }, [heroSelector, stickySelector]);
}
