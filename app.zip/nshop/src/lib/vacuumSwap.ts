/**
 * "Vacuum" swap engine for the hero price marquee.
 *
 * The marquee is a static, centred row of fixed-size slots. Every so often ONE slot's item is sucked out of
 * the slot vertically (accelerating, stretched along the travel axis) while its replacement is pulled in from
 * the opposite edge, continuing the same direction of travel - like items riding a pneumatic tube through a
 * window. Direction alternates organically; the cadence is staggered so the row is never busy all at once.
 *
 * Performance model
 *   - Only `transform` is animated, via the Web Animations API, so the browser runs it on the compositor
 *     thread: no per-frame JS, no style recalc, no layout, no paint. JS wakes up only to START a swap
 *     (one `animate()` pair) and when it FINISHES.
 *   - No layout reads (`getBoundingClientRect`, `offsetWidth`, ...) anywhere. Slots are fixed-size and
 *     `contain: strict`, so even the text write on the incoming cell cannot invalidate anything outside it.
 *   - Compositor layers are short-lived: `will-change: transform` (via `[data-fly]` in globals.css) exists only
 *     while a slot is flying. At rest the row is plain static text and the idle cell is `visibility: hidden`.
 *   - ONE timer in flight at any time. It is cleared on dispose and whenever the marquee is paused: tab hidden,
 *     hero scrolled out of view (IntersectionObserver), or a mouse hovering the row.
 *   - `prefers-reduced-motion`: no movement at all, items are swapped in place at a slow cadence.
 *
 * Bullet drag
 *   Each orange bullet between two slots is dragged a few px toward the direction of any neighbouring pull. The
 *   drag animation is created in the same task as the pull it belongs to, with the same delay, and its first
 *   segment has the pull's exact duration and easing, so both start on the same compositor frame and follow
 *   the same curve: the bullet is displaced in lock-step with the item, coasts a little further on its own
 *   momentum once the item has left (speeds are matched at the hand-off, so no kink) and eases back. Every bullet is TWO nested elements, one driven by its left neighbour and one by its right, so
 *   any combination of pulls simply composes through the DOM (translations add, stretches multiply) without
 *   per-frame JS and without `composite: 'add'` support:
 *     - one neighbour pulled            -> bullet follows it
 *     - both pulled the same way        -> bullet is dragged twice as far
 *     - both pulled in opposite ways    -> offsets cancel and the bullet is stretched between them
 *     - staggered / overlapping pulls   -> each contributes on its own timeline, whatever the overlap
 *
 * Highlight guarantee: an item can only leave once it has been fully settled for MIN_DWELL ms.
 *
 * Timing director (what makes the pulling feel random rather than clockwork)
 *   - Every slot owns its own clock (`dueAt`). After each swap the slot draws its next interval from a
 *     three-way mixture (eager / typical / long rest), so slots drift apart instead of ticking in step.
 *   - ONE timer still drives everything: it sleeps until the earliest `dueAt`.
 *   - When a slot comes due it may recruit a partner in a "motif", each with its own stagger and direction:
 *     chase (same way, a beat later), counter (opposite way, a beat later), echo (a long lag, overlapping the
 *     tail of the first pull) and snap (same frame - deliberately rare). Most events are plain solos.
 *     A pity timer raises the odds of a motif after a run of solos; a cooldown stops motifs repeating
 *     back-to-back, so no pattern can be learnt.
 *   - Slots that come due at the same moment are never allowed to fire together by accident: the extra
 *     slot is pushed back by a random amount unless it was deliberately recruited.
 *   - Every pull gets its own tempo (all durations scale together, so the bullet hand-off maths still
 *     holds) and a matching yank strength: quick pulls tug the bullet harder, lazy ones barely move it.
 */

// ── Pacing ──────────────────────────────────────────────────────────────────────────────────────────────
const MIN_DWELL = 3200; // ms an item sits fully settled before it may be swapped out
const REDUCED_GAP_MIN = 3500;
const REDUCED_GAP_MAX = 5200;
const INITIAL_DELAY = 2600; // let the hero intro play before anything moves
const RESUME_DELAY = 450;
const MIN_WAKE = 60; // never spin the timer faster than this

/** Per-slot rest AFTER the dwell, drawn from a mixture so intervals are bursty, not metronomic: [weight, min, max]. */
const REST_MIX: ReadonlyArray<readonly [number, number, number]> = [
  [0.3, 0, 700], // eager: leaves the moment it is allowed to
  [0.45, 700, 3200], // typical
  [0.25, 3200, 7000], // long rest
];
const DEFER_MIN = 700; // an accidentally co-due slot is pushed back by at least this ...
const DEFER_MAX = 2800; // ... and at most this
const OVERDUE_GRACE = 40; // a slot this close to due counts as due

/** Motifs: how a second slot joins the lead. `gap` is the stagger range in ms, `dir` how its direction relates. */
type Motif = 'chase' | 'counter' | 'echo' | 'snap';
const MOTIFS: ReadonlyArray<{ id: Motif; weight: number; gap: readonly [number, number]; dir: 'same' | 'opposite' | 'any' }> = [
  { id: 'chase', weight: 0.3, gap: [90, 380], dir: 'same' },
  { id: 'counter', weight: 0.26, gap: [60, 270], dir: 'opposite' },
  { id: 'echo', weight: 0.31, gap: [520, 1150], dir: 'any' },
  { id: 'snap', weight: 0.13, gap: [0, 0], dir: 'any' },
];
const MOTIF_BASE_CHANCE = 0.28; // chance that a due slot recruits a partner
const MOTIF_PITY_STEP = 0.14; // added per consecutive solo
const MOTIF_PITY_MAX = 3;

/** Every pull is slightly different: all its durations scale by one tempo factor. */
const TEMPO_MIN = 0.82;
const TEMPO_MAX = 1.3;
const STRENGTH_GAIN = 0.9; // quicker pull (tempo < 1) -> harder bullet tug

// ── Motion ──────────────────────────────────────────────────────────────────────────────────────────────
const EXIT_MS = 280;
const ENTER_MS = 440;
/** Replacement starts while the old item is still gathering speed, so the slot is never "empty". */
const ENTER_DELAY = 170;
/** Travel in cell heights; with STRETCH it is enough to clear a 1-cell window completely. */
const TRAVEL = 150;
const STRETCH = 1.6;
/** Slow start, violent finish: the item is held for an instant, then snatched away. */
const EXIT_EASE = 'cubic-bezier(0.6, 0, 0.9, 0.35)';
/** Arrives fast from the edge, then settles softly into the centre. */
const ENTER_EASE = 'cubic-bezier(0.1, 0.85, 0.2, 1)';

// ── Bullet drag ─────────────────────────────────────────────────────────────────────────────────────────
const DRAG_PEAK_PX = 4; // furthest a single pulling neighbour moves the bullet (the bullet itself is 4px)
const DRAG_SCALE_X = 0.85; // at the peak the bullet is stretched along the pull, proportionally to its offset
const DRAG_SCALE_Y = 1.35;
/** Share of the peak reached AFTER the item has left, by coasting on the momentum it built up. */
const COAST_SHARE = 0.3;
const COAST_MS = 170;
const RETURN_MS = 260;
/**
 * Hand-off from the pull to the coast: the pull's easing ends at slope (1 - 0.35) / (1 - 0.9) = 6.5 (in units
 * of its own travel), so the coast must START at the same absolute speed: y1 / x1 = 6.5 * (1 - COAST_SHARE) /
 * (COAST_SHARE * COAST_MS / EXIT_MS) ~= 9.2. It ends at slope 0, as does the return, so the whole path is smooth.
 */
const COAST_EASE = 'cubic-bezier(0.08, 0.74, 0.3, 1)';
const RETURN_EASE = 'cubic-bezier(0.45, 0, 0.25, 1)';

/** Must mirror the Tailwind `max-*:hidden` classes on the slots in HeroMarquee.tsx. */
const BREAKPOINTS: ReadonlyArray<readonly [query: string, slots: number]> = [
  ['(min-width: 1536px)', 6],
  ['(min-width: 1280px)', 5],
  ['(min-width: 1024px)', 4],
  ['(min-width: 640px)', 3],
];
const BASE_SLOTS = 2;

/** Orange bullet between slot k and slot k+1. `a` is driven by the left slot, `b` (nested inside) by the right. */
interface Bullet {
  a: HTMLElement;
  b: HTMLElement;
}

interface Slot {
  el: HTMLElement;
  cells: [HTMLElement, HTMLElement];
  active: 0 | 1;
  item: string;
  arrivedAt: number;
  /** When this slot's own clock wants it to leave (never before its dwell is over). */
  dueAt: number;
  busy: boolean;
}

const rand = (min: number, max: number) => min + Math.random() * (max - min);
const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));
const transformAt = (pct: number, scaleY: number) => `translate3d(0, ${pct}%, 0) scaleY(${scaleY})`;
const REST = transformAt(0, 1);

/** Wires the engine to server-rendered markup. Returns a dispose function. */
export function createVacuumSwap(root: HTMLElement, items: readonly string[]): () => void {
  const slots: Slot[] = Array.from(root.querySelectorAll<HTMLElement>('[data-vsw-slot]')).flatMap((el, i) => {
    const cells = el.querySelectorAll<HTMLElement>('[data-vsw-cell]');
    if (cells.length !== 2) return [];
    return [
      {
        el,
        cells: [cells[0], cells[1]] as [HTMLElement, HTMLElement],
        active: 0 as const,
        item: items[i % items.length],
        arrivedAt: 0,
        dueAt: 0,
        busy: false,
      },
    ];
  });
  if (slots.length === 0 || items.length < 2) return () => {};

  const bullets: Bullet[] = Array.from(root.querySelectorAll<HTMLElement>('[data-vsw-bullet]')).flatMap((el) => {
    const a = el.querySelector<HTMLElement>('[data-vsw-drag="a"]');
    const b = el.querySelector<HTMLElement>('[data-vsw-drag="b"]');
    return a && b ? [{ a, b }] : [];
  });

  // ── Environment state ────────────────────────────────────────────────────────────────────────────────
  const motionQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
  let reduced = motionQuery.matches || typeof root.animate !== 'function';

  const sizeQueries = BREAKPOINTS.map(([query, n]) => ({ mql: window.matchMedia(query), n }));
  const computeCount = () => {
    for (const { mql, n } of sizeQueries) if (mql.matches) return Math.min(n, slots.length);
    return Math.min(BASE_SLOTS, slots.length);
  };
  let count = computeCount();

  let inView = true;
  let hovering = false;
  let disposed = false;
  let timer = 0;
  const dirs: Array<1 | -1> = []; // last pull directions, so the same way is never repeated more than twice
  let soloStreak = 0;
  let lastMotif: Motif | null = null;
  let cooldown = 0; // events left during which no motif may fire
  const running = new Set<Animation>();
  const dragging = new Map<HTMLElement, Animation>(); // at most one live drag per bullet side

  /** Items not currently shown in a VISIBLE slot, oldest-retired first (fair rotation). */
  let queue: string[] = [];

  const now = () => performance.now();
  const paused = () => disposed || hovering || !inView || document.hidden;

  // ── Item bookkeeping ─────────────────────────────────────────────────────────────────────────────────
  const rebuildQueue = () => {
    const shown = new Set(slots.slice(0, count).map((s) => s.item));
    queue = queue.filter((it) => !shown.has(it));
    for (const it of items) if (!shown.has(it) && !queue.includes(it)) queue.push(it);
  };

  const setInstant = (s: Slot, item: string) => {
    s.cells[s.active].textContent = item;
    s.item = item;
    s.arrivedAt = now();
  };

  /** Called on init and whenever the number of visible slots changes: no duplicates may ever be on screen. */
  const reconcile = () => {
    const seen = new Set<string>();
    for (let i = 0; i < count; i++) {
      const s = slots[i];
      if (seen.has(s.item)) {
        const replacement = items.find((it) => !seen.has(it));
        if (replacement) setInstant(s, replacement);
      }
      seen.add(s.item);
    }
    rebuildQueue();
  };

  const takeFromQueue = (): string | undefined => {
    if (queue.length === 0) return undefined;
    // Mostly the longest-rested item, sometimes the runner-up, so the order is not a visible loop.
    const idx = queue.length > 1 && Math.random() < 0.35 ? 1 : 0;
    return queue.splice(idx, 1)[0];
  };

  // ── Timing director ──────────────────────────────────────────────────────────────────────────────────
  const settled = (s: Slot, t: number) => !s.busy && t - s.arrivedAt >= MIN_DWELL;

  const drawRest = () => {
    let r = Math.random();
    for (const [w, lo, hi] of REST_MIX) {
      if (r < w) return rand(lo, hi);
      r -= w;
    }
    return rand(REST_MIX[1][1], REST_MIX[1][2]);
  };

  const pickDir = (): 1 | -1 => {
    const n = dirs.length;
    if (n >= 2 && dirs[n - 1] === dirs[n - 2]) return dirs[n - 1] === 1 ? -1 : 1; // no third in a row
    return Math.random() < 0.5 ? 1 : -1;
  };
  const noteDir = (d: 1 | -1) => {
    dirs.push(d);
    if (dirs.length > 2) dirs.shift();
  };

  const pickMotif = (): (typeof MOTIFS)[number] => {
    const pool = MOTIFS.filter((m) => m.id !== lastMotif);
    let r = Math.random() * pool.reduce((sum, m) => sum + m.weight, 0);
    for (const m of pool) {
      if ((r -= m.weight) < 0) return m;
    }
    return pool[pool.length - 1];
  };

  // ── Bullet drag ──────────────────────────────────────────────────────────────────────────────────────
  /**
   * One drag on one bullet side. Segment 1 shares the pull's delay, duration and easing, so it tracks the
   * item exactly; segment 2 coasts on the momentum; segment 3 eases back to rest. Transform-only,
   * compositor-driven, fill 'none' (rest = no effect).
   */
  const drag = (el: HTMLElement, dir: 1 | -1, startDelay: number, tempo: number, strength: number) => {
    // k = how far along the peak pose the bullet is (0 = rest, 1 = peak): offset and stretch both follow it.
    // `strength` scales the whole pose; all times scale with `tempo`, so the exit/coast ratio (and the speed
    // hand-off between them) is identical for every pull.
    const pose = (k: number) =>
      `translate3d(0, ${dir * DRAG_PEAK_PX * strength * k}px, 0) scale(${1 + (DRAG_SCALE_X - 1) * strength * k}, ${1 + (DRAG_SCALE_Y - 1) * strength * k})`;
    const exitMs = EXIT_MS * tempo;
    const total = (EXIT_MS + COAST_MS + RETURN_MS) * tempo;

    dragging.get(el)?.cancel(); // defensive: dwell makes a second pull on the same side impossible in practice
    const anim = el.animate(
      [
        { transform: pose(0), offset: 0, easing: EXIT_EASE },
        { transform: pose(1 - COAST_SHARE), offset: exitMs / total, easing: COAST_EASE },
        { transform: pose(1), offset: (EXIT_MS + COAST_MS) * tempo / total, easing: RETURN_EASE },
        { transform: pose(0), offset: 1 },
      ],
      { duration: total, delay: startDelay, fill: 'none' },
    );
    dragging.set(el, anim);
    running.add(anim);
    anim.onfinish = () => {
      running.delete(anim);
      if (dragging.get(el) === anim) dragging.delete(el);
    };
  };

  /** A pull on slot i tugs the bullet on each side of it (those that exist and are on screen). */
  const dragNeighbours = (index: number, dir: 1 | -1, startDelay: number, tempo: number, strength: number) => {
    const before = bullets[index - 1]; // slot is this bullet's RIGHT neighbour
    const after = index + 1 < count ? bullets[index] : undefined; // slot is this bullet's LEFT neighbour
    if (before) drag(before.b, dir, startDelay, tempo, strength);
    if (after) drag(after.a, dir, startDelay, tempo, strength);
  };

  // ── The swap itself ──────────────────────────────────────────────────────────────────────────────────
  /** dir -1 = pulled upward, +1 = pulled downward. Returns the time the whole swap occupies. */
  const launch = (index: number, dir: 1 | -1, startDelay: number): number => {
    const s = slots[index];
    const next = takeFromQueue();
    if (!next) {
      s.dueAt = now() + rand(DEFER_MIN, DEFER_MAX);
      return 0;
    }
    queue.push(s.item);
    noteDir(dir);

    if (reduced) {
      setInstant(s, next);
      s.dueAt = now() + rand(REDUCED_GAP_MIN, REDUCED_GAP_MAX);
      return 0;
    }

    const tempo = rand(TEMPO_MIN, TEMPO_MAX);
    const strength = clamp(1 + (1 - tempo) * STRENGTH_GAIN, 0.7, 1.25);
    const enterDelay = ENTER_DELAY * tempo;
    const span = startDelay + enterDelay + ENTER_MS * tempo;
    s.dueAt = now() + span + MIN_DWELL + drawRest(); // this slot's next appointment, drawn right now

    const out = s.cells[s.active];
    const inn = s.cells[s.active === 0 ? 1 : 0];
    s.busy = true;
    inn.textContent = next;
    inn.style.visibility = 'visible';
    s.el.setAttribute('data-fly', ''); // promotes both cells to compositor layers for the duration only

    const exit = out.animate([{ transform: REST }, { transform: transformAt(dir * TRAVEL, STRETCH) }], {
      duration: EXIT_MS * tempo,
      delay: startDelay,
      easing: EXIT_EASE,
      fill: 'both',
    });
    const enter = inn.animate([{ transform: transformAt(-dir * TRAVEL, STRETCH) }, { transform: REST }], {
      duration: ENTER_MS * tempo,
      delay: startDelay + enterDelay,
      easing: ENTER_EASE,
      fill: 'both',
    });
    running.add(exit);
    running.add(enter);
    dragNeighbours(index, dir, startDelay, tempo, strength); // same task, same delay -> same compositor frame as `exit`

    exit.onfinish = () => {
      out.style.visibility = 'hidden'; // hide first, then drop the fill -> no one-frame flash
      exit.cancel();
      running.delete(exit);
    };
    enter.onfinish = () => {
      enter.cancel(); // resting state is the un-animated style; nothing is held on the compositor
      running.delete(enter);
      s.active = s.active === 0 ? 1 : 0;
      s.item = next;
      s.arrivedAt = now();
      s.busy = false;
      s.el.removeAttribute('data-fly');
    };

    return span;
  };

  // ── Scheduler: a single timer chain, sleeping until the earliest per-slot appointment ───────────────
  const schedule = (ms: number) => {
    window.clearTimeout(timer);
    timer = window.setTimeout(tick, Math.max(MIN_WAKE, ms));
  };

  const stop = () => {
    window.clearTimeout(timer);
    timer = 0;
  };

  /** Sleep until the first visible slot is both due and settled. */
  const scheduleNext = () => {
    const t = now();
    let wake = Infinity;
    for (let i = 0; i < count; i++) {
      const s = slots[i];
      wake = Math.min(wake, Math.max(s.dueAt, s.busy ? 0 : s.arrivedAt + MIN_DWELL) - t);
    }
    schedule(Number.isFinite(wake) ? wake : RESUME_DELAY);
  };

  function tick() {
    timer = 0;
    if (paused()) return;

    const t = now();
    const due: number[] = [];
    for (let i = 0; i < count; i++) {
      const s = slots[i];
      if (settled(s, t) && t >= s.dueAt - OVERDUE_GRACE) due.push(i);
    }
    if (due.length === 0) {
      scheduleNext();
      return;
    }

    // Lead: any due slot, favouring the one that has waited longest.
    let r = Math.random() * due.reduce((sum, i) => sum + (t - slots[i].dueAt + 600), 0);
    let lead = due[0];
    for (const i of due) {
      if ((r -= t - slots[i].dueAt + 600) < 0) {
        lead = i;
        break;
      }
    }
    // Slots that fell due together must never fire together by accident: push them back unless recruited below.
    for (const i of due) if (i !== lead) slots[i].dueAt = t + rand(DEFER_MIN, DEFER_MAX);

    const dir = pickDir();
    launch(lead, dir, 0);

    // Motif: does a partner join the lead, and how?
    let motif: Motif | null = null;
    if (!reduced && cooldown <= 0) {
      const chance = MOTIF_BASE_CHANCE + MOTIF_PITY_STEP * Math.min(soloStreak, MOTIF_PITY_MAX);
      if (Math.random() < chance) {
        const m = pickMotif();
        const candidates: number[] = [];
        for (let i = 0; i < count; i++) if (i !== lead && settled(slots[i], t)) candidates.push(i);
        // Chase / counter prefer a direct neighbour (that is where the bullet drag shows); echo prefers distance.
        const near = candidates.filter((i) => Math.abs(i - lead) === 1);
        const far = candidates.filter((i) => Math.abs(i - lead) > 1);
        const pool = m.id === 'echo' ? (far.length ? far : candidates) : near.length ? near : candidates;
        if (pool.length > 0) {
          const partner = pool[Math.floor(Math.random() * pool.length)];
          const opposite: 1 | -1 = dir === 1 ? -1 : 1;
          const pdir = m.dir === 'same' ? dir : m.dir === 'opposite' ? opposite : Math.random() < 0.5 ? dir : opposite;
          launch(partner, pdir, m.gap[0] === m.gap[1] ? 0 : rand(m.gap[0], m.gap[1]));
          motif = m.id;
        }
      }
    }
    if (motif) {
      lastMotif = motif;
      soloStreak = 0;
      cooldown = 1 + (Math.random() < 0.5 ? 1 : 0); // at least one plain event before the next motif
    } else {
      soloStreak++;
      cooldown--;
    }

    scheduleNext();
  }

  const sync = () => {
    if (paused()) stop();
    else if (!timer) schedule(RESUME_DELAY);
  };

  // ── Listeners ────────────────────────────────────────────────────────────────────────────────────────
  const onVisibility = () => sync();
  const onEnter = (e: PointerEvent) => {
    if (e.pointerType !== 'mouse') return; // touch "hover" sticks; only a real cursor pauses
    hovering = true;
    sync();
  };
  const onLeave = () => {
    hovering = false;
    sync();
  };
  const onSizeChange = () => {
    const next = computeCount();
    if (next === count) return;
    const prev = count;
    count = next;
    // Slots that just became visible get a short grace period before they may swap.
    for (let i = prev; i < count; i++) {
      slots[i].arrivedAt = now() - MIN_DWELL / 2;
      slots[i].dueAt = now() + rand(1500, 4500);
    }
    reconcile();
  };
  const onMotionChange = () => {
    reduced = motionQuery.matches || typeof root.animate !== 'function';
  };

  const io = new IntersectionObserver((entries) => {
    inView = entries[entries.length - 1].isIntersecting;
    sync();
  });

  // ── Init: normalise DOM (also makes React Strict Mode's mount/unmount/mount safe) ────────────────────
  const t0 = now();
  bullets.forEach((b) => [b.a, b.b].forEach((el) => el.getAnimations().forEach((a) => a.cancel())));
  slots.forEach((s, i) => {
    s.cells.forEach((c) => c.getAnimations().forEach((a) => a.cancel()));
    s.el.removeAttribute('data-fly');
    s.active = 0;
    s.item = items[i % items.length];
    s.cells[0].textContent = s.item;
    s.cells[0].style.visibility = 'visible';
    s.cells[1].textContent = '';
    s.cells[1].style.visibility = 'hidden';
    // Each slot gets its own random first appointment, so the opening swaps never line up.
    s.arrivedAt = t0 - MIN_DWELL;
    s.dueAt = t0 + INITIAL_DELAY + rand(0, 3800);
    s.busy = false;
  });
  reconcile();

  motionQuery.addEventListener('change', onMotionChange);
  sizeQueries.forEach(({ mql }) => mql.addEventListener('change', onSizeChange));
  document.addEventListener('visibilitychange', onVisibility);
  root.addEventListener('pointerenter', onEnter);
  root.addEventListener('pointerleave', onLeave);
  io.observe(root);
  if (!paused()) scheduleNext();

  return () => {
    disposed = true;
    stop();
    io.disconnect();
    motionQuery.removeEventListener('change', onMotionChange);
    sizeQueries.forEach(({ mql }) => mql.removeEventListener('change', onSizeChange));
    document.removeEventListener('visibilitychange', onVisibility);
    root.removeEventListener('pointerenter', onEnter);
    root.removeEventListener('pointerleave', onLeave);
    running.forEach((a) => {
      a.onfinish = null;
      a.cancel();
    });
    running.clear();
    dragging.clear();
    slots.forEach((s) => s.el.removeAttribute('data-fly'));
  };
}
