import type Lenis from 'lenis';

/**
 * Shared handle on the page's Lenis instance (created in Providers.tsx), so any component can start a
 * smooth, eased scroll without owning the scroll engine. Falls back to the browser's native smooth scroll
 * when Lenis is not running (SSR, or before Providers has mounted).
 */
let instance: Lenis | null = null;

export function registerLenis(lenis: Lenis | null) {
  instance = lenis;
}

/** Slow in, long glide, slow out. No hard edge at either end, which is what reads as "buttery". */
const easeInOutQuart = (t: number) => (t < 0.5 ? 8 * t ** 4 : 1 - (-2 * t + 2) ** 4 / 2);

/** Eased scroll to an absolute document Y. Duration grows with distance (1.4s to 2.8s). */
export function smoothScrollToY(y: number) {
  const distance = Math.abs(y - window.scrollY);
  const duration = Math.min(2.8, Math.max(1.4, 1.1 + distance / 1400));
  if (instance) {
    instance.scrollTo(y, { duration, easing: easeInOutQuart, force: true });
    return;
  }
  window.scrollTo({ top: y, behavior: 'smooth' });
}
