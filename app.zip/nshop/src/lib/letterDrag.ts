/**
 * Per-letter drag physics for the footer watermark (see components/FooterWatermark.tsx).
 *
 * Ported from phylax's DraggableFooterLogo and generalised from "one logo" to "one controller per letter":
 *
 *  - Pointer events (mouse, pen, touch) with pointer capture; `touch-action: none` on the letters (CSS) hands the
 *    gesture to this code, so swiping a letter moves that letter, not the page. Every letter owns its own pointer id,
 *    so several fingers can pull several letters at once and a letter can never drag its neighbours.
 *  - Magnetic tension: the letter is tethered to its resting place by a rubber band. The pointer's pull passes through
 *    `tensionMap` (follow ratio 1 at the centre, easing toward 1 - S far out), and `tensionInverse` re-anchors the pull
 *    whenever the clamp pins the letter, so there is never a dead zone on the way back.
 *  - Recoil: on release the letter snaps a short way toward home on an under-damped spring (fixed 1/240 s sub-steps),
 *    overshoots and stays where it settles.
 *  - Idle return: after IDLE_RETURN_MS without pointer/wheel activity in the footer, displaced letters glide home
 *    on a CSS transition. A press mid-glide takes over from the visible position.
 *
 * Added on top of the reference:
 *  - Three mirrored layers per letter (fill / knock-out / hit). Every layer's copy of letter i gets the *same*
 *    transform and transition (the reference's "plate" pattern), so they can never drift apart.
 *  - Brightness: `is-lit` is toggled on the fill copy while the letter is dragged, hovered (mouse/pen), recoiling or
 *    gliding; CSS fades colour in and out.
 *  - X-ray rings: `is-ring` is toggled on a letter's hit copy while its (inset) box overlaps another letter's, so the
 *    outline layer fades in exactly when the knock-out layer is cutting a hole. Measured once per frame while
 *    anything is moving.
 *
 * Only `transform` is ever written to layout-participating elements, so nothing here can shift layout.
 *
 * Published for other components: while a letter is held (and once, when it is let go) the controller dispatches a
 * LETTER_DRAG_EVENT CustomEvent on `root` with a LetterDragDetail: which letter, how far it is from its resting place
 * (after tension and containment, i.e. exactly what is on screen), whether it is still held, and the pointer type.
 * FooterMascot uses it to lean Nemo with a finger's drag. Nothing in here depends on anyone listening.
 */

/** Fired on the watermark root; see LetterDragDetail. */
export const LETTER_DRAG_EVENT = 'wm:letter-drag';
export type LetterDragDetail = {
  /** Letter index, as in data-wm-i. */
  i: number;
  /** Displacement from the resting place, px, as drawn (after tension and containment). */
  x: number;
  y: number;
  /** True while the letter is held; one final event with false when it is released. */
  active: boolean;
  /** PointerEvent.pointerType of the pointer holding it: 'touch', 'mouse' or 'pen'. */
  pointerType: string;
};

const IDLE_RETURN_MS = 4000; // inactivity before displaced letters glide home
const RETURN_MS = 750; // duration of the glide home
const RETURN_EASE = 'cubic-bezier(.16,1,.3,1)'; // fast start, soft landing
const CONTAINMENT_INSET = 8; // px kept clear between a letter and the horizontal bounds
const CONTAINMENT_PAD_Y = 28; // px a letter may travel above / below the watermark block

// Magnetic tension: displayed offset m = d - S*d^2/(d + L), d = pointer pull from the resting place.
const TENSION_SCALE = 110; // L, px
const TENSION_STRENGTH = 0.62; // S, 0..<1

// Recoil on release: short, snappy, under-damped spring toward home.
const RECOIL_FRACTION = 0.2;
const RECOIL_MAX_PX = 34;
const RECOIL_STIFFNESS = 900;
const RECOIL_DAMPING = 22;
const RECOIL_KICK = 10;
const RECOIL_TIMEOUT_MS = 1500;

// Overlap test for the X-ray ring: the letter's box shrunk to roughly its ink (caps do not fill the line box).
const INK_INSET_X = 0.08; // fraction of box width removed from each side
const INK_INSET_Y = 0.16; // fraction of box height removed from top and bottom
const MIN_OVERLAP_PX = 1.5;

const tensionMap = (d: number) => d - (TENSION_STRENGTH * d * d) / (d + TENSION_SCALE);

const tensionInverse = (m: number) => {
  if (m <= 0) return 0;
  const a = 1 - TENSION_STRENGTH;
  const q = TENSION_SCALE - m;
  const s = Math.sqrt(q * q + 4 * a * m * TENSION_SCALE);
  return q >= 0 ? (2 * m * TENSION_SCALE) / (q + s) : (s - q) / (2 * a);
};

const clamp = (v: number, min: number, max: number) => (min > max ? (min + max) / 2 : Math.min(max, Math.max(min, v)));

export type LetterDragOptions = {
  /** Horizontal limits (the footer). Vertical limits are the watermark block itself plus a small pad. */
  bounds: HTMLElement;
  /** Called with true when the first letter is hovered/held and false when the last one is released. */
  onHoverChange?: (hovering: boolean) => void;
};

type Letter = {
  i: number;
  hit: HTMLElement;
  fill: HTMLElement;
  els: HTMLElement[];
  pos: { x: number; y: number };
  drag: { active: boolean; id: number; startX: number; startY: number; pullX0: number; pullY0: number; lastX: number; lastY: number; raf: number };
  idleTimer: number;
  returnTimer: number;
  recoilRaf: number;
  hovered: boolean;
  lit: boolean;
  ring: boolean;
  pointerType: string;
  armIdle: () => void;
  clampToBounds: () => void;
  release: () => void;
  dispose: () => void;
};

export function attachLetterDrag(root: HTMLElement, { bounds, onHoverChange }: LetterDragOptions): () => void {
  const q = (layer: string) =>
    Array.from(root.querySelectorAll<HTMLElement>(`[data-wm-layer="${layer}"] [data-wm-i]`)).sort(
      (a, b) => Number(a.dataset.wmI) - Number(b.dataset.wmI),
    );
  const hits = q('hit');
  const fills = q('fill');
  const kos = q('ko');
  if (!hits.length || hits.length !== fills.length || hits.length !== kos.length) return () => {};

  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const letters: Letter[] = [];
  let tickRaf = 0;
  let hoverCount = 0;
  let hoverReported = false;

  const reportHover = () => {
    const now = hoverCount > 0;
    if (now === hoverReported) return;
    hoverReported = now;
    onHoverChange?.(now);
  };

  // ---- shared: brightness + overlap rings ---------------------------------------------------------------------------

  const isBusy = (l: Letter) => l.drag.active || l.recoilRaf !== 0 || l.returnTimer !== 0;

  const refreshLit = (l: Letter) => {
    const lit = l.hovered || isBusy(l);
    if (lit === l.lit) return;
    l.lit = lit;
    l.fill.classList.toggle('is-lit', lit);
  };

  const inkRect = (el: HTMLElement) => {
    const r = el.getBoundingClientRect();
    const ix = r.width * INK_INSET_X;
    const iy = r.height * INK_INSET_Y;
    return { l: r.left + ix, r: r.right - ix, t: r.top + iy, b: r.bottom - iy };
  };

  const updateRings = () => {
    tickRaf = 0;
    const rects = letters.map((l) => inkRect(l.hit));
    for (let a = 0; a < letters.length; a++) {
      let overlapping = false;
      const ra = rects[a];
      for (let b = 0; b < letters.length && !overlapping; b++) {
        if (a === b) continue;
        const rb = rects[b];
        overlapping =
          Math.min(ra.r, rb.r) - Math.max(ra.l, rb.l) > MIN_OVERLAP_PX &&
          Math.min(ra.b, rb.b) - Math.max(ra.t, rb.t) > MIN_OVERLAP_PX;
      }
      const l = letters[a];
      if (overlapping !== l.ring) {
        l.ring = overlapping;
        l.hit.classList.toggle('is-ring', overlapping);
      }
    }
    // Keep measuring for as long as anything is moving (including CSS-driven glides); one last pass runs after it stops.
    if (letters.some(isBusy)) tickRaf = requestAnimationFrame(updateRings);
  };
  const pump = () => {
    if (!tickRaf) tickRaf = requestAnimationFrame(updateRings);
  };

  // ---- shared: containment ------------------------------------------------------------------------------------------

  const limits = () => {
    const f = bounds.getBoundingClientRect();
    const w = root.getBoundingClientRect();
    return {
      left: f.left + CONTAINMENT_INSET,
      right: f.right - CONTAINMENT_INSET,
      top: w.top - CONTAINMENT_PAD_Y,
      bottom: w.bottom + CONTAINMENT_PAD_Y,
    };
  };

  // ---- one controller per letter ------------------------------------------------------------------------------------

  const create = (i: number): Letter => {
    const hit = hits[i];
    const fill = fills[i];
    const els = [fills[i], kos[i], hits[i]];
    const l: Letter = {
      i,
      hit,
      fill,
      els,
      pos: { x: 0, y: 0 },
      drag: { active: false, id: -1, startX: 0, startY: 0, pullX0: 0, pullY0: 0, lastX: 0, lastY: 0, raf: 0 },
      idleTimer: 0,
      returnTimer: 0,
      recoilRaf: 0,
      hovered: false,
      lit: false,
      ring: false,
      pointerType: 'mouse',
      armIdle: () => {},
      clampToBounds: () => {},
      release: () => {},
      dispose: () => {},
    };
    const { pos, drag } = l;

    const write = () => {
      const t = `translate3d(${pos.x}px, ${pos.y}px, 0)`;
      for (const el of els) el.style.transform = t;
    };
    const emit = (active: boolean) => {
      root.dispatchEvent(
        new CustomEvent<LetterDragDetail>(LETTER_DRAG_EVENT, {
          detail: { i, x: pos.x, y: pos.y, active, pointerType: l.pointerType },
        }),
      );
    };
    const setTransition = (v: string) => {
      for (const el of els) el.style.transition = v;
    };
    const readCurrent = () => {
      const m = new DOMMatrixReadOnly(getComputedStyle(hit).transform);
      pos.x = m.m41;
      pos.y = m.m42;
    };
    const atRest = () => pos.x === 0 && pos.y === 0;

    const stopRecoil = () => {
      if (l.recoilRaf) cancelAnimationFrame(l.recoilRaf);
      l.recoilRaf = 0;
    };
    const cancelTimers = () => {
      clearTimeout(l.idleTimer);
      clearTimeout(l.returnTimer);
      l.idleTimer = 0;
      l.returnTimer = 0;
    };

    const translationRange = () => {
      const rect = hit.getBoundingClientRect();
      const lim = limits();
      const restLeft = rect.left - pos.x;
      const restTop = rect.top - pos.y;
      return {
        minX: lim.left - restLeft,
        maxX: lim.right - rect.width - restLeft,
        minY: lim.top - restTop,
        maxY: lim.bottom - rect.height - restTop,
      };
    };

    const clampToBounds = () => {
      if (atRest() || drag.active || l.returnTimer) return;
      const r = translationRange();
      pos.x = clamp(pos.x, r.minX, r.maxX);
      pos.y = clamp(pos.y, r.minY, r.maxY);
      write();
    };

    const startRecoil = () => {
      stopRecoil();
      if (reduced) return;
      const d = Math.hypot(pos.x, pos.y);
      const recoil = Math.min(RECOIL_MAX_PX, d * RECOIL_FRACTION);
      if (recoil < 1) return;
      const ux = pos.x / d;
      const uy = pos.y / d;
      const tx = pos.x - ux * recoil;
      const ty = pos.y - uy * recoil;
      let vx = -ux * recoil * RECOIL_KICK;
      let vy = -uy * recoil * RECOIL_KICK;
      const t0 = performance.now();
      let last = t0;
      setTransition('none');

      const step = (now: number) => {
        let dt = Math.min(Math.max((now - last) / 1000, 0), 0.05);
        last = now;
        while (dt > 0) {
          const h = Math.min(dt, 1 / 240);
          vx += (-RECOIL_STIFFNESS * (pos.x - tx) - RECOIL_DAMPING * vx) * h;
          vy += (-RECOIL_STIFFNESS * (pos.y - ty) - RECOIL_DAMPING * vy) * h;
          pos.x += vx * h;
          pos.y += vy * h;
          dt -= h;
        }
        const settled = Math.abs(pos.x - tx) + Math.abs(pos.y - ty) < 0.05 && Math.abs(vx) + Math.abs(vy) < 4;
        if (settled || now - t0 > RECOIL_TIMEOUT_MS) {
          pos.x = tx;
          pos.y = ty;
          l.recoilRaf = 0;
        } else {
          l.recoilRaf = requestAnimationFrame(step);
        }
        write();
        if (!l.recoilRaf) refreshLit(l);
      };
      l.recoilRaf = requestAnimationFrame(step);
    };

    const sendHome = () => {
      l.idleTimer = 0;
      if (drag.active || atRest()) return;
      stopRecoil();
      pos.x = 0;
      pos.y = 0;
      if (reduced) {
        setTransition('none');
        write();
        refreshLit(l);
        pump();
        return;
      }
      setTransition(`transform ${RETURN_MS}ms ${RETURN_EASE}`);
      write();
      l.returnTimer = window.setTimeout(() => {
        l.returnTimer = 0;
        setTransition('none');
        refreshLit(l);
        pump();
      }, RETURN_MS + 50);
      refreshLit(l);
      pump();
    };

    const armIdle = () => {
      clearTimeout(l.idleTimer);
      l.idleTimer = 0;
      if (drag.active || l.returnTimer || atRest()) return;
      l.idleTimer = window.setTimeout(sendHome, IDLE_RETURN_MS);
    };

    const applyDrag = () => {
      drag.raf = 0;
      const r = translationRange();
      const dx = drag.lastX - drag.startX;
      const dy = drag.lastY - drag.startY;
      const pullX = drag.pullX0 + dx;
      const pullY = drag.pullY0 + dy;
      const pull = Math.hypot(pullX, pullY);
      const k = pull > 0 ? tensionMap(pull) / pull : 0;
      const wantX = pullX * k;
      const wantY = pullY * k;
      pos.x = clamp(wantX, r.minX, r.maxX);
      pos.y = clamp(wantY, r.minY, r.maxY);
      if (pos.x !== wantX || pos.y !== wantY) {
        const m = Math.hypot(pos.x, pos.y);
        const j = m > 0 ? tensionInverse(m) / m : 0;
        drag.pullX0 = pos.x * j - dx;
        drag.pullY0 = pos.y * j - dy;
      }
      write();
      emit(true);
    };

    const finishDrag = (flush?: { x: number; y: number }) => {
      if (!drag.active) return;
      if (drag.raf) {
        cancelAnimationFrame(drag.raf);
        drag.raf = 0;
      }
      if (flush) {
        drag.lastX = flush.x;
        drag.lastY = flush.y;
        applyDrag();
      }
      drag.active = false;
      emit(false);
      try {
        if (hit.hasPointerCapture(drag.id)) hit.releasePointerCapture(drag.id);
      } catch {
        /* capture already gone */
      }
      hit.classList.remove('is-dragging');
      startRecoil();
      armIdle();
      refreshLit(l);
      pump();
    };

    const onPointerDown = (e: PointerEvent) => {
      if (drag.active) return; // one pointer per letter
      if (e.pointerType === 'mouse' && e.button !== 0) return;
      e.preventDefault(); // no native drag ghost, no text selection
      const gliding = l.returnTimer !== 0;
      cancelTimers();
      stopRecoil();
      if (gliding) {
        readCurrent();
        setTransition('none');
        write();
      }
      drag.active = true;
      l.pointerType = e.pointerType;
      drag.id = e.pointerId;
      drag.startX = drag.lastX = e.clientX;
      drag.startY = drag.lastY = e.clientY;
      const here = Math.hypot(pos.x, pos.y);
      const j = here > 0 ? tensionInverse(here) / here : 0;
      drag.pullX0 = pos.x * j;
      drag.pullY0 = pos.y * j;
      try {
        hit.setPointerCapture(e.pointerId);
      } catch {
        /* pointer already gone */
      }
      hit.classList.add('is-dragging');
      refreshLit(l);
      pump();
    };

    const onPointerMove = (e: PointerEvent) => {
      if (!drag.active || e.pointerId !== drag.id) return;
      drag.lastX = e.clientX;
      drag.lastY = e.clientY;
      if (!drag.raf) drag.raf = requestAnimationFrame(applyDrag);
      pump();
    };
    const onPointerUp = (e: PointerEvent) => {
      if (e.pointerId === drag.id) finishDrag({ x: e.clientX, y: e.clientY });
    };
    const onPointerCancel = (e: PointerEvent) => {
      if (e.pointerId === drag.id) finishDrag();
    };
    const onLostCapture = (e: PointerEvent) => {
      if (e.pointerId === drag.id) finishDrag();
    };

    const setHovered = (v: boolean) => {
      if (v === l.hovered) return;
      l.hovered = v;
      hoverCount += v ? 1 : -1;
      reportHover();
      refreshLit(l);
    };
    const onEnter = (e: PointerEvent) => {
      if (e.pointerType !== 'touch') setHovered(true);
    };
    const onLeave = () => setHovered(false);

    const prevent = (e: Event) => e.preventDefault();

    hit.addEventListener('pointerdown', onPointerDown);
    hit.addEventListener('pointermove', onPointerMove);
    hit.addEventListener('pointerup', onPointerUp);
    hit.addEventListener('pointercancel', onPointerCancel);
    hit.addEventListener('lostpointercapture', onLostCapture);
    hit.addEventListener('pointerenter', onEnter);
    hit.addEventListener('pointerleave', onLeave);
    hit.addEventListener('dragstart', prevent);
    hit.addEventListener('selectstart', prevent);
    hit.addEventListener('contextmenu', prevent);

    l.armIdle = () => {
      if (!drag.active && !atRest()) armIdle();
    };
    l.clampToBounds = clampToBounds;
    l.release = () => finishDrag();

    l.dispose = () => {
      cancelTimers();
      stopRecoil();
      cancelAnimationFrame(drag.raf);
      hit.removeEventListener('pointerdown', onPointerDown);
      hit.removeEventListener('pointermove', onPointerMove);
      hit.removeEventListener('pointerup', onPointerUp);
      hit.removeEventListener('pointercancel', onPointerCancel);
      hit.removeEventListener('lostpointercapture', onLostCapture);
      hit.removeEventListener('pointerenter', onEnter);
      hit.removeEventListener('pointerleave', onLeave);
      hit.removeEventListener('dragstart', prevent);
      hit.removeEventListener('selectstart', prevent);
      hit.removeEventListener('contextmenu', prevent);
      if (drag.active) {
        try {
          hit.releasePointerCapture(drag.id);
        } catch {
          /* ignore */
        }
      }
      for (const el of els) {
        el.style.transform = '';
        el.style.transition = '';
      }
      fill.classList.remove('is-lit');
      hit.classList.remove('is-dragging', 'is-ring');
    };
    return l;
  };

  for (let i = 0; i < hits.length; i++) letters.push(create(i));

  // ---- footer-wide activity / lifecycle -----------------------------------------------------------------------------

  // Any pointer or wheel activity in the footer means the visitor is around: restart every displaced letter's timer.
  const onActivity = () => {
    for (const l of letters) l.armIdle();
  };
  const onResize = () => {
    for (const l of letters) l.clampToBounds();
    pump();
  };
  // A window that loses focus mid-drag may never deliver pointerup: let go so nothing stays lit or held.
  const onBlur = () => {
    for (const l of letters) l.release();
  };

  bounds.addEventListener('pointermove', onActivity);
  bounds.addEventListener('pointerdown', onActivity);
  bounds.addEventListener('wheel', onActivity, { passive: true });
  window.addEventListener('resize', onResize);
  window.addEventListener('blur', onBlur);

  return () => {
    bounds.removeEventListener('pointermove', onActivity);
    bounds.removeEventListener('pointerdown', onActivity);
    bounds.removeEventListener('wheel', onActivity);
    window.removeEventListener('resize', onResize);
    window.removeEventListener('blur', onBlur);
    cancelAnimationFrame(tickRaf);
    tickRaf = 0;
    for (const l of letters) l.dispose();
    if (hoverReported) onHoverChange?.(false);
  };
}
