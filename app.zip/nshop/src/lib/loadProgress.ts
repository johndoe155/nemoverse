/**
 * Real page-load progress (0..1), no timers pretending to be work.
 *
 * Signals, weighted:
 *   0.10  DOM parsed            (document.readyState >= "interactive")
 *   0.15  web fonts resolved    (document.fonts.ready)
 *   0.45  assets                (eligible <img> elements decoded + three.js loader items)
 *   0.30  window "load"         (JS chunks, CSS, everything the browser itself blocks on)
 *
 * The value is monotonic - late-discovered images can grow the denominator, but the reported
 * progress never moves backwards. A hard timeout resolves it to 1 so a stalled request can
 * never trap the visitor behind the preloader.
 */
import { useProgress } from '@react-three/drei';

const W_DOM = 0.1;
const W_FONTS = 0.15;
const W_ASSETS = 0.45;
const W_LOAD = 0.3;

export const LOAD_TIMEOUT_MS = 12000;

export interface LoadProgressTracker {
  /** Latest real progress in [0, 1]. Cheap to read every frame. */
  get(): number;
  stop(): void;
}

function imageRatio(): { loaded: number; total: number } {
  let loaded = 0;
  let total = 0;
  for (const img of Array.from(document.images)) {
    // Lazy images below the fold never load until scrolled to - they must not hold the preloader.
    if (img.loading === 'lazy' && !img.complete) continue;
    total += 1;
    if (img.complete) loaded += 1; // complete is also true for a failed image: it's "settled"
  }
  return { loaded, total };
}

export function trackLoadProgress(): LoadProgressTracker {
  let fontsReady = false;
  let windowLoaded = document.readyState === 'complete';
  let best = 0;
  let forced = false;

  document.fonts?.ready.then(() => (fontsReady = true), () => (fontsReady = true));
  if (!document.fonts) fontsReady = true;

  const onLoad = () => (windowLoaded = true);
  if (!windowLoaded) window.addEventListener('load', onLoad, { once: true });

  const timeout = window.setTimeout(() => (forced = true), LOAD_TIMEOUT_MS);

  const compute = (): number => {
    if (forced) return 1;

    const dom = document.readyState !== 'loading' ? 1 : 0;

    const imgs = imageRatio();
    const three = useProgress.getState(); // THREE.DefaultLoadingManager: textures, models, HDRs...
    const total = imgs.total + three.total;
    const loaded = imgs.loaded + Math.min(three.loaded, three.total);
    const assets = total > 0 ? loaded / total : 1;

    const p =
      W_DOM * dom +
      W_FONTS * (fontsReady ? 1 : 0) +
      W_ASSETS * assets +
      W_LOAD * (windowLoaded ? 1 : 0);

    // Don't claim "done" until the browser itself says the page has loaded.
    const capped = windowLoaded && fontsReady ? p : Math.min(p, 0.99);
    return Math.min(1, capped);
  };

  return {
    get() {
      best = Math.max(best, compute());
      return best >= 0.9999 ? 1 : best;
    },
    stop() {
      window.clearTimeout(timeout);
      window.removeEventListener('load', onLoad);
    },
  };
}
