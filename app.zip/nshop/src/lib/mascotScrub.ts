/**
 * Scroll-scrubbed stop-motion for the footer mascot (see components/FooterMascot.tsx).
 *
 * Everything here is framework-free and has no side effects on import: the mapping from scroll progress to a frame
 * and a camera zoom (pure functions), the canvas painter, and the frame loader.
 *
 * Why a canvas and not eight stacked <img>s: the camera push-in scales the artwork by up to ZOOM_MAX. A canvas
 * repaints the bitmap at the zoomed size every time, so the face stays razor sharp at any zoom and any pixel ratio,
 * where a scaled DOM layer is either re-rasterised every frame or (with will-change) left blurry. A single canvas
 * also cannot cross-fade, flicker or show a half-decoded frame: a paint is "this decoded bitmap, at this scale", or
 * nothing changes at all.
 */

/** Frame names, in playback order (01 is the first frame, 08 the last). 01 is the original static footer mascot. */
export const FRAME_IDS = ['01', '02', '03', '04', '05', '06', '07', '08'] as const;
export const FRAME_COUNT = FRAME_IDS.length;

/**
 * The two rendition widths in /public/mascot/frames, and the height / width of every frame. All eight frames share
 * one crop (the union of their subjects plus a little air above the highest bare crown), so the box never changes.
 * Frame 01 sits in that same crop, registered to 02 on the eye line (see scripts/mascot), so 01 -> 02 changes the cap and
 * nothing else: not a pixel of the face, the hoodie or the cords moves.
 */
export const FRAME_WIDTHS = { sm: 800, lg: 1280 } as const;
export type FrameTier = keyof typeof FRAME_WIDTHS;
export const FRAME_ASPECT = 1808 / 2048; // 0.8828. Mirrors --fm-ar in globals.css.
export const frameUrl = (id: string, tier: FrameTier) => `/mascot/frames/nemo-${id}-${FRAME_WIDTHS[tier]}.webp`;

/**
 * The camera's focal point, as a fraction of the frame. It sits on the vertical centre line, a hair above the highest
 * bare crown (06's is at 2.8% of the frame height, the others at 4.4% to 5.9%), so the push-in grows the head downward
 * and outward from just above it and the crown never runs out of the top of the frame.
 * Frame 01 (the cap) is the one exception: its crown is flush with the top edge of the shared crop, above the focal
 * point. It only ever shows below 1/8 progress, where the zoom has barely left 1 (1.015 at most), so the push-in moves
 * it by a fraction of a pixel.
 */
export const FOCAL = { x: 0.5, y: 0.015 } as const;
/** Zoom at progress 1. At 1.4 the face fills the window with the chin still inside the bottom dissolve. */
export const ZOOM_MAX = 1.4;

/**
 * The photo's own lower crop (a hard edge through the hoodie) is dissolved into the footer: alpha of the mask by the
 * fraction of the frame height. Same stops as the stylesheet's .fm-poster, so poster and canvas are identical.
 */
const HEM_STOPS: ReadonlyArray<readonly [number, number]> = [
  [0, 1],
  [0.58, 1],
  [0.68, 0.86],
  [0.78, 0.58],
  [0.89, 0.26],
  [1, 0],
];

const clamp01 = (v: number) => (v < 0 ? 0 : v > 1 ? 1 : v);

/**
 * Frame for a progress value. A pure function of progress, on purpose: the same scroll position always shows the
 * same frame, forward or in reverse, with no hysteresis or memory. Each frame owns an equal 1/8 of the range, and
 * progress 1 lands on the last frame.
 */
export function frameIndexAt(progress: number): number {
  return Math.min(FRAME_COUNT - 1, Math.floor(clamp01(progress) * FRAME_COUNT));
}

/** Camera zoom for a progress value. Sine in-out: no hard start or stop, the push-in eases on and settles off. */
export function zoomAt(progress: number): number {
  const e = 0.5 - 0.5 * Math.cos(Math.PI * clamp01(progress));
  return 1 + (ZOOM_MAX - 1) * e;
}

/** Which rendition a canvas of this backing width needs: the sharpest zoom it can reach must not outgrow the file. */
export function tierFor(backingWidth: number): FrameTier {
  return backingWidth * ZOOM_MAX <= FRAME_WIDTHS.sm ? 'sm' : 'lg';
}

export type Frame = ImageBitmap | HTMLImageElement;

/** Paint one frame, zoomed about FOCAL, into a canvas whose backing store is `w` x `h` px. */
export function paintFrame(ctx: CanvasRenderingContext2D, frame: Frame, w: number, h: number, zoom: number) {
  const dw = w * zoom;
  const dh = h * zoom;
  const dx = w * FOCAL.x * (1 - zoom);
  const dy = h * FOCAL.y * (1 - zoom);

  ctx.globalCompositeOperation = 'source-over';
  ctx.clearRect(0, 0, w, h);
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';
  ctx.drawImage(frame, dx, dy, dw, dh);

  // Dissolve the photo's cropped lower edge. The gradient lives in the artwork's space, so the hem is dissolved at
  // every zoom (and leaves the window with the artwork as the camera pushes in).
  const g = ctx.createLinearGradient(0, dy, 0, dy + dh);
  for (const [at, alpha] of HEM_STOPS) g.addColorStop(at, `rgba(0,0,0,${1 - alpha})`);
  ctx.globalCompositeOperation = 'destination-out';
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, w, h);
  ctx.globalCompositeOperation = 'source-over';
}

/**
 * Loads and keeps the frames. Frames are decoded into ImageBitmaps where the browser can (a bitmap stays decoded,
 * where an <img>'s decoded pixels can be evicted under memory pressure and re-decoded in the middle of a paint).
 * `pick` never returns nothing once any frame is ready: it falls back to the nearest ready frame, so a fast scroll
 * over frames that are still arriving shows the closest pose instead of a blank.
 */
export class FrameBank {
  private sets: Record<FrameTier, Array<Frame | null>> = {
    sm: new Array(FRAME_COUNT).fill(null),
    lg: new Array(FRAME_COUNT).fill(null),
  };
  private started: Record<FrameTier, boolean> = { sm: false, lg: false };
  private disposed = false;

  constructor(private onFrame: () => void) {}

  /** Start loading a tier (once). In playback order, so frame 01 (the poster's twin) is the first to land. */
  load(tier: FrameTier) {
    if (this.started[tier] || this.disposed) return;
    this.started[tier] = true;
    FRAME_IDS.forEach((id, i) => {
      void this.fetchOne(tier, id, i);
    });
  }

  private async fetchOne(tier: FrameTier, id: string, i: number) {
    const img = new Image();
    img.decoding = 'async';
    img.src = frameUrl(id, tier);
    try {
      await img.decode();
    } catch {
      // decode() can reject for a frame that is fine (or on browsers that do not implement it): fall back to onload.
      const ok = await new Promise<boolean>((resolve) => {
        if (img.complete && img.naturalWidth > 0) resolve(true);
        else {
          img.onload = () => resolve(true);
          img.onerror = () => resolve(false);
        }
      });
      if (!ok) return;
    }
    let frame: Frame = img;
    if (typeof createImageBitmap === 'function') {
      try {
        frame = await createImageBitmap(img);
      } catch {
        frame = img;
      }
    }
    if (this.disposed) {
      if ('close' in frame) frame.close();
      return;
    }
    this.sets[tier][i] = frame;
    this.onFrame();
  }

  /** The best available frame for index `i`: the wanted tier first, then the other, nearest index first. */
  pick(i: number, tier: FrameTier): Frame | null {
    const other: FrameTier = tier === 'sm' ? 'lg' : 'sm';
    for (const t of [tier, other]) {
      const set = this.sets[t];
      if (set[i]) return set[i];
    }
    for (let d = 1; d < FRAME_COUNT; d++) {
      for (const t of [tier, other]) {
        const set = this.sets[t];
        const lo = set[i - d];
        if (lo) return lo;
        const hi = set[i + d];
        if (hi) return hi;
      }
    }
    return null;
  }

  /** True when frame `i` itself (not a stand-in) is decoded, in either tier. */
  ready(i: number) {
    return Boolean(this.sets.sm[i] || this.sets.lg[i]);
  }

  /** True once every frame of the tier is decoded. */
  complete(tier: FrameTier) {
    return this.sets[tier].every(Boolean);
  }

  dispose() {
    this.disposed = true;
    for (const t of ['sm', 'lg'] as const) {
      this.sets[t].forEach((f) => {
        if (f && 'close' in f) f.close();
      });
      this.sets[t].fill(null);
    }
  }
}
