/**
 * ISOLATED: Phylax scroll-driven colour morph (OKLab/OKLCH + contrast-aware token hand-over).
 * Extracted verbatim from lib/triggerTone.ts (colour maths) + lib/pricingMorph.ts (palette model).
 * Wiring: hooks/usePricingMorph.ts (GSAP ScrollTrigger -> one progress p -> CSS vars). See notes in chat.
 */

/* ======================= PART 1: colour maths (from triggerTone.ts) ======================= */
export type RGB = { r: number; g: number; b: number };

const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));

/* ---------- sRGB / OKLab maths ---------- */

const toLin = (c: number) => {
  const v = c / 255;
  return v <= 0.04045 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4;
};
const fromLin = (v: number) => 255 * (v <= 0.0031308 ? v * 12.92 : 1.055 * v ** (1 / 2.4) - 0.055);

export function luminance({ r, g, b }: RGB) {
  return 0.2126 * toLin(r) + 0.7152 * toLin(g) + 0.0722 * toLin(b);
}

export function contrast(a: RGB, b: RGB) {
  const la = luminance(a);
  const lb = luminance(b);
  return (Math.max(la, lb) + 0.05) / (Math.min(la, lb) + 0.05);
}

export function toOklch({ r, g, b }: RGB) {
  const R = toLin(r), G = toLin(g), B = toLin(b);
  const l = Math.cbrt(0.4122214708 * R + 0.5363325363 * G + 0.0514459929 * B);
  const m = Math.cbrt(0.2119034982 * R + 0.6806995451 * G + 0.1073969566 * B);
  const s = Math.cbrt(0.0883024619 * R + 0.2817188376 * G + 0.6299787005 * B);
  const L = 0.2104542553 * l + 0.793617785 * m - 0.0040720468 * s;
  const a = 1.9779984951 * l - 2.428592205 * m + 0.4505937099 * s;
  const bb = 0.0259040371 * l + 0.7827717662 * m - 0.808675766 * s;
  return { L, C: Math.hypot(a, bb), h: ((Math.atan2(bb, a) * 180) / Math.PI + 360) % 360 };
}

/** OKLCH -> sRGB. Chroma is reduced until the colour fits the sRGB gamut, so hue and lightness survive. */
export function fromOklch(L: number, C: number, h: number): RGB {
  const hr = (h * Math.PI) / 180;
  let c = C;
  for (let i = 0; i < 28; i++) {
    const a = c * Math.cos(hr), b = c * Math.sin(hr);
    const l = (L + 0.3963377774 * a + 0.2158037573 * b) ** 3;
    const m = (L - 0.1055613458 * a - 0.0638541728 * b) ** 3;
    const s = (L - 0.0894841775 * a - 1.291485548 * b) ** 3;
    const lin = [
      4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s,
      -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s,
      -0.0041960863 * l - 0.7034186147 * m + 1.707614701 * s,
    ];
    if (lin.every((v) => v >= -0.0005 && v <= 1.0005) || c < 0.0005) {
      return { r: fromLin(clamp(lin[0], 0, 1)), g: fromLin(clamp(lin[1], 0, 1)), b: fromLin(clamp(lin[2], 0, 1)) };
    }
    c *= 0.88;
  }
  const v = fromLin(clamp(L, 0, 1));
  return { r: v, g: v, b: v };
}

export const css = ({ r, g, b }: RGB) => `rgb(${Math.round(r)} ${Math.round(g)} ${Math.round(b)})`;

/* ======================= PART 2: palette model (from pricingMorph.ts) ======================= */
const PAPER: RGB = { r: 0xf5, g: 0xf1, b: 0xea }; // --cream  (Templates' background)
const INK: RGB = { r: 0x11, g: 0x11, b: 0x12 }; //   --ink    (Pricing's original background)
const CARD_LIGHT: RGB = { r: 0xe7, g: 0xe2, b: 0xd8 }; // Templates' tile surface (.helmet-visual)
const CARD_DARK: RGB = { r: 0x18, g: 0x19, b: 0x1b }; //  the site's dark card surface (.visual)

const hex = (n: number): RGB => ({ r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 });

interface Token {
  /** Colour used when the backdrop is cream-coloured (Templates theme). */
  onLight: RGB;
  /** Colour used when the backdrop is ink-coloured (Pricing's original theme). */
  onDark: RGB;
  /** How far (0..1) the colour may lean toward ink/cream at the crossover to stay separated from the backdrop. */
  pull: number;
}

const TOKENS = {
  fg: { onLight: INK, onDark: PAPER, pull: 1 },
  muted: { onLight: hex(0x4b4b4e), onDark: hex(0xd9d4ca), pull: 0.8 },
  // Accent is display-size text ("TILES", "FREE.") and decorative dots: it leans less, so it stays recognisably blue.
  accent: { onLight: hex(0x506b80), onDark: hex(0x7a93a8), pull: 0.6 },
} satisfies Record<string, Token>;

/** Text printed on the template tiles, which sit on their own surface rather than on the page background. */
const SURFACE_FG: Token = { onLight: INK, onDark: PAPER, pull: 1 };

/** Hairlines keep their original strengths (rgba(ink, .18) on cream, rgba(cream, .2) on ink). */
const LINE_ALPHA = { onLight: 0.18, onDark: 0.2 };

/**
 * Half-width of the hand-over, in morph progress (0..1). The whole hand-over spans 2 * SWAP_HALF_WIDTH of the scroll
 * range, so text drifts from dark to light over that whole stretch instead of flipping. Wider = gentler but a longer
 * stretch of mid-contrast; narrower = crisper but it starts to read as a snap (0.015 did).
 */
export const SWAP_HALF_WIDTH = 0.14;

const clamp01 = (v: number) => Math.min(1, Math.max(0, v));
/** Quintic smootherstep: C2-continuous, so neither the colour nor its rate of change jumps at either end. */
const smootherstep = (a: number, b: number, x: number) => {
  const t = clamp01((x - a) / (b - a));
  return t * t * t * (t * (t * 6 - 15) + 10);
};
const mixRgb = (a: RGB, b: RGB, t: number): RGB => ({ r: a.r + (b.r - a.r) * t, g: a.g + (b.g - a.g) * t, b: a.b + (b.b - a.b) * t });

/** The shared page background at progress p. Matches what the compositor draws for an ink layer at opacity p over cream. */
export const backgroundAt = (p: number): RGB => mixRgb(PAPER, INK, clamp01(p));
/** The tile surface at progress p. */
export const surfaceAt = (p: number): RGB => mixRgb(CARD_LIGHT, CARD_DARK, clamp01(p));

/** Progress at which black and white are equally legible on `backdrop` (luminance sqrt(1.05 * 0.05) - 0.05). */
function crossoverOf(backdrop: (p: number) => RGB): number {
  const target = Math.sqrt(1.05 * 0.05) - 0.05;
  let lo = 0, hi = 1;
  for (let i = 0; i < 30; i++) {
    const mid = (lo + hi) / 2;
    if (luminance(backdrop(mid)) > target) lo = mid; else hi = mid;
  }
  return (lo + hi) / 2;
}
const SWAP_POINT = crossoverOf(backgroundAt);
const SURFACE_SWAP_POINT = crossoverOf(surfaceAt);
export { SWAP_POINT };

/** Side of the hand-over: 0 = cream-theme colours, 1 = ink-theme colours. */
export const swapAt = (p: number, point = SWAP_POINT) => smootherstep(point - SWAP_HALF_WIDTH, point + SWAP_HALF_WIDTH, p);

/** Perceptual (OKLab) linear blend of two colours. */
function mixOklab(a: RGB, b: RGB, t: number): RGB {
  if (t <= 0) return a;
  if (t >= 1) return b;
  const A = toOklch(a), B = toOklch(b);
  const ax = A.C * Math.cos((A.h * Math.PI) / 180), ay = A.C * Math.sin((A.h * Math.PI) / 180);
  const bx = B.C * Math.cos((B.h * Math.PI) / 180), by = B.C * Math.sin((B.h * Math.PI) / 180);
  const x = ax + (bx - ax) * t, y = ay + (by - ay) * t;
  return fromOklch(A.L + (B.L - A.L) * t, Math.hypot(x, y), ((Math.atan2(y, x) * 180) / Math.PI + 360) % 360);
}

/**
 * A token's colour at progress p on a backdrop whose black/white crossover is `point`, with hand-over weight `s`.
 * p = 0 and p = 1 return the theme colours exactly (the ramps are 0 there and mixOklab short-circuits).
 */
function tokenAt(token: Token, p: number, s: number, point: number): RGB {
  const rampDown = smootherstep(0, point, p); //      0 at cream -> 1 at the crossover
  const rampUp = 1 - smootherstep(point, 1, p); //    1 at the crossover -> 0 at ink
  const pre = mixOklab(token.onLight, INK, rampDown * token.pull);
  const post = mixOklab(token.onDark, PAPER, rampUp * token.pull);
  return mixOklab(pre, post, s);
}

export interface MorphPalette {
  /** The one background both sections share. */
  bg: RGB;
  fg: RGB;
  muted: RGB;
  accent: RGB;
  /** Hairline colour, already flattened onto the background (so it can be used as an opaque `border-color`). */
  line: RGB;
  /** Template tile surface, and the text/bars printed on it. */
  surface: RGB;
  surfaceFg: RGB;
}

export function morphPalette(p: number): MorphPalette {
  p = clamp01(p);
  const bg = backgroundAt(p);
  const surface = surfaceAt(p);
  const s = swapAt(p);
  const fg = tokenAt(TOKENS.fg, p, s, SWAP_POINT);
  const alpha = LINE_ALPHA.onLight + (LINE_ALPHA.onDark - LINE_ALPHA.onLight) * s;
  return {
    bg,
    fg,
    muted: tokenAt(TOKENS.muted, p, s, SWAP_POINT),
    accent: tokenAt(TOKENS.accent, p, s, SWAP_POINT),
    line: mixRgb(bg, fg, alpha),
    surface,
    surfaceFg: tokenAt(SURFACE_FG, p, swapAt(p, SURFACE_SWAP_POINT), SURFACE_SWAP_POINT),
  };
}

export const rgbCss = ({ r, g, b }: RGB) => `rgb(${Math.round(r)} ${Math.round(g)} ${Math.round(b)})`;
