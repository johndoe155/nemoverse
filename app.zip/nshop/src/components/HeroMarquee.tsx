'use client';
import { memo, useEffect, useRef } from 'react';
import { createVacuumSwap } from '@/lib/vacuumSwap';

/** Every distinct item the bar can show. More items than visible slots, so there is always something to swap in. */
const ITEMS = [
  'BASE $25',
  'HOLO $25',
  'SPARKLE $25',
  'CRACKED ICE $30',
  'STAR $40',
  'FREE US SHIPPING',
  '$15 INTL FLAT',
  'BULK FROM $11/CARD',
  '7-12 DAYS TO SHIPPED',
] as const;

/**
 * Slot count per viewport. Must mirror BREAKPOINTS in src/lib/vacuumSwap.ts
 * (Tailwind sm 640 / lg 1024 / xl 1280 / 2xl 1536).
 * Written as full literals so Tailwind's scanner picks every class up.
 */
const SLOT_VISIBILITY = ['', '', 'max-sm:hidden', 'max-lg:hidden', 'max-xl:hidden', 'max-2xl:hidden'] as const;

export const HeroMarquee = memo(function HeroMarquee() {
  const rowRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const row = rowRef.current;
    if (!row) return;
    return createVacuumSwap(row, ITEMS);
  }, []);

  return (
    <div className="absolute bottom-0 left-0 right-0 border-y border-[#1A1A1A]">
      {/* Backdrop blur lives on its own sibling layer: the animated row above never sits inside a
          backdrop-filter element, so its per-frame compositor updates do not re-trigger the blur pass. */}
      <div aria-hidden="true" className="absolute inset-0 bg-[#0a0a0a]/80 backdrop-blur" />

      {/* The row is decorative motion; assistive tech gets the complete, static list instead. */}
      <ul className="sr-only">
        {ITEMS.map((txt) => (
          <li key={txt}>{txt}</li>
        ))}
      </ul>

      <div
        ref={rowRef}
        aria-hidden="true"
        className="relative flex items-center justify-center py-3 font-mono text-[10px] sm:text-[11px] tracking-widest tabular"
      >
        {SLOT_VISIBILITY.map((visibility, i) => (
          <div key={i} className={`flex items-center ${visibility}`}>
            {i > 0 && (
              // Two nested layers: the outer one is dragged by the slot on its left, the inner one by the slot on its right.
              <span className="vsw-bullet" data-vsw-bullet>
                <span className="vsw-drag" data-vsw-drag="a">
                  <span className="vsw-drag" data-vsw-drag="b" />
                </span>
              </span>
            )}
            <div className="vsw-slot" data-vsw-slot>
              <span className="vsw-cell" data-vsw-cell>
                {ITEMS[i]}
              </span>
              <span className="vsw-cell" data-vsw-cell style={{ visibility: 'hidden' }} />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
});
