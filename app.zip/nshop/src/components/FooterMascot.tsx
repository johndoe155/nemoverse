'use client';

import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { LETTER_DRAG_EVENT, type LetterDragDetail } from '@/lib/letterDrag';
import { FRAME_IDS, FRAME_ASPECT, FRAME_WIDTHS, FrameBank, frameIndexAt, frameUrl, paintFrame, tierFor, zoomAt, type FrameTier } from '@/lib/mascotScrub';

if (typeof window !== 'undefined') {
  gsap.registerPlugin(ScrollTrigger);
}

/**
 * Footer mascot: Nemo in the orange hoodie, standing in front of the "NEMO'S / VAULT" watermark.
 *
 * Rendered by FooterWatermark as the last child of the watermark root (see its `mascot` prop), so it lives in the
 * watermark's own coordinate space and rides the same scroll parallax: the two can never drift apart. All sizing
 * and placement is CSS (the `.fm*` block in globals.css, in the same vw units as the lettering, so the pair keeps
 * its proportions from phone to ultrawide). This file adds three behaviours on top:
 *
 *  - Scrub. Nemo is an eight-frame stop-motion (public/mascot/frames, 01 first, 08 last) driven directly by scroll:
 *    one ScrollTrigger runs from the moment his reveal fires (15% of his box on screen) to the end of the page (the
 *    footer is the last thing on it), and its 0..1 progress picks the frame (discrete steps, an equal eighth of the
 *    range each, no cross-fade) and the camera zoom (1 -> ZOOM_MAX about a focal point just above his head). Progress
 *    is the only input, so scrolling back plays the same frames and the same zoom in reverse, exactly. Frames are
 *    painted into one canvas (lib/mascotScrub.ts), clipped by `.fm-cam`, which dissolves its own edges so the
 *    crop never shows as a hard line. The canvas is invisible until it has painted; the first frame's <img> is the
 *    poster before that (and the whole thing under prefers-reduced-motion, where he simply stands there). Frame 01 is
 *    the original static footer mascot (cap on), registered to 02 on the eye line, so the poster, the reveal and the
 *    first step of the scrub are one picture, and the cap comes off without anything else moving.
 *  - Reveal. Once the mascot is on screen and its image has decoded, `data-state` flips from "pending" to "in" (set
 *    straight on the element, like FooterStamp's one-shot state, so there is no re-render) and the CSS does the
 *    rest: Nemo rises out of the footer on the site's soft ease-out while the warm glow behind him and the caption
 *    follow a beat later. Only opacity/transform ever move. It plays once; a decode that stalls never holds the
 *    reveal for more than REVEAL_TIMEOUT_MS.
 *  - Motion. One set of gsap.quickTo tweens on a wrapper of its own (so it composes with the reveal instead of
 *    fighting it), fed by whichever input the device has. Never both at once, and none under prefers-reduced-motion:
 *      Drift (mouse and pen): a very small, slow follow of the cursor, a few px of travel and about one degree of
 *        lean, pivoting on his base. Armed only while the mascot is on screen.
 *      Lean (touch only): while a finger is dragging a watermark letter he leans the way it is pulled, up to a few
 *        degrees, pivoting on his base, and eases back upright when it is released. The lean follows the letter's
 *        displacement as drawn (lib/letterDrag.ts publishes it), saturating smoothly (tanh) so a long pull never
 *        tips him over; several fingers add up, so opposite pulls cancel. Mouse drags do not lean him: a mouse has
 *        the cursor drift instead.
 *
 * The mascot never takes pointer events, so every letter under him stays draggable. The artwork is the transparent
 * cut-out in /public/mascot/frames (WebP with alpha, 800 and 1280 wide, one shared crop for all eight frames); his
 * lower edge is the photo's own crop, which is dissolved into the footer (a mask on the poster, the same stops
 * painted into the canvas, so it stays dissolved at every zoom).
 */

// The poster is frame 01 (cap on); the canvas plays the whole sequence, which ends with the cap off.
const ALT_POSTER = 'Nemo the penguin in a card-logo cap and orange hoodie';
const ALT_SCRUB = 'Nemo the penguin in an orange hoodie, taking off his card-logo cap';
const POSTER_SM = frameUrl(FRAME_IDS[0], 'sm');
const POSTER_LG = frameUrl(FRAME_IDS[0], 'lg');
/** Intrinsic size of the large rendition; reserves the box so nothing shifts while the file loads. */
const W = FRAME_WIDTHS.lg;
const H = Math.round(FRAME_WIDTHS.lg * FRAME_ASPECT);
/** Must mirror --fm-w in globals.css (58vw / 44vw from 768px / 36vw from 1280px). */
const SIZES = '(min-width: 1280px) 36vw, (min-width: 768px) 44vw, 58vw';

/** Pixel-ratio cap for the canvas: a 3x phone would paint 2.25x the pixels for no visible gain. */
const MAX_DPR = 2;
/** Start fetching the frames this far (in viewport heights) before the mascot can be on screen. */
const LOAD_MARGIN = '200% 0px';

/** Share of his box that must be on screen for the reveal to fire, and for the scrub to begin (so frame 01, the cap on, is the pose he rises in). */
const ON_SCREEN = 0.15;
const REVEAL_TIMEOUT_MS = 1200;
const DRIFT_X = 9; // px of travel at the screen edge
const DRIFT_Y = 5; // px
const DRIFT_LEAN = 1.1; // degrees
const DRIFT_SECONDS = 1.3;

// Touch lean. A pull of TOUCH_REACH x his width reaches ~76% of the maximum (tanh), so the response scales with him.
const TOUCH_REACH = 0.34;
const TOUCH_LEAN = 3.4; // degrees at full pull
const TOUCH_X = 12; // px
const TOUCH_Y = 6; // px

const clamp = (v: number, min: number, max: number) => Math.min(max, Math.max(min, v));

/** Document Y of an element's layout box (offsetTop ignores transforms, so the watermark's parallax never moves it). */
const layoutTop = (el: HTMLElement) => {
  let y = 0;
  for (let n: HTMLElement | null = el; n; n = n.offsetParent as HTMLElement | null) y += n.offsetTop;
  return y;
};

export function FooterMascot() {
  const rootRef = useRef<HTMLDivElement>(null);
  const driftRef = useRef<HTMLDivElement>(null);
  const imgRef = useRef<HTMLImageElement>(null);
  const camRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Scrub: scroll progress -> frame + camera zoom, painted into the canvas. Everything it starts is torn down on unmount.
  useEffect(() => {
    const root = rootRef.current;
    const cam = camRef.current;
    const canvas = canvasRef.current;
    if (!root || !cam || !canvas) return;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return; // the poster stays: no zoom, no stepping
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let progress = 0;
    let w = 0;
    let h = 0;
    let tier: FrameTier = 'sm';
    let near = false; // close enough to the viewport to start loading
    let raf = 0;
    let disposed = false;
    let painted = false;
    // What is on the canvas right now, so a repaint that would change nothing is skipped.
    let shown: { frame: unknown; zoom: number; w: number; h: number } | null = null;

    const paint = () => {
      raf = 0;
      if (disposed || !w) return;
      const index = frameIndexAt(progress);
      // The poster is frame 01 (the cap on). The canvas takes over from it only once the frame this scroll position
      // actually wants is decoded: a stand-in (the nearest ready frame) must never swap his cap off under the poster.
      if (!painted && !bank.ready(index)) return;
      const frame = bank.pick(index, tier);
      if (!frame) return; // nothing decoded yet: the poster is still showing
      const zoom = zoomAt(progress);
      if (shown && shown.frame === frame && shown.zoom === zoom && shown.w === w && shown.h === h) return;
      paintFrame(ctx, frame, w, h, zoom);
      shown = { frame, zoom, w, h };
      if (!painted) {
        painted = true;
        root.dataset.cam = 'on'; // poster out, canvas in, in the same commit
      }
    };
    const schedule = () => {
      if (!raf && !disposed) raf = requestAnimationFrame(paint);
    };
    const bank = new FrameBank(schedule);

    // Backing store follows the box (layout size, so the reveal's scale and the drift never feed back into it).
    const size = () => {
      const cssW = cam.clientWidth;
      if (!cssW) return;
      const dpr = Math.min(window.devicePixelRatio || 1, MAX_DPR);
      const nw = Math.round(cssW * dpr);
      const nh = Math.round(cam.clientHeight * dpr);
      if (nw !== w || nh !== h) {
        w = nw;
        h = nh;
        canvas.width = w; // resets the bitmap, so the next paint must not be skipped
        canvas.height = h;
        shown = null;
      }
      tier = tierFor(w);
      if (near) bank.load(tier);
      schedule();
    };

    const loader = new IntersectionObserver(
      (entries) => {
        if (!entries.some((e) => e.isIntersecting)) return;
        loader.disconnect();
        near = true;
        bank.load(tier);
      },
      { rootMargin: LOAD_MARGIN },
    );
    loader.observe(root);

    // The range: the moment the reveal fires (ON_SCREEN of his box above the bottom of the viewport) -> the end of the
    // page. Pixel positions, re-read on every refresh (resize, fonts changing the watermark's fit, pins above), so it
    // follows layout instead of caching it.
    const footer = root.closest('footer') ?? document.body;
    const start = () => Math.max(0, layoutTop(root) + root.offsetHeight * ON_SCREEN - window.innerHeight);
    const trigger = ScrollTrigger.create({
      trigger: footer,
      start,
      end: () => Math.max(start() + 1, ScrollTrigger.maxScroll(window)),
      onUpdate: (self) => {
        progress = self.progress;
        schedule();
      },
      onRefresh: (self) => {
        progress = self.progress;
        schedule();
      },
    });

    const watermark = root.closest<HTMLElement>('.wm-root');
    const resizeObserver = new ResizeObserver(() => {
      size();
      trigger.refresh();
    });
    resizeObserver.observe(cam);
    if (watermark) resizeObserver.observe(watermark);
    size();

    return () => {
      disposed = true;
      cancelAnimationFrame(raf);
      loader.disconnect();
      resizeObserver.disconnect();
      trigger.kill();
      bank.dispose();
      delete root.dataset.cam;
    };
  }, []);

  // Reveal: first time the mascot is on screen (and decoded), once.
  useEffect(() => {
    const root = rootRef.current;
    const img = imgRef.current;
    if (!root || !img) return;
    const reveal = () => {
      root.dataset.state = 'in';
    };
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      reveal(); // CSS has no transitions in this mode, so he simply appears
      return;
    }

    let disposed = false;
    let observer: IntersectionObserver | null = new IntersectionObserver(
      (entries) => {
        if (!entries.some((e) => e.isIntersecting)) return;
        observer?.disconnect();
        observer = null;
        const decoded = typeof img.decode === 'function' ? img.decode().catch(() => {}) : Promise.resolve();
        const timeout = new Promise<void>((resolve) => window.setTimeout(resolve, REVEAL_TIMEOUT_MS));
        void Promise.race([decoded, timeout]).then(() => {
          if (!disposed) reveal();
        });
      },
      { threshold: ON_SCREEN },
    );
    observer.observe(root);

    return () => {
      disposed = true;
      observer?.disconnect();
    };
  }, []);

  // Motion: cursor drift on fine pointers, letter-drag lean for fingers. Both write the same three tweens.
  useEffect(() => {
    const root = rootRef.current;
    const drift = driftRef.current;
    if (!root || !drift) return;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

    const opts = { duration: DRIFT_SECONDS, ease: 'power3.out' };
    const xTo = gsap.quickTo(drift, 'x', opts);
    const yTo = gsap.quickTo(drift, 'y', opts);
    const rTo = gsap.quickTo(drift, 'rotation', opts);
    const settle = () => {
      xTo(0);
      yTo(0);
      rTo(0);
    };

    // Letters currently held by a finger, with their displacement from home.
    const held = new Map<number, { x: number; y: number }>();

    // Touch lean: lean toward the summed pull of every held letter, upright again once none is held.
    const lean = () => {
      let sx = 0;
      let sy = 0;
      held.forEach((p) => {
        sx += p.x;
        sy += p.y;
      });
      const pull = Math.hypot(sx, sy);
      if (pull < 0.5) {
        settle();
        return;
      }
      const m = Math.tanh(pull / (root.offsetWidth * TOUCH_REACH));
      const ux = sx / pull;
      const uy = sy / pull;
      xTo(ux * m * TOUCH_X);
      yTo(uy * m * TOUCH_Y);
      rTo(ux * m * TOUCH_LEAN);
    };
    const onLetterDrag = (e: Event) => {
      const d = (e as CustomEvent<LetterDragDetail>).detail;
      if (d.pointerType !== 'touch') return;
      if (d.active) held.set(d.i, { x: d.x, y: d.y });
      else held.delete(d.i);
      lean();
    };
    const watermark = root.closest<HTMLElement>('.wm-root');
    watermark?.addEventListener(LETTER_DRAG_EVENT, onLetterDrag);

    // Cursor drift: fine pointers only (a touch screen has no cursor to follow).
    let observer: IntersectionObserver | null = null;
    let onMove: ((e: PointerEvent) => void) | null = null;
    if (!window.matchMedia('(pointer: coarse)').matches) {
      let onScreen = false;
      observer = new IntersectionObserver(
        ([entry]) => {
          onScreen = entry.isIntersecting;
          if (!onScreen) settle();
        },
        { threshold: 0 },
      );
      observer.observe(root);

      onMove = (e: PointerEvent) => {
        if (!onScreen || e.pointerType === 'touch' || held.size > 0) return;
        const r = root.getBoundingClientRect();
        const nx = clamp((e.clientX - (r.left + r.width / 2)) / (window.innerWidth / 2), -1, 1);
        const ny = clamp((e.clientY - (r.top + r.height / 2)) / (window.innerHeight / 2), -1, 1);
        xTo(nx * DRIFT_X);
        yTo(ny * DRIFT_Y);
        rTo(nx * DRIFT_LEAN);
      };
      window.addEventListener('pointermove', onMove, { passive: true });
      document.documentElement.addEventListener('pointerleave', settle);
      window.addEventListener('blur', settle);
    }

    return () => {
      watermark?.removeEventListener(LETTER_DRAG_EVENT, onLetterDrag);
      observer?.disconnect();
      if (onMove) {
        window.removeEventListener('pointermove', onMove);
        document.documentElement.removeEventListener('pointerleave', settle);
        window.removeEventListener('blur', settle);
      }
      gsap.killTweensOf(drift);
    };
  }, []);

  return (
    <div ref={rootRef} data-state="pending" className="fm">
      <div aria-hidden="true" className="fm-glow" />
      <div ref={driftRef} className="fm-drift">
        <div className="fm-rise">
          {/* The camera window: clips the push-in and dissolves its own edges (see .fm-cam). The poster reserves the
              box (width/height) and is what shows until the canvas has painted; the canvas covers it exactly. */}
          <div ref={camRef} className="fm-cam">
            <img
              ref={imgRef}
              src={POSTER_LG}
              srcSet={`${POSTER_SM} ${FRAME_WIDTHS.sm}w, ${POSTER_LG} ${FRAME_WIDTHS.lg}w`}
              sizes={SIZES}
              width={W}
              height={H}
              alt={ALT_POSTER}
              loading="lazy"
              decoding="async"
              draggable={false}
              className="fm-img fm-poster"
            />
            <canvas ref={canvasRef} role="img" aria-label={ALT_SCRUB} className="fm-canvas" />
          </div>
        </div>
      </div>
      {/* Specimen caption, in the same mono voice as the footer's other micro-labels. Decorative; hidden on phones. */}
      <div aria-hidden="true" className="fm-tag">
        <span className="fm-tag-dot" />
        <span>NEMO</span>
        <span className="fm-tag-rule" />
        <span>VAULT KEEPER</span>
      </div>
    </div>
  );
}
