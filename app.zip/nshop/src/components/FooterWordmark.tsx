'use client';

import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

/**
 * Footer wordmark, scroll-scrubbed.
 *
 * public/logo-wordmark-animated.svg animates with SMIL (<animateTransform>, one 12.6 s loop). SMIL has no
 * CSS/WAAPI handle and an <img> SVG is a sealed document that self-plays, so the file is fetched and inlined,
 * its timeline is paused, and a ScrollTrigger moves the playhead with `svg.setCurrentTime()`. Nothing in here
 * ever plays on a clock: the animation only moves when the page scrolls.
 *
 * Behaviour
 *  - 0%   the wordmark enters the viewport (top of the wordmark meets the bottom of the screen): the logo is
 *         at rest, frame 0.
 *  - 0-100%  scrolling down advances it, scrolling up reverses it, 1:1 with scroll distance.
 *  - 100% the end of the page (the bottom of the footer), or, if the window is so short that the logo would
 *         leave the top of the screen first, the moment its bottom edge reaches 10% down the screen. The max
 *         progress reached is tracked; the moment it hits 100% the end state is locked for the session and
 *         the ScrollTrigger is killed, so scrolling back up can never reset or reverse it.
 *  - prefers-reduced-motion: render the finished state straight away, no ScrollTrigger at all.
 *
 * Scroll is shared with Lenis (Providers.tsx calls ScrollTrigger.update() on every Lenis tick), which is why
 * this uses the project's ScrollTrigger rather than its own scroll listener: same clock, and positions are
 * re-measured by the ScrollTrigger.refresh() calls the Gallery makes as the page settles.
 */

const SRC = '/logo-wordmark-animated.svg';
/** Plain static wordmark, only shown if the animated file cannot be loaded. */
const FALLBACK_SRC = '/logo-wordmark.svg';
const LABEL = "NEMO'S CARD SHOP";

/** `dur` of the SMIL loop in the SVG; re-read from the file once it is loaded. */
const DEFAULT_DUR = 12.6;
/**
 * The part of the loop in which anything visibly moves, as fractions of the loop. Measured from the SVG's
 * keyTimes: the first letter starts shaking at 0.087 and the last settles by 0.862; before and after that the
 * logo sits at rest. Scrubbing only this window means no scroll distance is wasted on dead time, and 0% and
 * 100% are both the clean resting frame. Update these two numbers if the SVG is ever re-exported.
 */
const MOTION_START = 0.085;
const MOTION_END = 0.8625;
/** Progress at/above which the run counts as complete (absorbs sub-pixel scroll rounding at page end). */
const LOCK_AT = 0.998;

/**
 * Set once the run has completed. Module scope on purpose: it outlives remounts (StrictMode, client-side
 * navigation) so a finished wordmark stays finished for the whole session. A full page reload starts over.
 */
let completed = false;

export function FooterWordmark({ className = '' }: { className?: string }) {
  const hostRef = useRef<HTMLDivElement>(null);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    const host = hostRef.current;
    if (!host) return;
    gsap.registerPlugin(ScrollTrigger); // idempotent; Providers.tsx has already done it

    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)');

    let disposed = false;
    let svg: SVGSVGElement | null = null;
    let dur = DEFAULT_DUR;
    let seeked = -1; // last playhead position written, to skip redundant seeks
    let progress = 0; // latest scroll progress, 0..1
    let maxProgress = completed ? 1 : 0; // furthest progress reached so far
    let trigger: ScrollTrigger | null = null;
    let observer: IntersectionObserver | null = null;

    /** Move the SMIL playhead to scroll progress p (0..1). */
    const seek = (p: number) => {
      if (!svg) return;
      const t = (MOTION_START + p * (MOTION_END - MOTION_START)) * dur;
      if (t === seeked) return;
      seeked = t;
      svg.setCurrentTime(t);
    };

    /** Freeze on the finished frame for good and detach the scroll listener. */
    const lock = () => {
      completed = true;
      maxProgress = 1;
      if (trigger) {
        trigger.kill();
        trigger = null;
      }
      seek(1);
    };

    const onScrollProgress = (p: number) => {
      progress = p;
      if (completed) return;
      if (p > maxProgress) maxProgress = p;
      if (maxProgress >= LOCK_AT) {
        lock();
        return;
      }
      seek(p);
    };

    /** What the SVG should show right now. */
    const render = () => {
      if (completed || reduceMotion.matches) seek(1);
      else seek(progress);
    };

    const load = async () => {
      try {
        const res = await fetch(SRC);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const doc = new DOMParser().parseFromString(await res.text(), 'image/svg+xml');
        const root = doc.documentElement;
        if (root.nodeName.toLowerCase() !== 'svg' || doc.querySelector('parsererror')) {
          throw new Error('not an SVG');
        }
        if (disposed) return;

        // Own, static asset, but never inline anything executable or embedded.
        root.querySelectorAll('script, foreignObject, metadata').forEach((n) => n.remove());

        const el = document.importNode(root, true) as unknown as SVGSVGElement;
        el.removeAttribute('width');
        el.removeAttribute('height');
        el.setAttribute('preserveAspectRatio', 'xMaxYMid meet'); // sits right, like object-right did
        el.setAttribute('aria-hidden', 'true'); // the host carries the accessible name
        el.style.cssText = 'display:block;width:100%;height:100%';

        host.replaceChildren(el);
        // SMIL starts its clock the instant the SVG is inserted. Pause in the same task, before any paint,
        // so not a single frame autoplays.
        el.pauseAnimations();

        const d = parseFloat(el.querySelector('animateTransform')?.getAttribute('dur') ?? '');
        dur = Number.isFinite(d) && d > 0 ? d : DEFAULT_DUR;
        svg = el;
        render();
      } catch {
        if (!disposed) setFailed(true);
      }
    };

    const onMotionPreferenceChange = () => {
      if (reduceMotion.matches) lock();
    };

    if (reduceMotion.matches) {
      // Finished state immediately, and no scroll machinery at all.
    } else if (!completed) {
      trigger = ScrollTrigger.create({
        trigger: host,
        start: 'top bottom', // wordmark enters the screen -> 0%
        // Footer is the last thing on the page, so the max scroll position is the end of the footer -> 100%.
        // Re-evaluated on every refresh, so late layout changes are picked up. Capped so the run always
        // finishes while the logo is still on screen.
        end: () => {
          const logoBottom = host.getBoundingClientRect().bottom + window.scrollY;
          return Math.min(ScrollTrigger.maxScroll(window), logoBottom - window.innerHeight * 0.1);
        },
        onUpdate: (self) => onScrollProgress(self.progress),
        onRefresh: (self) => onScrollProgress(self.progress), // layout moved: re-sync
      });
    }
    reduceMotion.addEventListener('change', onMotionPreferenceChange);

    // The file is ~150 KB: fetch it when the footer is within reach instead of at page load, where it would
    // compete with the WebGL assets. The ScrollTrigger is already live, so whatever progress exists by the
    // time it arrives is applied by render().
    observer = new IntersectionObserver(
      (entries) => {
        if (!entries.some((e) => e.isIntersecting)) return;
        observer?.disconnect();
        observer = null;
        void load();
      },
      { rootMargin: '1500px 0px' },
    );
    observer.observe(host);

    return () => {
      disposed = true;
      observer?.disconnect();
      reduceMotion.removeEventListener('change', onMotionPreferenceChange);
      if (trigger) trigger.kill();
    };
  }, []);

  return (
    <div
      ref={hostRef}
      role="img"
      aria-label={LABEL}
      // 5:1 box (= the SVG's 200x40 viewBox) is reserved up front, so the swap-in never shifts layout.
      className={`block min-w-0 aspect-[5/1] ${className}`}
    >
      {failed && <img src={FALLBACK_SRC} alt="" className="w-full h-full object-contain object-right" />}
    </div>
  );
}
