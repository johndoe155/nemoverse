'use client';
import { useCallback, useEffect, useRef, useState } from 'react';
import { useVaultStore } from '@/store/useVaultStore';
import { MagneticButton } from './ui/MagneticButton';
import { NemoMark } from './ui/NemoMark';
import { useHeroGate } from '@/lib/heroGate';
import { smoothScrollToY } from '@/lib/smoothScroll';

// N-mark spin: one full turn, gentle at both ends with a pronounced mid-turn surge (peak angular speed ~3.3x the
// average), so it reads as a deliberate, fluid flick instead of a snap or a linear spin.
const SPIN_DURATION_MS = 700;
const SPIN_EASING = 'cubic-bezier(0.7, 0, 0.3, 1)';

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const cartCount = useVaultStore((s) => s.cartCount);
  const setCursor = useVaultStore((s) => s.setCursor);

  // Adaptive inversion stays off (baseline brand colours) until the hero is fully behind the sticky elements.
  useHeroGate();

  const markRef = useRef<SVGSVGElement>(null);
  const spinRef = useRef<Animation | null>(null); // non-null while a spin is running: the "ignore extra clicks" lock
  const ctaRef = useRef<HTMLDivElement>(null);
  const trackRef = useRef<HTMLButtonElement>(null);

  // Keep the track button glued to the CTA's left edge as the CTA's width changes (cart badge, font load). DOM write only.
  useEffect(() => {
    const cta = ctaRef.current;
    const track = trackRef.current;
    if (!cta || !track) return;
    const sync = () => track.style.setProperty('--cta-w', `${cta.offsetWidth}px`);
    sync();
    const ro = new ResizeObserver(sync);
    ro.observe(cta);
    return () => ro.disconnect();
  }, []);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  /** Eased scroll to the hero's top. The fixed header overlays the hero (which pads itself clear of it), so the only
   *  offset to honour is whatever `scroll-margin-top` the hero declares (0 by default). */
  const scrollToHero = useCallback(() => {
    const hero = document.querySelector<HTMLElement>('[data-hero]');
    const y = hero
      ? hero.getBoundingClientRect().top + window.scrollY - (parseFloat(getComputedStyle(hero).scrollMarginTop) || 0)
      : 0;
    smoothScrollToY(Math.max(0, y));
  }, []);

  /** N click: spin ONLY the glyph <svg> (transform-only, so no layout/reflow; the wrapper, wordmark and the blended
   *  tile are untouched), and start the scroll strictly after the turn has finished. */
  const onMarkClick = useCallback(() => {
    if (spinRef.current) return; // a spin is already running: ignore (no stacked / overlapping spins)

    const mark = markRef.current;
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (!mark || reduceMotion || typeof mark.animate !== 'function') {
      scrollToHero(); // reduced motion (or no WAAPI): skip the spin, scroll right away
      return;
    }

    const spin = mark.animate(
      [{ transform: 'rotate(0deg)' }, { transform: 'rotate(360deg)' }],
      { duration: SPIN_DURATION_MS, easing: SPIN_EASING, fill: 'none' }
    );
    spinRef.current = spin;
    spin.onfinish = () => {
      spinRef.current = null; // reset the lock, then hand over to the scroll
      scrollToHero();
    };
    spin.oncancel = () => {
      spinRef.current = null;
    };
  }, [scrollToHero]);

  // If the navbar unmounts mid-spin, drop the animation without firing the scroll.
  useEffect(
    () => () => {
      const spin = spinRef.current;
      if (spin) {
        spin.onfinish = null;
        spin.cancel();
      }
    },
    []
  );

  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <>
      {/*
        Adaptive sticky elements (N tile + "Start Forging"): colour comes from `mix-blend-mode: difference`, the same
        mechanism as Phylax's header logo / menu trigger. The compositor inverts whatever is behind them per pixel, every
        frame, so any element (DOM, image, video, WebGL canvas) is covered with zero JS and zero lag.
        A blend only sees siblings in the SAME stacking context, so each blended element is a direct `fixed` child of the
        page root, never nested in another fixed/z-indexed/transformed wrapper.
      */}

      {/* N tile - blended (cream -> inverse of the page). The orange glyph sits above it, un-blended. */}
      <div aria-hidden="true" className="tone-blend tone-tile fixed z-50 top-4 left-4 md:top-6 md:left-6 w-10 h-10 pointer-events-none" />

      {/* Logo: glyph + wordmark (interactive, un-blended) */}
      <div
        className="fixed z-[52] top-4 left-4 md:top-6 md:left-6 flex items-center gap-3 group cursor-none"
        onMouseEnter={() => setCursor(true, 'HOME')}
        onMouseLeave={() => setCursor(false)}
        onClick={onMarkClick}
      >
        <div className="w-10 h-10 grid place-items-center p-1.5">
          <NemoMark ref={markRef} className="w-full h-full" />
        </div>
        <div className="hidden md:block leading-none">
          <div className="font-display font-black text-[16px] tracking-tight">NEMO'S</div>
          <div className="font-mono text-[9px] tracking-[0.2em] opacity-60 -mt-1">CARD SHOP • EST 2023</div>
        </div>
      </div>

      {/* Center nav - desktop */}
      <nav className={`hidden lg:flex fixed z-50 top-4 md:top-6 left-1/2 -translate-x-1/2 items-center gap-1 p-1 rounded-full transition-all duration-500 ${scrolled ? 'bg-[#1A1A1A]/80 backdrop-blur-xl border border-[#2A2A2A]' : 'bg-transparent'}`}>
        {[
          { label: 'Gallery', id: 'gallery' },
          { label: 'How It Works', id: 'how' },
          { label: 'Forge', id: 'forge' },
          { label: 'Partnerships', id: 'partnerships' },
        ].map((item) => (
          <button
            key={item.id}
            onClick={() => scrollTo(item.id)}
            className="nav-link px-5 py-2 text-[11px] font-bold tracking-widest uppercase text-[#F5F3EF]/70 hover:text-[#F5F3EF] hover:bg-white/5 rounded-full transition-colors cursor-none"
            onMouseEnter={() => setCursor(true, 'GO')}
            onMouseLeave={() => setCursor(false)}
          >
            {item.label}
          </button>
        ))}
      </nav>

      {/* Track button: sits left of the CTA; --cta-w is kept in sync with the CTA's width by a ResizeObserver (no React state) */}
      <button
        ref={trackRef}
        onClick={() => scrollTo('status')}
        style={{ right: 'calc(1.5rem + var(--cta-w, 9.5rem) + 0.5rem)' }}
        className="nav-link hidden md:flex fixed z-50 top-6 w-10 h-10 bg-[#1A1A1A] border border-[#2A2A2A] text-[#F5F3EF] items-center justify-center font-mono text-[10px] hover:border-[#FF4D00]/50 transition-colors cursor-none"
        onMouseEnter={() => setCursor(true, 'TRACK')}
        onMouseLeave={() => setCursor(false)}
      >
        ◍
      </button>

      {/* "Start Forging": the fixed wrapper is the blended group (fill + knocked-out label, see globals.css) */}
      <div ref={ctaRef} className="tone-blend fixed z-50 top-[18px] right-4 md:top-[26px] md:right-6 flex">
        <MagneticButton variant="adaptive" size="sm" onClick={() => scrollTo('forge')}>
          Start Forging
          {cartCount > 0 && <span className="ml-2 w-5 h-5 bg-[#FF4D00] text-white rounded-full grid place-items-center text-[10px]">{cartCount}</span>}
        </MagneticButton>
      </div>

      {/* Vertical rails */}
      <div className="fixed left-0 top-0 bottom-0 z-40 hidden xl:flex flex-col justify-between py-24 px-4 pointer-events-none">
        <div className="vertical-rail">SCROLL — EXPLORE THE VAULT</div>
        <div className="vertical-rail">TOUCH GRASS. TOUCH SLABS.</div>
      </div>
      <div className="fixed right-0 top-0 bottom-0 z-40 hidden xl:flex flex-col justify-between py-24 px-4 pointer-events-none">
        <div className="vertical-rail">NEMO'S CARD SHOP ©2024</div>
        <div className="vertical-rail">BUILT FOR COLLECTORS • BY COLLECTORS</div>
      </div>
    </>
  );
}
