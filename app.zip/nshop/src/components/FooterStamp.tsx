'use client';

import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

/**
 * Footer "N" stamp, scroll-scrubbed.
 *
 * The finished stamp is exactly what the footer always rendered: 1px orange outline, cream tile, the plain
 * /logo-mark-orange.svg inside it, and the solid orange corner square. This component does not restyle any of
 * that. The markup and classes below are the original ones, so the CSS stays the single source of truth for the
 * end state. While the run is live it only layers inline overrides on top (transparent border/fill, a transform on
 * the corner, an SVG trail); locking in removes every override and the untouched CSS takes over again.
 *
 * Scrub range (a short one, so the rest of the footer stays the focus): from the stamp's bottom edge reaching
 * the bottom of the screen (0%) to it reaching 70% down the screen (100%), i.e. 30% of a viewport height.
 *
 *  - 0%    only the plain mark is visible: no outline, no fill, no corner square.
 *  - A     corner square POPS in (scale 0 -> 1 with a small overshoot, never an opacity fade).
 *  - B     the square travels the full outline and an orange trail is drawn behind it, ending back on its
 *          resting spot as the outline closes. The path is derived from where the CSS puts the square (it
 *          starts at whichever tile corner it sits in and runs clockwise), so nothing here hard-codes that.
 *  - C     the cream fill fades from 0 to 100%.
 *  - Between 0 and 100% it is fully bidirectional: scrolling up steps back through the phases.
 *  - At 100% it locks for the session (module flag + ScrollTrigger killed): scrolling up, resizing or any other
 *    event cannot reverse or replay it. A full page reload starts over.
 *  - prefers-reduced-motion: nothing is overridden at all, so the finished stamp simply shows. No scrubbing.
 *
 * Like FooterWordmark this uses the project's ScrollTrigger (Providers.tsx feeds it from Lenis on every tick),
 * so it shares the page's scroll clock and is re-measured by the same ScrollTrigger.refresh() calls.
 *
 * Renders a fragment: the parent keeps the `relative` wrapper (which is also the magnetic target in Footer),
 * so the tile, trail and corner still move together.
 */

/** Phase boundaries as fractions of the scrub range. */
const POP_END = 0.12; // A: 0 -> POP_END
const DRAW_END = 0.72; // B: POP_END -> DRAW_END, then C: DRAW_END -> 1
/** Progress at/above which the run counts as complete (absorbs sub-pixel scroll rounding). */
const LOCK_AT = 0.998;

const clamp01 = (v: number) => Math.min(1, Math.max(0, v));
/** Overshoots ~13% and settles on 1. Reads as a pop. */
const easeOutBack = (t: number) => {
  const c = 2;
  const u = t - 1;
  return 1 + (c + 1) * u ** 3 + c * u ** 2;
};
/** Gentle start and stop, so the square glides round the outline. */
const easeInOutSine = (t: number) => -(Math.cos(Math.PI * t) - 1) / 2;

/**
 * Set once the run has completed. Module scope on purpose: it outlives remounts (StrictMode, client-side
 * navigation) so a finished stamp stays finished for the whole session.
 */
let completed = false;

export function FooterStamp() {
  const tileRef = useRef<HTMLDivElement>(null);
  const trailRef = useRef<SVGSVGElement>(null);
  const pathRef = useRef<SVGPathElement>(null);
  const cornerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const tile = tileRef.current;
    const trail = trailRef.current;
    const path = pathRef.current;
    const corner = cornerRef.current;
    if (!tile || !trail || !path || !corner) return;
    gsap.registerPlugin(ScrollTrigger); // idempotent; Providers.tsx has already done it

    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
    if (reduceMotion.matches) completed = true; // finished design straight away, nothing to scrub
    if (completed) return;

    let trigger: ScrollTrigger | null = null;
    let verts: Array<[number, number]> = []; // outline corners, clockwise, starting at the square's own corner
    let lastP = -1;

    /** Read the tile/outline geometry and the square's resting corner from the live layout. */
    const measure = () => {
      const size = tile.offsetWidth;
      if (!size) return;
      const bw = parseFloat(getComputedStyle(tile).borderTopWidth) || 1;
      const lo = bw / 2; // the outline is stroked on the centre line of the border
      const hi = size - bw / 2;
      const ring: Array<[number, number]> = [[lo, lo], [hi, lo], [hi, hi], [lo, hi]]; // TL, TR, BR, BL (clockwise)
      const right = corner.offsetLeft + corner.offsetWidth / 2 > size / 2;
      const bottom = corner.offsetTop + corner.offsetHeight / 2 > size / 2;
      const first = bottom ? (right ? 2 : 3) : right ? 1 : 0;
      verts = [0, 1, 2, 3].map((k) => ring[(first + k) % 4]);
      const [x0, y0] = verts[0];
      trail.setAttribute('viewBox', `0 0 ${size} ${size}`);
      path.setAttribute('stroke-width', String(bw));
      path.setAttribute('d', `M${verts.map(([x, y]) => `${x} ${y}`).join('L')}L${x0} ${y0}`);
      lastP = -1; // geometry changed: force the next render to redraw
    };

    /** Point at fraction s (0..1) of the way round the outline. s = 1 lands exactly back on verts[0]. */
    const pointAt = (s: number): [number, number] => {
      const t = clamp01(s) * 4;
      const k = Math.min(Math.floor(t), 3);
      const f = t - k;
      const [ax, ay] = verts[k];
      const [bx, by] = verts[(k + 1) % 4];
      return [ax + (bx - ax) * f, ay + (by - ay) * f];
    };

    /** Draw the stamp for scroll progress p (0..1). Pure function of p, which is what makes it scrub both ways. */
    const render = (p: number) => {
      if (p === lastP || verts.length < 4) return;
      lastP = p;
      const pop = clamp01(p / POP_END);
      const draw = clamp01((p - POP_END) / (DRAW_END - POP_END));
      const fill = clamp01((p - DRAW_END) / (1 - DRAW_END));

      const s = easeInOutSine(draw);
      const [x, y] = pointAt(s);
      const [x0, y0] = verts[0];
      // Offsets are relative to the square's CSS position, so 0 and 1 both land exactly where the CSS put it.
      corner.style.transform = `translate3d(${x - x0}px, ${y - y0}px, 0) scale(${easeOutBack(pop)})`;
      path.style.strokeDasharray = `${s} 2`; // pathLength is 1, so this draws the first s of the outline
      tile.style.backgroundColor =
        fill > 0 ? `color-mix(in srgb, var(--paper) ${fill * 100}%, transparent)` : 'transparent';
    };

    /** Hand everything back to the stylesheet for good and detach the scroll listener. */
    const lock = () => {
      completed = true;
      if (trigger) {
        trigger.kill();
        trigger = null;
      }
      tile.style.removeProperty('border-color');
      tile.style.removeProperty('background-color');
      trail.style.removeProperty('display');
      corner.style.removeProperty('transform');
      corner.style.removeProperty('will-change');
    };

    const onProgress = (p: number) => {
      if (completed) return;
      if (p >= LOCK_AT) {
        // A measurement taken before the page layout settled can read as "past the range" while the stamp is
        // still below the fold. Don't let that lock the run early; the next refresh re-measures.
        if (tile.getBoundingClientRect().top > window.innerHeight) return;
        lock();
        return;
      }
      render(p);
    };

    const onMotionPreferenceChange = () => {
      if (reduceMotion.matches) lock();
    };

    // Take over from the static CSS: plain mark only (outline + fill hidden, square scaled to 0).
    tile.style.borderColor = 'transparent'; // keeps the 1px border box, so the mark does not shift
    trail.style.display = 'block';
    corner.style.willChange = 'transform';
    measure();
    render(0);

    trigger = ScrollTrigger.create({
      trigger: tile,
      start: 'clamp(bottom bottom)', // whole stamp has just entered the screen -> 0%
      end: 'clamp(bottom 70%)', // 30% of a viewport height later -> 100% (clamped so it can always finish)
      onUpdate: (self) => onProgress(self.progress),
      onRefresh: (self) => {
        measure();
        onProgress(self.progress); // layout moved: re-sync
      },
    });
    onProgress(trigger.progress);
    reduceMotion.addEventListener('change', onMotionPreferenceChange);

    return () => {
      reduceMotion.removeEventListener('change', onMotionPreferenceChange);
      if (trigger) trigger.kill();
    };
  }, []);

  return (
    <>
      <div
        ref={tileRef}
        className="w-12 h-12 border border-[#FF4D00] bg-[#F5F3EF] grid place-items-center p-1.5"
      >
        <img src="/logo-mark-orange.svg" alt="Nemo's" draggable={false} className="w-full h-full object-contain select-none" />
      </div>
      {/* Outline trail: hidden (display:none) in the finished state, where the tile's own border is the outline. */}
      <svg
        ref={trailRef}
        aria-hidden="true"
        focusable="false"
        viewBox="0 0 48 48"
        className="hidden absolute inset-0 w-full h-full overflow-visible pointer-events-none"
      >
        <path ref={pathRef} d="" pathLength={1} fill="none" style={{ stroke: 'var(--orange)', strokeDasharray: '0 2' }} />
      </svg>
      <div ref={cornerRef} aria-hidden="true" className="absolute -bottom-0.5 -right-0.5 w-1.5 h-1.5 bg-[#FF4D00]" />
    </>
  );
}
