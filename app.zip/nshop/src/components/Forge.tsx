'use client';
import { useState, useEffect, useRef } from 'react';
import gsap from 'gsap';
import { useVaultStore, FinishType, SlabType, BaseSubFinish } from '@/store/useVaultStore';
import { MagneticButton } from './ui/MagneticButton';
import { SlabFrame } from './ui/SlabFrame';
import { fetchNFT, DEMO_NFTS } from '@/lib/utils';
import { sounds } from '@/lib/sounds';
import { ForgePreviewCanvas } from './canvas/ForgePreview';
import dynamic from 'next/dynamic';

// Dynamically import to avoid SSR issues with Three
const ForgePreview = dynamic(() => Promise.resolve(ForgePreviewCanvas), { ssr: false });

const finishes: { id: FinishType; label: string; price: string; desc: string; shader: string }[] = [
  { id: 'base', label: 'Base', price: '$25', desc: 'Matte, clean, grail-ready', shader: 'Matte • No foil' },
  { id: 'holo', label: 'Holo', price: '$25', desc: 'Rainbow foil, light-reactive', shader: 'Liquid ripple + rainbow' },
  { id: 'sparkle', label: 'Sparkle', price: '$25', desc: 'Glitter dots, tilt-twinkle', shader: 'Dot matrix + glints' },
  { id: 'cracked-ice', label: 'Cracked Ice', price: '$30', desc: 'Fractured, icy, 1/1 energy', shader: 'Voronoi + prism flakes' },
  { id: 'star', label: 'Star', price: '$40', desc: 'Angular foil flakes, vault tier', shader: 'Shards + hot flash' },
];

// Final pricing (client-approved anchors, extended):
// Singles in standard slab: Base $20 • Holo $25 • Sparkle $25 • Cracked Ice $30 • Star $40.
// Bulk auto-applies per card at 10/25/50/100+; slab upgrades (+$15/+$40) add on
// top of the per-card rate at any quantity.
const SINGLE_PRICE: Record<FinishType, number> = { base: 25, holo: 25, sparkle: 25, 'cracked-ice': 30, star: 40 };
const BULK_TIERS: { min: number; price: Record<FinishType, number> }[] = [
  { min: 100, price: { base: 11, holo: 15, sparkle: 15, 'cracked-ice': 18, star: 24 } },
  { min: 50, price: { base: 13, holo: 17, sparkle: 17, 'cracked-ice': 20, star: 27 } },
  { min: 25, price: { base: 15, holo: 19, sparkle: 19, 'cracked-ice': 23, star: 30 } },
  { min: 10, price: { base: 17, holo: 21, sparkle: 21, 'cracked-ice': 25, star: 34 } },
];

// Sub-finishes of Base. Same price as Base; swatches are CSS only.
const subFinishes: { id: BaseSubFinish; label: string; shader: string; swatch: string }[] = [
  { id: 'plain', label: 'Plain', shader: 'Matte • No foil', swatch: 'linear-gradient(135deg,#2a2a2a,#555)' },
  { id: 'silver', label: 'Silver', shader: 'Cool metallic sheen', swatch: 'linear-gradient(135deg,#8d95a3,#eef2f8 50%,#9aa3b2)' },
  { id: 'gold', label: 'Gold', shader: 'Warm metallic sheen', swatch: 'linear-gradient(135deg,#9a7430,#f0d490 50%,#a98238)' },
];

const slabTypes: { id: SlabType; label: string; price: string; spec: string }[] = [
  { id: 'standard', label: 'Standard', price: '+$0', spec: '6.2mm • 120g' },
  { id: 'premium', label: 'Premium • Thick', price: '+$15', spec: '8.5mm • 180g • Bevel' },
  { id: 'vault', label: 'Vault • Museum', price: '+$40', spec: '10mm • 250g • UV' },
];

export function Forge() {
  const finishType = useVaultStore((s) => s.finishType);
  const setFinishType = useVaultStore((s) => s.setFinishType);
  const baseSubFinish = useVaultStore((s) => s.baseSubFinish);
  const setBaseSubFinish = useVaultStore((s) => s.setBaseSubFinish);
  const slabType = useVaultStore((s) => s.slabType);
  const setSlabType = useVaultStore((s) => s.setSlabType);
  const nftData = useVaultStore((s) => s.nftData);
  const setNftData = useVaultStore((s) => s.setNftData);
  const isFetchingNFT = useVaultStore((s) => s.isFetchingNFT);
  const setIsFetchingNFT = useVaultStore((s) => s.setIsFetchingNFT);
  const setCursor = useVaultStore((s) => s.setCursor);
  const cartCount = useVaultStore((s) => s.cartCount);
  const setCartCount = useVaultStore((s) => s.setCartCount);
  const [step, setStep] = useState(1);
  const [contract, setContract] = useState('');
  const [tokenId, setTokenId] = useState('');
  const [uploadPreview, setUploadPreview] = useState<string | null>(null);
  const [quantity, setQuantity] = useState(1);
  const [showWebGL, setShowWebGL] = useState(true);

  // Step choreography: on every step change the newly-active panel rises in
  // and its indicator dot pulses once. Deliberately scoped to the Forge flow —
  // not blanket-applied across sections (that's the generic tell we're avoiding).
  const prevStep = useRef(step);
  useEffect(() => {
    if (prevStep.current === step) return;
    prevStep.current = step;
    const panel = document.querySelector(`[data-forge-panel="${step}"]`);
    if (panel) {
      gsap.fromTo(panel,
        { y: 28, opacity: 0.35 },
        { y: 0, opacity: 1, duration: 0.55, ease: 'power3.out', clearProps: 'transform,opacity' }
      );
      gsap.fromTo(panel,
        { borderColor: 'rgba(255,77,0,0.9)' },
        { borderColor: 'rgba(255,77,0,0.5)', duration: 0.9, ease: 'power2.out', clearProps: 'borderColor' }
      );
    }
    const dot = document.querySelector(`[data-forge-dot="${step}"]`);
    if (dot) {
      gsap.fromTo(dot, { scale: 1.35 }, { scale: 1, duration: 0.5, ease: 'back.out(2)', clearProps: 'scale' });
    }
  }, [step]);

  const slabAdd = { standard: 0, premium: 15, vault: 40 }[slabType];
  const bulkTier = BULK_TIERS.find(t => quantity >= t.min);
  const unitPrice = bulkTier ? bulkTier.price[finishType] : SINGLE_PRICE[finishType];
  const savings = bulkTier ? (SINGLE_PRICE[finishType] - unitPrice) * quantity : 0;
  const totalPrice = (unitPrice + slabAdd) * quantity;

  const handleFetch = async () => {
    if (!contract || !tokenId) return;
    setIsFetchingNFT(true);
    sounds.click();
    try {
      const data = await fetchNFT(contract, tokenId);
      setNftData(data);
      setUploadPreview(null);
      sounds.success();
      setStep(2);
    } catch (e) {
      console.error(e);
    } finally {
      setIsFetchingNFT(false);
    }
  };

  const handleDemo = async (c: string, t: string) => {
    setContract(c);
    setTokenId(t);
    setIsFetchingNFT(true);
    const data = await fetchNFT(c, t);
    setNftData(data);
    setIsFetchingNFT(false);
    sounds.success();
    setStep(2);
  };

  const handleUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const url = URL.createObjectURL(file);
    setUploadPreview(url);
    setNftData({
      image: url,
      name: file.name,
      collection: 'Custom Upload',
      tokenId: 'CUSTOM',
      contract: '0xCUSTOM',
    });
    sounds.success();
    setStep(2);
  };

  return (
    <section id="forge" className="relative py-24 md:py-32 px-6 md:px-12 xl:px-24 bg-[#080808] border-y border-[#1A1A1A] overflow-hidden">
      <div className="absolute inset-0 opacity-[0.02]" style={{
        backgroundImage: `repeating-linear-gradient(0deg, transparent, transparent 40px, rgba(255,255,255,0.1) 40px, rgba(255,255,255,0.1) 41px)`,
      }} />

      <div className="max-w-[1600px] mx-auto relative z-10">
        <div className="flex flex-wrap items-end justify-between gap-8 mb-16">
          <div>
            <div className="flex flex-wrap items-center gap-x-3 gap-y-2 mb-6">
              <span className="font-mono text-[10px] tracking-[0.3em] text-[#FF4D00]">03 / FORGE • TRUE WEBGL</span>
              <div className="w-12 h-[1px] bg-[#FF4D00]" />
              <span className="font-mono text-[10px] text-[#F5F3EF]/30">LIVE GLSL • ORBITCONTROLS • 60FPS</span>
            </div>
            <h2 className="font-display font-black leading-[0.85] tracking-tighter uppercase" style={{ fontSize: 'var(--fs-h2)' }}>
              Forge<br/>
              <span className="font-light italic lowercase">Your Grail</span>
            </h2>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            {[1,2,3,4].map(n => (
              <div key={n} data-forge-dot={n} className={`flex items-center gap-2 ${n <= step ? '' : 'opacity-30'}`}>
                <div className={`w-8 h-8 rounded-full grid place-items-center font-mono text-[11px] font-bold border transition-colors ${n === step ? 'bg-[#FF4D00] text-white border-[#FF4D00]' : n < step ? 'bg-[#F5F3EF] text-black border-[#F5F3EF]' : 'bg-transparent text-[#F5F3EF]/40 border-[#2A2A2A]'}`}>
                  {n < step ? '✓' : n}
                </div>
                {n < 4 && <div className={`w-8 h-[1px] ${n < step ? 'bg-[#F5F3EF]' : 'bg-[#2A2A2A]'}`} />}
              </div>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-[minmax(0,1fr)] lg:grid-cols-[1.1fr_0.9fr] gap-8 md:gap-12">
          <div className="space-y-6">
            <div data-forge-panel={1} className={`border transition-colors ${step === 1 ? 'border-[#FF4D00]/50 bg-[#0f0f0f]' : 'border-[#1A1A1A] bg-[#0a0a0a]'} p-6 md:p-8`}>
              <div className="flex flex-wrap items-center justify-between gap-x-4 gap-y-2 mb-6">
                <h3 className="font-display font-bold text-[20px] tracking-tight uppercase">01 — Submit NFT / Artwork</h3>
                <span className="font-mono text-[10px] text-[#F5F3EF]/30">READ-ONLY • ALCHEMY DEMO</span>
              </div>

              {step === 1 ? (
                <>
                  <div className="grid md:grid-cols-[1.2fr_0.8fr] gap-6">
                    <div className="space-y-4">
                      <div>
                        <label className="font-mono text-[10px] tracking-widest text-[#F5F3EF]/50 mb-2 block">CONTRACT ADDRESS</label>
                        <input
                          value={contract}
                          onChange={e => setContract(e.target.value)}
                          placeholder="0xBC4CA0EdA7647A8aB7C2061c2E118A18a936f13D"
                          className="w-full h-12 px-4 bg-[#111] border border-[#2A2A2A] font-mono text-[12px] text-[#F5F3EF] placeholder:text-[#F5F3EF]/20 focus:border-[#FF4D00]/50 transition-colors"
                        />
                      </div>
                      <div>
                        <label className="font-mono text-[10px] tracking-widest text-[#F5F3EF]/50 mb-2 block">TOKEN ID</label>
                        <div className="flex gap-2">
                          <input
                            value={tokenId}
                            onChange={e => setTokenId(e.target.value)}
                            placeholder="1"
                            className="flex-1 min-w-0 h-12 px-4 bg-[#111] border border-[#2A2A2A] font-mono text-[12px] text-[#F5F3EF] placeholder:text-[#F5F3EF]/20 focus:border-[#FF4D00]/50 transition-colors"
                          />
                          <MagneticButton variant="orange" size="md" cursorLabel="FETCH" onClick={handleFetch} disabled={isFetchingNFT || !contract || !tokenId}>
                            {isFetchingNFT ? 'FETCHING...' : 'FETCH'}
                          </MagneticButton>
                        </div>
                      </div>

                      <div className="pt-4 border-t border-[#1A1A1A]">
                        <div className="font-mono text-[10px] tracking-widest text-[#F5F3EF]/40 mb-3">OR TRY DEMO:</div>
                        <div className="flex flex-wrap gap-2">
                          {DEMO_NFTS.map(d => (
                            <button
                              key={d.label}
                              onClick={() => handleDemo(d.contract, d.tokenId)}
                              className="px-3 py-1.5 bg-[#1A1A1A] border border-[#2A2A2A] font-mono text-[10px] text-[#F5F3EF]/70 hover:text-[#F5F3EF] hover:border-[#FF4D00]/30 transition-colors cursor-none"
                              onMouseEnter={() => setCursor(true, 'FETCH')}
                              onMouseLeave={() => setCursor(false)}
                            >
                              {d.label}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>

                    <div>
                      <div className="font-mono text-[10px] tracking-widest text-[#F5F3EF]/40 mb-3">OR UPLOAD DIRECTLY</div>
                      <label className="group relative flex flex-col items-center justify-center w-full h-[160px] border border-dashed border-[#2A2A2A] hover:border-[#FF4D00]/50 bg-[#111]/50 hover:bg-[#111] transition-colors cursor-pointer">
                        <input type="file" accept="image/*" onChange={handleUpload} className="hidden" />
                        <div className="font-mono text-[10px] text-[#F5F3EF]/40 group-hover:text-[#F5F3EF]/70 transition-colors">DROP IMAGE OR CLICK</div>
                        <div className="font-mono text-[9px] text-[#F5F3EF]/20 mt-1">PNG, JPG, WEBP • MAX 10MB</div>
                        <div className="mt-4 w-8 h-8 border border-[#2A2A2A] grid place-items-center group-hover:border-[#FF4D00]/50 transition-colors">+</div>
                      </label>
                    </div>
                  </div>
                </>
              ) : (
                <div className="flex items-center gap-4">
                  <img src={nftData?.image || uploadPreview || ''} alt="" className="w-16 h-16 object-cover border border-[#2A2A2A]" />
                  <div>
                    <div className="font-bold text-[14px]">{nftData?.name}</div>
                    <div className="font-mono text-[10px] text-[#F5F3EF]/50">{nftData?.collection} • #{nftData?.tokenId}</div>
                  </div>
                  <button onClick={() => setStep(1)} className="ml-auto font-mono text-[10px] tracking-widest text-[#FF4D00] hover:text-white transition-colors">EDIT</button>
                </div>
              )}
            </div>

            <div data-forge-panel={2} className={`border transition-colors ${step === 2 ? 'border-[#FF4D00]/50 bg-[#0f0f0f]' : 'border-[#1A1A1A] bg-[#0a0a0a] opacity-60'} p-6 md:p-8`}>
              <div className="flex flex-wrap items-center justify-between gap-x-4 gap-y-2 mb-6">
                <h3 className="font-display font-bold text-[20px] tracking-tight uppercase">02 — Choose Finish & Slab</h3>
                <span className="font-mono text-[10px] text-[#F5F3EF]/30">GLSL SHADER • LIVE</span>
              </div>

              {step >= 2 && (
                <>
                  <div className="mb-8">
                    <div className="font-mono text-[10px] tracking-widest text-[#F5F3EF]/40 mb-3">FINISH • SELECT ONE • REAL SHADER SWAP</div>
                    <div className="grid grid-cols-2 gap-2">
                      {finishes.map((f, i) => (
                        <button
                          key={f.id}
                          onClick={() => { setFinishType(f.id); sounds.foil(); }}
                          className={`text-left p-4 border transition-all group ${i === finishes.length - 1 && finishes.length % 2 === 1 ? 'col-span-2' : ''} ${finishType === f.id ? 'bg-[#F5F3EF] text-black border-[#F5F3EF]' : 'bg-[#111] text-[#F5F3EF]/70 border-[#2A2A2A] hover:border-[#F5F3EF]/20 hover:text-[#F5F3EF]'}`}
                        >
                          <div className="flex flex-wrap items-center justify-between gap-x-2 gap-y-1">
                            <span className="font-bold text-[13px] tracking-wide uppercase">{f.label}</span>
                            <span className={`font-mono text-[11px] font-bold px-1.5 py-0.5 ${finishType === f.id ? 'bg-black text-white' : 'bg-[#FF4D00] text-white'}`}>{f.price}</span>
                          </div>
                          <div className={`font-mono text-[10px] mt-1 ${finishType === f.id ? 'text-black/60' : 'text-[#F5F3EF]/40'}`}>{f.desc}</div>
                          <div className={`font-mono text-[9px] mt-2 px-1.5 py-0.5 inline-block ${finishType === f.id ? 'bg-black/10 text-black/50' : 'bg-[#1A1A1A] text-[#F5F3EF]/30'}`}>{f.shader}</div>
                        </button>
                      ))}
                    </div>
                    {/* Base sub-finish: revealed only while Base is selected. Height animates
                        via grid rows (no measuring, no overflow); collapsed = inert. */}
                    <div
                      className={`grid transition-[grid-template-rows,opacity,margin] duration-300 ease-out ${finishType === 'base' ? 'grid-rows-[1fr] opacity-100 mt-2' : 'grid-rows-[0fr] opacity-0 mt-0 pointer-events-none'}`}
                      aria-hidden={finishType !== 'base'}
                      inert={finishType !== 'base'}
                    >
                      <div className="overflow-hidden min-w-0">
                        <div className="flex items-center gap-3 p-2 border border-[#2A2A2A] bg-[#0a0a0a]">
                          <span className="hidden min-[420px]:block font-mono text-[9px] tracking-widest text-[#F5F3EF]/40 pl-1 shrink-0">BASE FOIL</span>
                          <div role="radiogroup" aria-label="Base sub-finish" className="grid grid-cols-3 gap-1 flex-1 min-w-0">
                            {subFinishes.map(sf => (
                              <button
                                key={sf.id}
                                type="button"
                                role="radio"
                                aria-checked={baseSubFinish === sf.id}
                                onClick={() => { setBaseSubFinish(sf.id); sounds.foil(); }}
                                className={`flex items-center justify-center gap-2 min-w-0 h-9 px-2 border font-mono text-[10px] tracking-wide uppercase transition-colors ${baseSubFinish === sf.id ? 'bg-[#F5F3EF] text-black border-[#F5F3EF]' : 'bg-[#111] text-[#F5F3EF]/60 border-[#2A2A2A] hover:text-[#F5F3EF] hover:border-[#F5F3EF]/20'}`}
                              >
                                <span aria-hidden className="w-2.5 h-2.5 shrink-0 border border-black/30" style={{ background: sf.swatch }} />
                                <span className="truncate">{sf.label}</span>
                              </button>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="mb-8">
                    <div className="font-mono text-[10px] tracking-widest text-[#F5F3EF]/40 mb-3">SLAB TYPE • THICKNESS & WEIGHT</div>
                    <div className="flex gap-2">
                      {slabTypes.map(s => (
                        <button
                          key={s.id}
                          onClick={() => setSlabType(s.id)}
                          className={`flex-1 p-3 border font-mono text-[11px] tracking-wide uppercase transition-colors ${slabType === s.id ? 'bg-[#1A1A1A] text-[#F5F3EF] border-[#F5F3EF]/20' : 'bg-transparent text-[#F5F3EF]/40 border-[#1A1A1A] hover:text-[#F5F3EF]/70'}`}
                        >
                          <div>{s.label}</div>
                          <div className="text-[10px] text-[#FF4D00] mt-1">{s.price}</div>
                          <div className="text-[9px] text-[#F5F3EF]/30 mt-1 normal-case">{s.spec}</div>
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <MagneticButton variant="dark" size="md" cursorLabel="BACK" onClick={() => setStep(1)}>← Back</MagneticButton>
                    <MagneticButton variant="light" size="md" cursorLabel="NEXT" className="flex-1" onClick={() => { setStep(3); sounds.success(); }}>Continue to Preview</MagneticButton>
                  </div>
                </>
              )}
            </div>

            <div data-forge-panel={3} className={`border transition-colors ${step === 3 ? 'border-[#FF4D00]/50 bg-[#0f0f0f]' : 'border-[#1A1A1A] bg-[#0a0a0a] opacity-60'} p-6 md:p-8`}>
              <h3 className="font-display font-bold text-[20px] tracking-tight uppercase mb-6">03 — Preview & Quantity</h3>
              {step >= 3 && (
                <>
                  <div className="flex flex-wrap items-center gap-x-4 gap-y-3 mb-6">
                    <span className="font-mono text-[10px] tracking-widest text-[#F5F3EF]/40">QUANTITY</span>
                    <div className="flex items-center gap-2">
                      <button onClick={() => setQuantity(Math.max(1, quantity - 1))} className="w-8 h-8 bg-[#1A1A1A] border border-[#2A2A2A] grid place-items-center hover:border-[#F5F3EF]/20 transition-colors">−</button>
                      <span className="w-12 h-8 bg-[#111] border border-[#2A2A2A] grid place-items-center font-mono text-[12px] tabular">{quantity}</span>
                      <button onClick={() => setQuantity(Math.min(500, quantity + 1))} className="w-8 h-8 bg-[#1A1A1A] border border-[#2A2A2A] grid place-items-center hover:border-[#F5F3EF]/20 transition-colors">+</button>
                    </div>
                    <span className="font-mono text-[10px] text-[#F5F3EF]/30 tabular">
                      ${unitPrice}/CARD{bulkTier ? ' • BULK RATE' : ''}{savings > 0 ? ` • SAVE $${savings}` : ''} • UP TO 500
                    </span>
                  </div>
                  <div className="flex gap-2">
                    <MagneticButton variant="dark" size="md" cursorLabel="BACK" onClick={() => setStep(2)}>← Back</MagneticButton>
                    <MagneticButton variant="orange" size="md" cursorLabel="PAY" className="flex-1 tabular" onClick={() => { setStep(4); sounds.slabClack(); }}>Proceed to Checkout — ${totalPrice}</MagneticButton>
                  </div>
                </>
              )}
            </div>

            {step === 4 && (
              <div data-forge-panel={4} className="border border-[#FF4D00] bg-[#0f0f0f] p-6 md:p-8">
                <h3 className="font-display font-bold text-[20px] tracking-tight uppercase mb-6">04 — Checkout (Mock)</h3>
                <div className="space-y-4 mb-6">
                  <input placeholder="Email" className="w-full h-12 px-4 bg-[#111] border border-[#2A2A2A] font-mono text-[12px] placeholder:text-[#F5F3EF]/20 focus:border-[#FF4D00]/50" />
                  <input placeholder="Shipping Address" className="w-full h-12 px-4 bg-[#111] border border-[#2A2A2A] font-mono text-[12px] placeholder:text-[#F5F3EF]/20 focus:border-[#FF4D00]/50" />
                  <div className="grid grid-cols-1 min-[420px]:grid-cols-2 gap-2">
                    <input placeholder="City" className="h-12 px-4 min-w-0 bg-[#111] border border-[#2A2A2A] font-mono text-[12px] placeholder:text-[#F5F3EF]/20 focus:border-[#FF4D00]/50" />
                    <input placeholder="Postal" className="h-12 px-4 min-w-0 bg-[#111] border border-[#2A2A2A] font-mono text-[12px] placeholder:text-[#F5F3EF]/20 focus:border-[#FF4D00]/50" />
                  </div>
                </div>
                <MagneticButton variant="light" size="lg" cursorLabel="PAY" className="w-full tabular" onClick={() => {
                  setCartCount(cartCount + quantity);
                  sounds.success();
                  alert(`Order placed! Mock confirmation NMO-${Date.now().toString().slice(-6)} • $${totalPrice} • You will receive tracking via email.`);
                  setStep(1);
                  setNftData(null);
                  setUploadPreview(null);
                }}>
                  Pay ${totalPrice} — Mock Checkout
                </MagneticButton>
                <div className="mt-3 font-mono text-[9px] text-center text-[#F5F3EF]/30 tabular">
                  Free US shipping • $15 flat international • Mock checkout — no payment taken
                </div>
              </div>
            )}
          </div>

          <div className="lg:sticky lg:top-24 h-fit space-y-4">
            <SlabFrame label={`TRUE WEBGL PREVIEW • ${finishType.toUpperCase()}${finishType === 'base' && baseSubFinish !== 'plain' ? ` ${baseSubFinish.toUpperCase()}` : ''} • ${slabType.toUpperCase()} • GLSL`} foil>
              <div className="relative">
                <div className="flex items-center justify-between p-2 bg-[#0a0a0a] border-b border-[#1A1A1A]">
                  <div className="flex gap-1">
                    <button onClick={() => setShowWebGL(true)} className={`px-2 py-1 font-mono text-[9px] tracking-widest ${showWebGL ? 'bg-[#F5F3EF] text-black' : 'bg-[#1A1A1A] text-[#F5F3EF]/50'}`}>WEBGL • TRUE</button>
                    <button onClick={() => setShowWebGL(false)} className={`px-2 py-1 font-mono text-[9px] tracking-widest ${!showWebGL ? 'bg-[#F5F3EF] text-black' : 'bg-[#1A1A1A] text-[#F5F3EF]/50'}`}>DOM • FALLBACK</button>
                  </div>
                  <div className="font-mono text-[9px] text-[#FF4D00]">● LIVE SHADER</div>
                </div>
                
                {showWebGL ? (
                  <div className="aspect-[3/4] bg-[#050505]">
                    <ForgePreview />
                  </div>
                ) : (
                  <div className="aspect-[3/4] relative bg-[#050505] overflow-hidden">
                    {(nftData?.image || uploadPreview) ? (
                      <img src={nftData?.image || uploadPreview || ''} alt="Preview" className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full grid place-items-center p-12 text-center">
                        <div>
                          <div className="w-16 h-16 mx-auto border border-dashed border-[#2A2A2A] grid place-items-center mb-4">
                            <span className="font-mono text-[20px] text-[#F5F3EF]/20">+</span>
                          </div>
                          <div className="font-mono text-[10px] tracking-widest text-[#F5F3EF]/30">FETCH AN NFT TO SEE TRUE WEBGL</div>
                        </div>
                      </div>
                    )}
                    <div className="absolute inset-0 pointer-events-none mix-blend-overlay opacity-60"
                      style={{
                        background: finishType === 'holo' ? `linear-gradient(105deg, transparent 30%, rgba(255,77,0,0.4), rgba(0,229,255,0.4), transparent 70%)` :
                                   finishType === 'cracked-ice' ? `repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(255,255,255,0.05) 2px, rgba(255,255,255,0.05) 3px)` :
                                   finishType === 'star' ? `linear-gradient(180deg, rgba(255,215,0,0.3), transparent, rgba(255,215,0,0.2))` :
                                   finishType === 'sparkle' ? `radial-gradient(circle at 30% 25%, rgba(255,255,255,0.35) 0, transparent 2px), radial-gradient(circle at 70% 60%, rgba(255,138,61,0.35) 0, transparent 2px)` : 'transparent',
                      }}
                    />
                    <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black to-transparent">
                      <div className="flex items-end justify-between">
                        <div>
                          <div className="font-bold text-[14px] text-white truncate max-w-[200px]">{nftData?.name || 'Untitled'}</div>
                          <div className="font-mono text-[10px] text-white/60">{nftData?.collection || '—'} • {finishType.toUpperCase()}</div>
                        </div>
                        <div className="font-mono text-[10px] px-2 py-1 bg-[#FF4D00] text-white font-bold tabular">${totalPrice}</div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </SlabFrame>

            <div className="grid grid-cols-3 gap-2">
              {[
                { k: 'Finish', v: finishType === 'base' && baseSubFinish !== 'plain' ? `base ${baseSubFinish}` : finishType, d: finishType === 'base' ? subFinishes.find(x => x.id === baseSubFinish)?.shader : finishes.find(f => f.id === finishType)?.shader },
                { k: 'Slab', v: slabType, d: slabTypes.find(s => s.id === slabType)?.spec },
                { k: 'Qty', v: `×${quantity}`, d: `$${totalPrice}` },
              ].map(s => (
                <div key={s.k} className="p-3 bg-[#0a0a0a] border border-[#1A1A1A]">
                  <div className="font-mono text-[9px] tracking-widest text-[#F5F3EF]/30">{s.k}</div>
                  <div className="font-mono text-[11px] font-bold text-[#F5F3EF] uppercase mt-1 tabular">{s.v}</div>
                  <div className="font-mono text-[8px] text-[#F5F3EF]/40 mt-1 truncate">{s.d}</div>
                </div>
              ))}
            </div>

            <div className="p-4 bg-[#FF4D00]/10 border border-[#FF4D00]/20">
              <div className="font-mono text-[10px] tracking-widest text-[#FF4D00] mb-1">VAULT NOTE • TRUE WEBGL</div>
              <div className="font-body text-[12px] leading-snug text-[#F5F3EF]/70">
                This preview uses the same GLSL shader as final print: fresnel, rainbow gradient, noise. Drag to spin. Pointer drives foil. What you see is what gets forged.
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
