'use client';

import * as THREE from 'three';
import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { shaderMaterial } from '@react-three/drei';
import { applyProps, extend, useFrame, useThree, type ThreeElement, type ThreeEvent } from '@react-three/fiber';
import type { PaletteDriver } from '@/components/canvas/slab/slabPalette';

/* ------------------------------------------------------------------ *
 * Finishes
 * ------------------------------------------------------------------ */

export type FinishName = 'base' | 'holo' | 'cracked-ice' | 'star' | 'sparkle';

/** Finish name → the number the shader blends between. */
export const FINISH_INDEX: Record<FinishName, number> = {
  base: 0,
  holo: 1,
  'cracked-ice': 2,
  star: 3,
  sparkle: 4,
};

/** Sub-finishes of 'base': plain ink, or a clean metallic foil. */
export type SubFinishName = 'plain' | 'silver' | 'gold';

export const SUB_FINISH_INDEX: Record<SubFinishName, number> = {
  plain: 0,
  silver: 1,
  gold: 2,
};

/* ------------------------------------------------------------------ *
 * Shader
 *
 * Two modes:
 *   0 base     — draws the art itself with the finish mixed in (legacy path)
 *   1 overlay  — a transparent foil pass that sits on the card plane and is
 *                masked to the art window, so the frame, title and attributes
 *                keep their own inks
 *
 * The finish passes are written against the reference photos in the repo
 * root (holo.jpg, gold.jpg, cracked-ice.jpg; gold.jpg is the star reference);
 * each one is documented where it is defined in the fragment shader:
 *
 *   holo         liquid-rippled band pinned to one edge, colour running DOWN
 *                it (red, orange, yellow, green, a little blue), opaque core
 *   cracked-ice  continuous crumpled sheet: layered slim facet mosaics with
 *                tonal highlights/lowlights and crisp light-catching creases
 *   star         sparse flat angular flakes (open gaps), luminous pink /
 *                magenta / cyan / mint / orange, bright rims, hot-white flash
 *   sparkle      the print left bare under a fine dot-matrix of twinkling foil
 *                specks (dotSparkle) plus sparse hot glints (glintPoints)
 *
 * Every finish composites in linear light and adds an HDR specular hotspot
 * under the pointer, so cores blow out to white like the photos.
 *
 * Dynamic opacity (foil light field)
 *   Finish visibility is not a constant: it is driven by a per-pixel light
 *   field, foilLight(). A virtual key light hangs over the card face (it
 *   follows the pointer); the eye direction is taken in CARD space (a vertex
 *   varying), so orbiting / spinning / tilting the card moves the mirror
 *   point exactly like a real glossy sheet. Where the card's normal bisects
 *   light and eye (half-vector slope ~ 0) the foil is lit; elsewhere, and at
 *   grazing views, it eases down to a per-finish noise floor. Each finish
 *   maps that through its own curve (foilOpacity: floor + smoothstep
 *   threshold + gamma) and also gates its micro-facets (ice facets, star
 *   flakes, sparkle dots) by their OWN tilt, so they twinkle in and out as
 *   the card moves. Star uses by far the steepest curve and lowest floor.
 *   uLightFx (prop `lighting`) blends this against the old constant opacity.
 * ------------------------------------------------------------------ */

const HoloShaderMaterial = shaderMaterial(
  {
    uTime: 0,
    uPointer: new THREE.Vector2(0.5, 0.5),
    uImage: null as THREE.Texture | null,
    /** source width / height — drives the cover-fit crop */
    uImageAspect: 1,
    /** card face width / height */
    uCardAspect: 0.709,
    uFinish: 0,
    /** base sub-finish: 0 plain, 1 silver, 2 gold (only read inside the base branch) */
    uSubFinish: 0,
    uIntensity: 1,
    /** 0 = draw the art, 1 = foil overlay */
    uMode: 0,
    /** 1 = three layers per finish (default look), 0 = two (cheaper on weak GPUs) */
    uQuality: 1,
    /** 1 = finish opacity follows the light field, 0 = constant (legacy) */
    uLightFx: 1,
    /**
     * x0, y0, x1, y1 of the foil mask, in card UV (v measured from the bottom).
     * These are the measured art window of `reference-image.jpg`: card
     * x 0.0569..0.9431, y 0.0464..0.6325 from the top.
     */
    uMask: new THREE.Vector4(0.0569, 0.3675, 0.9431, 0.9536),
    /**
     * The reference's art frame is a hard 4 px ink line, so the foil has to
     * stop at it: the old 0.06 feather smeared the rainbow ~30 px past the
     * window and onto the card's furniture, which the photo does not show.
     */
    uMaskFeather: 0.012,
    /** how strongly the foil shows outside the mask (the photo shows none) */
    uOutside: 0.015,
    /* Dynamic palette: the foil's diffraction orders, the ice tint and the
     * star pair. Defaults are the hand-tuned constants; a palette driver
     * writes the derived family in here every frame. Values are LINEAR light.
     * The holo / star spectra now follow the reference photos (fixed hues, so
     * they stay luminous on any art); the palette still drives the ice tint
     * (uIce) and the star specular warmth (uStarA). The others stay declared
     * so the palette engine can keep writing them. */
    uFoilB: new THREE.Vector3(0.32, 0.78, 0.92),
    uFoilC: new THREE.Vector3(1.0, 0.82, 0.34),
    uFoilD: new THREE.Vector3(0.92, 0.35, 0.72),
    uIce: new THREE.Vector3(0.78, 0.88, 1.0),
    uStarA: new THREE.Vector3(1.0, 0.86, 0.36),
    uStarB: new THREE.Vector3(0.62, 0.42, 0.09),
  },
  // vertex
  /* glsl */ `
    varying vec2 vUv;
    varying vec3 vNormal;
    varying vec3 vViewDir;
    /** direction to the eye in CARD space (z = card normal). Affine in the
     *  vertex position, so it interpolates exactly across the face; the
     *  fragment shader normalises it. Scale cancels in the normalise. */
    varying vec3 vLocalView;

    void main() {
      vUv = uv;
      vec4 mvPos = modelViewMatrix * vec4(position, 1.0);
      vNormal = normalize(normalMatrix * normal);
      vViewDir = normalize(-mvPos.xyz);
      /* columns of the model-view rotation are the card's axes in view space,
       * so dotting the view-space eye vector with them gives card-space coords
       * (this follows the orbit camera, the flip, the spin and the back face) */
      mat3 mv3 = mat3(modelViewMatrix);
      vec3 eye = -mvPos.xyz;
      vLocalView = vec3(dot(mv3[0], eye), dot(mv3[1], eye), dot(mv3[2], eye));
      gl_Position = projectionMatrix * mvPos;
    }
  `,
  // fragment
  /* glsl */ `
    uniform float uTime;
    uniform vec2 uPointer;
    uniform sampler2D uImage;
    uniform float uImageAspect;
    uniform float uCardAspect;
    uniform float uFinish;
    uniform float uSubFinish;
    uniform float uIntensity;
    uniform float uMode;
    /** 1 = three layers per finish (default look), 0 = two (cheaper on weak GPUs) */
    uniform float uQuality;
    /** 1 = finish opacity follows the light field, 0 = constant (legacy) */
    uniform float uLightFx;
    uniform vec3 uFoilB;
    uniform vec3 uFoilC;
    uniform vec3 uFoilD;
    uniform vec3 uIce;
    uniform vec3 uStarA;
    uniform vec3 uStarB;

    varying vec2 vUv;
    varying vec3 vNormal;
    varying vec3 vViewDir;
    varying vec3 vLocalView;

    /* ================================================================== *
     * Utilities
     * ================================================================== */

    float hash21(vec2 p) {
      p = fract(p * vec2(234.34, 435.345));
      p += dot(p, p + 34.345);
      return fract(p.x * p.y);
    }

    vec2 hash22(vec2 p) {
      float n = hash21(p);
      return vec2(hash21(p + n + 1.71), hash21(p + n * 2.31 + 5.13));
    }

    /** four decorrelated randoms per integer cell */
    vec4 hash4(vec2 p) {
      float a = hash21(p);
      float b = hash21(p + 17.31 + a * 3.7);
      float c = hash21(p + 41.77 + b * 5.3);
      float d = hash21(p + 83.13 + c * 7.1);
      return vec4(a, b, c, d);
    }

    float noise(vec2 st) {
      vec2 i = floor(st);
      vec2 f = fract(st);
      float a = hash21(i);
      float b = hash21(i + vec2(1.0, 0.0));
      float c = hash21(i + vec2(0.0, 1.0));
      float d = hash21(i + vec2(1.0, 1.0));
      vec2 u = f * f * (3.0 - 2.0 * f);
      return mix(a, b, u.x) + (c - a) * u.y * (1.0 - u.x) + (d - b) * u.x * u.y;
    }

    vec3 srgbEnc(vec3 c) {
      vec3 s = step(vec3(0.0031308), c);
      return mix(c * 12.92, 1.055 * pow(max(c, vec3(1e-5)), vec3(1.0 / 2.4)) - 0.055, s);
    }

    vec3 srgbDec(vec3 c) {
      vec3 s = step(vec3(0.04045), c);
      return mix(c / 12.92, pow(max(c + 0.055, vec3(0.0)) / 1.055, vec3(2.4)), s);
    }

    /** fine foil dot-matrix over the whole face; .rgb tint, .a sparkle.
     *  facet = the dot's own micro-tilt (-1..1 each axis): lets the caller
     *  light each dot only when it squarely catches the key light */
    vec4 dotSparkle(vec2 uv, float phase, out vec2 facet) {
      vec2 g = uv * vec2(120.0, 170.0);
      vec2 id = floor(g);
      vec2 f = fract(g) - 0.5;
      vec2 jr = hash22(id) - 0.5;
      float d = length(f - jr * 0.35);
      float shape = 1.0 - smoothstep(0.20, 0.46, d);
      float h1 = hash21(id);
      float h2 = hash21(id + 7.31);
      float tw = 0.5 + 0.5 * sin(phase * 2.0 + h1 * 6.2831);
      float spark = shape * (0.03 + 0.97 * h2 * h2 * (0.25 + 0.75 * tw));
      float tinted = step(0.74, h1);
      vec3 pal = 0.55 + 0.45 * cos(6.2831 * (h2 + phase * 0.05 + vec3(0.0, 0.33, 0.67)));
      vec3 tint = mix(vec3(1.0), pal * pal, tinted * 0.85);
      facet = hash22(id + 11.7) * 2.0 - 1.0;
      return vec4(tint, spark);
    }

    vec4 dotSparkle(vec2 uv, float phase) {
      vec2 facet;
      return dotSparkle(uv, phase, facet);
    }

    /** scattered hot sparkle points (orange/white), HDR */
    vec3 glintPoints(vec2 uv, float time, float thresh) {
      vec2 g = uv * vec2(90.0, 130.0);
      vec2 id = floor(g);
      float h = hash21(id + 3.7);
      float on = step(thresh, h);
      float tw = 0.5 + 0.5 * sin(time * 2.6 + h * 40.0);
      float d = length(fract(g) - 0.5);
      float spot = 1.0 - smoothstep(0.10, 0.40, d);
      vec3 col = mix(vec3(1.0, 0.55, 0.15), vec3(1.0), step(0.5, hash21(id + 8.2)));
      return col * on * spot * (0.5 + 2.3 * tw);
    }

    /* ================================================================== *
     * Foil light field
     *
     * One cheap, shared model of "where is the foil catching the light":
     *
     *   - a virtual key light hangs LIGHT_H above the card, over the point
     *     keyLightCentre() (it follows the pointer, as the old hotspot did);
     *   - the eye is taken in CARD space (vLocalView), so camera orbit, spin
     *     and gyro tilt all move the highlight; EYE_TILT_GAIN keeps the
     *     highlight on the card through ordinary orbiting (the key light
     *     rides partly with the viewer, like a studio light on the rig);
     *   - slope = H.xy / H.z, the Beckmann slope of the half-vector: 0 where
     *     the card's normal bisects light and eye (the mirror point). A lobe
     *     exp(-|slope|^2 / m^2) on it is the microfacet distribution, so the
     *     lit area stretches the way a real highlight does at oblique views;
     *   - gate drops the whole finish toward grazing views.
     *
     * Each finish turns this into an opacity with foilOpacity() and lets its
     * own facets (ice facets, star flakes, sparkle dots) catch the light by
     * their own tilt via facetCatch().
     * ================================================================== */

    /** key light height above the card face, in card heights */
    const float LIGHT_H = 0.85;
    /** half-vector slope per card height away from the mirror point (1 / 2H) */
    const float SLOPE_PER_CARD = 0.5 / LIGHT_H;
    /** share of the eye's sideways tilt the key light's mirror point follows
     *  (1 = a fixed light: the highlight leaves the card by ~40 degrees) */
    const float EYE_TILT_GAIN = 0.65;

    struct FoilLight {
      vec2 slope;  // half-vector slope in card space; 0 = perfect mirror alignment
      float gate;  // 0..1 viewing-angle visibility (grazing views fall to 0)
      vec2 hs;     // specular hotspot: x = blown core, y = soft halo
      vec2 mirror; // card UV where the key light's reflection sits for THIS eye (slope = 0)
      float facing; // cos of the angle between the card normal and the eye
    };

    /** card UV where the key light's reflection sits when the card faces the eye */
    vec2 keyLightCentre() {
      return vec2(0.5 + (uPointer.x - 0.5) * 1.30 - 0.08 + 0.015 * sin(uTime * 0.31),
                  0.5 + (uPointer.y - 0.5) * 1.30 + 0.12 + 0.015 * cos(uTime * 0.23));
    }

    /** gaussian lobe on a half-vector slope; radius = footprint on the card
     *  (in card heights, at normal view) where it falls to 1/e */
    float lobe(vec2 s, float radius) {
      vec2 q = s / (radius * SLOPE_PER_CARD);
      return exp(-dot(q, q));
    }

    FoilLight foilLight() {
      vec3 V = normalize(vLocalView);
      vec3 P = vec3((vUv - 0.5) * vec2(uCardAspect, 1.0), 0.0);
      vec3 Lp = vec3((keyLightCentre() - 0.5) * vec2(uCardAspect, 1.0), LIGHT_H);
      vec3 Ve = normalize(vec3(V.xy * EYE_TILT_GAIN, max(V.z, 0.05)));
      vec3 Hv = normalize(normalize(Lp - P) + Ve);
      FoilLight FL;
      FL.slope = Hv.xy / max(Hv.z, 0.25);
      FL.gate = smoothstep(0.06, 0.50, V.z);
      FL.facing = clamp(V.z, 0.0, 1.0);
      /* the mirror point: where the card's normal bisects light and eye. It
       * slides with the pointer-driven light AND with the card's tilt. */
      FL.mirror = keyLightCentre() + vec2(Ve.x / uCardAspect, Ve.y) * (LIGHT_H / max(Ve.z, 0.3));
      /* radii sqrt(0.0042) and sqrt(0.036): the old hotspot's core and halo */
      FL.hs = vec2(lobe(FL.slope, 0.0648), lobe(FL.slope, 0.1897));
      return FL;
    }

    /** how squarely a micro-facet catches the light. f is the facet's random
     *  tilt (-1..1 per axis); squaring it biases facets toward flat with a
     *  few steep ones, and the gaussian keeps the flash smooth in tilt */
    float facetCatch(vec2 slope, vec2 f, float tilt, float width) {
      vec2 d = (slope - f * abs(f) * tilt) / width;
      return exp(-dot(d, d));
    }

    /**
     * lit (0..1) -> finish opacity: a noise floor, then a smoothstep ramp
     * between lo and hi (no clamped edge), shaped by gamma (>1 = steeper toe,
     * the highlight has to be nearly direct). uLightFx blends against the
     * constant-opacity look.
     *
     *   finish   floor  lo    hi    gamma
     *   holo     0.28   0.05  0.85  1.0     broad, the band never vanishes
     *   ice      0.16   0.08  0.80  1.0     lit patch + per-facet catch
     *   sparkle  0.10   0.06  0.80  1.0     dots wake near the highlight
     *   star     0.03   0.25  0.88  1.5     near-invisible, pops when caught
     */
    float foilOpacity(float lit, float floorOp, float lo, float hi, float gamma) {
      float t = smoothstep(lo, hi, lit);
      float c = pow(max(t, 1e-4), gamma);
      return mix(1.0, mix(floorOp, 1.0, c), uLightFx);
    }

    /* ================================================================== *
     * Shards
     *
     * A layer is a jittered grid with ONE convex polygon per cell: a triangle
     * or a kite/quad built from four hashed vertices (two tips on a long
     * axis, two side vertices), at any angle. The polygon's edge distances
     * give crisp anti-aliased borders, a bright rim band and the edge normal
     * (for light-catching edges) - no radial falloff, so shards are angular.
     * Only the 2x2 nearest cells are tested; shard reach is kept under 0.8 of
     * a cell so nothing is cut at a cell boundary.
     * ================================================================== */

    struct Shard {
      float a;     // anti-aliased coverage 0..1
      float rim;   // 0..1: inside the rim band along the border
      vec2 n;      // outward normal of the nearest edge
      vec4 r;      // per-shard randoms
      vec2 fn;     // facet tilt -1..1: decides when it flashes
      float t;     // 0..1 along the long axis
    };

    /** inside distance to the convex quad v0..v3 (CCW); >0 inside */
    float quadDist(vec2 p, vec2 v0, vec2 v1, vec2 v2, vec2 v3, out vec2 nOut) {
      vec2 e0 = v1 - v0;
      vec2 e1 = v2 - v1;
      vec2 e2 = v3 - v2;
      vec2 e3 = v0 - v3;
      vec2 n0 = vec2(-e0.y, e0.x) * inversesqrt(max(dot(e0, e0), 1e-8));
      vec2 n1 = vec2(-e1.y, e1.x) * inversesqrt(max(dot(e1, e1), 1e-8));
      vec2 n2 = vec2(-e2.y, e2.x) * inversesqrt(max(dot(e2, e2), 1e-8));
      vec2 n3 = vec2(-e3.y, e3.x) * inversesqrt(max(dot(e3, e3), 1e-8));
      float d = dot(p - v0, n0);
      nOut = -n0;
      float d1 = dot(p - v1, n1);
      if (d1 < d) { d = d1; nOut = -n1; }
      float d2 = dot(p - v2, n2);
      if (d2 < d) { d = d2; nOut = -n2; }
      float d3 = dot(p - v3, n3);
      if (d3 < d) { d = d3; nOut = -n3; }
      return d;
    }

    /**
     * cp      card-space position (x scaled by card aspect, y 0..1)
     * cell    grid pitch in card units - also ~ the shard's length
     * density fraction of cells that hold a shard
     * slim    width multiplier (1 = slender, 1.7 = fat flat flake)
     * lenK    length multiplier
     * flow    share of shards that follow flowAng (rest are any angle)
     * rimPx   rim band width in screen pixels
     */
    Shard shardLayer(vec2 cp, float cell, float density, float slim, float lenK,
                     float seed, float flow, float flowAng, float rimPx) {
      vec2 g = cp / cell + vec2(seed * 7.13, seed * 3.37);
      vec2 id0 = floor(g);
      vec2 sg = step(0.5, g - id0) * 2.0 - 1.0;
      float px = max(fwidth(cp.y), 1e-6) / cell;
      Shard S;
      S.a = 0.0;
      S.rim = 0.0;
      S.n = vec2(0.0);
      S.r = vec4(0.0);
      S.fn = vec2(0.0);
      S.t = 0.5;
      float bestZ = -1.0;
      for (int k = 0; k < 4; k++) {
        float fk = float(k);
        vec2 id = id0 + vec2(mod(fk, 2.0), floor(fk * 0.5)) * sg;
        vec2 sid = id + seed * 31.7;
        float pr = hash21(sid);
        if (pr < 1.0 - density) continue;              // empty cell: no polygon work at all
        vec4 r = vec4(pr, hash21(sid + 17.31 + pr * 3.7), hash21(sid + 41.77 + pr * 5.3), hash21(sid + 83.13 + pr * 7.1));
        vec4 q = fract(r.wzyx * 13.713 + r.yxwz * 7.317 + 0.371);
        vec2 c = id + 0.5 + (r.yz - 0.5) * 0.36;
        float ang = mix(6.2831853 * r.w, flowAng + (r.w - 0.5) * 1.3, step(q.w, flow));
        vec2 dir = vec2(cos(ang), sin(ang));
        vec2 prp = vec2(-dir.y, dir.x);
        float L1 = mix(0.26, 0.58, q.x) * lenK;
        float L2 = mix(0.10, 0.34, q.y) * lenK;
        float W1 = mix(0.07, 0.24, q.z) * slim * lenK;
        float isQuad = step(0.42, fract(r.x * 17.0 + q.y * 5.0));
        float W2 = isQuad * mix(0.03, 0.20, fract(q.z * 9.1 + r.y)) * slim * lenK;
        float S1 = mix(-0.08, 0.20, fract(r.z * 5.3 + q.w)) * lenK;
        float S2 = mix(-0.08, 0.12, fract(r.y * 7.7 + q.x)) * lenK;
        vec2 v0 = c + dir * L1;
        vec2 v1 = c + dir * S1 + prp * W1;
        vec2 v2 = c - dir * L2;
        vec2 v3 = c + dir * S2 - prp * W2;
        vec2 nO;
        float d = quadDist(g, v0, v1, v2, v3, nO);
        float cov = clamp(d / px + 0.5, 0.0, 1.0);
        float z = fract(r.z * 3.7 + q.y * 11.3);
        if (cov > 0.02 && z > bestZ) {
          bestZ = z;
          S.a = cov;
          S.rim = cov * (1.0 - smoothstep(0.0, rimPx * px, max(d, 0.0)));
          S.n = nO;
          S.r = hash4(id + seed * 5.7 + 300.1);
          S.fn = (S.r.xy - 0.5) * 2.0;
          S.t = clamp((dot(g - c, dir) + L2) / (L1 + L2), 0.0, 1.0);
        }
      }
      return S;
    }

    /* ================================================================== *
     * HOLO - a rippled liquid band pinned to the card edge
     *
     * gold.jpg/holo.jpg: a vertical band hugging the right edge. Colour runs
     * DOWN it (red, orange, yellow, green, a little blue) and bleeds in
     * vertical tongues; the inner boundary is ragged, the surface is long
     * vertical ripples that catch the light, and in the core the band
     * replaces the art instead of tinting it.
     * ================================================================== */

    /** t = how far DOWN the card (0 top .. 1 bottom): red, orange, yellow,
     *  green, and only a little teal/blue at the very bottom */
    vec3 bandRamp(float t) {
      vec3 cRed = vec3(1.0000, 0.0153, 0.0331);
      vec3 cOrange = vec3(1.0000, 0.1873, 0.0039);
      vec3 cYellow = vec3(1.0000, 0.8481, 0.0072);
      vec3 cGreen = vec3(0.0049, 1.0000, 0.0272);
      vec3 cTeal = vec3(0.0015, 0.7484, 0.3931);
      vec3 cBlue = vec3(0.0174, 0.1329, 1.0000);
      vec3 c = mix(cRed, cOrange, smoothstep(0.02, 0.28, t));
      c = mix(c, cYellow, smoothstep(0.26, 0.50, t));
      c = mix(c, cGreen, smoothstep(0.48, 0.70, t));
      c = mix(c, cTeal, smoothstep(0.84, 1.00, t));
      c = mix(c, cBlue, smoothstep(1.00, 1.14, t));
      return c;
    }

    vec3 holoFinish(vec3 img, float phase, float viewShift, float I, float Ik, FoilLight FL) {
      float y = vUv.y;
      float t = uTime;

      /* liquid relief: ripples run long vertically (low y frequency, high x
       * frequency) and the whole sheet wobbles sideways so none is ruler
       * straight */
      float wob = (noise(vec2(y * 5.0 + t * 0.040, 3.1)) - 0.5) * 0.085
                + (noise(vec2(y * 11.0 - t * 0.030, 8.7)) - 0.5) * 0.030;
      float xw = vUv.x + wob;
      float h1 = noise(vec2(xw * 11.0 + t * 0.020, y * 2.3 - t * 0.030));
      float h2 = noise(vec2(xw * 29.0 - t * 0.015, y * 6.5 - t * 0.050 + 4.1));
      float h3 = noise(vec2(xw * 71.0, y * 13.0 - t * 0.080 + 9.7));
      float relief = h1 * 0.50 + h2 * 0.32 + h3 * 0.18;
      float fineEdge = noise(vec2(xw * 60.0, y * 9.0 + t * 0.04 + 6.2));
      float e = 0.010;
      float rx = noise(vec2((xw + e) * 29.0 - t * 0.015, y * 6.5 - t * 0.050 + 4.1))
               - noise(vec2((xw - e) * 29.0 - t * 0.015, y * 6.5 - t * 0.050 + 4.1));

      /* ---- the band follows the light ----
       * On a real holo sheet the rainbow strip lives where the eye sees the
       * key light's reflection, so it is placed from the MIRROR POINT, which
       * moves with the pointer-driven light and with the card's tilt. d is how
       * far that point has travelled from where it sits at rest (0.42, 0.62):
       *   position  centre sweeps faster than the highlight itself, pinned to
       *             the right edge at rest, free to slide off either edge
       *   shape     the band leans with vertical tilt and bows toward the
       *             direction it travels, pivoting on the highlight's height
       *   width     fattens toward grazing views and with distance travelled,
       *             and tapers away from the highlight's height
       *   length    brightest at the highlight's height, thinner far from it
       *   opacity   follows how much of the light still lands on the card,
       *             the viewing angle and the ripple facets */
      vec2 d = FL.mirror - vec2(0.42, 0.62);
      float dy = y - FL.mirror.y;
      float graz = 1.0 - smoothstep(0.35, 1.0, FL.facing);
      float vFar = smoothstep(0.15, 0.75, abs(dy));
      float vEnv = mix(0.45, 1.0, 1.0 - smoothstep(0.20, 0.90 + 0.50 * graz, abs(dy)));

      float xc0 = 0.5 + 0.7 * tanh((1.03 + d.x * 1.40 - 0.5) / 0.7);
      float skew = clamp(d.y * 0.55 - d.x * 0.12, -0.40, 0.40);
      float bow = clamp(d.x, -0.8, 0.8) * 0.30;
      float xc = xc0 + dy * skew + dy * dy * bow;

      /* the long ragged tail is on the side that faces the card's inside */
      float ws = (0.80 + 0.90 * graz) * (1.0 - 0.30 * vFar) * (1.0 + 0.20 * clamp(length(d), 0.0, 1.0));
      float Wl = mix(0.10, 0.25, smoothstep(0.25, 0.85, xc0)) * ws;
      float Wr = mix(0.25, 0.10, smoothstep(0.15, 0.75, xc0)) * ws;
      float sx = vUv.x - xc;
      float dist = (sx < 0.0) ? -sx / Wl : sx / Wr;
      dist += (relief - 0.5) * 0.72 + (h1 - 0.5) * 0.30;
      float sxn = clamp(sx / (0.5 * (Wl + Wr)), -1.5, 1.5);

      vec2 dm = (FL.mirror - 0.5) * vec2(uCardAspect, 1.0);
      float onCard = exp(-dot(dm, dm) / 0.64);
      float streak = lobe(vec2(rx * 0.45, (h2 - 0.5) * 0.10), 0.50);
      float opH = foilOpacity(onCard * FL.gate * vEnv * (0.80 + 0.20 * streak), 0.22, 0.05, 0.80, 1.0);

      float m = 1.0 - smoothstep(0.10, 0.90, dist + (fineEdge - 0.5) * 0.16);
      float edgeBoost = 1.0 - smoothstep(0.0, 0.50, dist);

      /* colour runs DOWN the band and scrolls with the tilt, disperses a little
       * across the band's width (sxn), and streak noise makes one hue bleed
       * into the next in vertical tongues */
      float hueT = (1.0 - y) - d.y * 0.32 + sxn * 0.09 + dist * 0.04
                 + (h1 - 0.5) * 0.22 + (h2 - 0.5) * 0.08 + 0.03 * sin(t * 0.11);
      vec3 bandCol = bandRamp(hueT);

      float lit = smoothstep(-0.12, 0.14, rx);
      float stripe = noise(vec2(xw * 38.0 + t * 0.010, y * 1.7 + 2.3));
      float fine = noise(vec2(xw * 120.0 - t * 0.012, y * 24.0 - t * 0.090 + 1.3));
      float lum = (0.80 + 0.24 * lit + 0.30 * (h3 - 0.5) + 0.26 * (fine - 0.5)) * (0.90 + 0.20 * stripe);
      float sheen = pow(clamp(rx * 3.5, 0.0, 1.0), 2.0) * 0.10 * (0.35 + 0.65 * edgeBoost);
      vec3 emit = bandCol * lum * (0.66 + 0.40 * m) * (0.94 + 0.16 * edgeBoost);
      emit += bandCol * sheen * m;
      emit *= 0.86 + 0.28 * opH; // the lit part of the band blooms

      /* opaque foil: the band REPLACES the print; only a ghost of the art
       * (modulated by the band's colour) survives in the core */
      float Kb = clamp(pow(m, 0.80), 0.0, 1.0) * 0.97 * Ik * opH;
      vec3 lin = img * (1.0 - Kb) + img * bandCol * 0.18 * Kb + emit * Kb;

      /* border glitter + hot sparks */
      float bm = 1.0 - smoothstep(0.02, 0.10, min(min(vUv.x, 1.0 - vUv.x),
                                                  min(vUv.y, 1.0 - vUv.y)));
      float pointerGlow = 1.0 - smoothstep(0.0, 0.75, distance(vUv, uPointer));
      vec4 sp = dotSparkle(vUv, phase * 3.0 + pointerGlow * 1.2);
      vec3 pts = glintPoints(vUv, t, 0.975);
      lin += (sp.rgb * sp.a * (0.04 + 0.85 * bm) + pts * (0.03 + 0.30 * bm + 1.00 * Kb)) * I * (0.35 + 0.65 * opH);

      /* specular hotspot rides the band */
      vec2 hs = FL.hs;
      lin += vec3(1.0, 0.97, 0.92) * (hs.x * 1.1 + hs.y * 0.20) * (0.06 + 0.94 * Kb) * I;
      return srgbEnc(lin);
    }

    /* ================================================================== *
     * CRACKED ICE - layered slim translucent facets: crumpled paper
     *
     * cracked-ice.jpg: the whole face reads as ONE continuous crumpled
     * sheet. Several overlapping mosaics of slim facets (each a touch
     * lighter or darker than what is under it: highlights / lowlights), at
     * crossing angles so no direction dominates. Edges are crisp creases that
     * catch light on the side facing the lamp; a few pastel prism flakes sit
     * on top. Tilting the card flips which facets are lit.
     *
     * A facet layer is a Voronoi mosaic in an anisotropic, rotated space:
     * complete coverage (the continuity) with straight borders and slender
     * cells (not bulky).
     * ================================================================== */

    struct Facet {
      float d;     // inside distance to the nearest border (layer units)
      float aa;    // one pixel in the same units
      vec2 n;      // outward normal of that border, in card space
      vec4 r;      // randoms of the owning facet
    };

    Facet facetLayer(vec2 cp, float ang, vec2 cellSize, float seed) {
      float ca = cos(ang);
      float sa = sin(ang);
      vec2 q = vec2(ca * cp.x + sa * cp.y, -sa * cp.x + ca * cp.y) / cellSize
             + vec2(seed * 7.13, seed * 3.37);
      vec2 ip = floor(q);
      vec2 fp = q - ip;
      vec2 pts[9];
      float md = 1e9;
      vec2 pa = vec2(0.0);
      vec2 ida = vec2(0.0);
      for (int j = 0; j < 3; j++) {
        for (int i = 0; i < 3; i++) {
          vec2 o = vec2(float(i) - 1.0, float(j) - 1.0);
          vec2 jp = ip + o + seed * 19.7;
          vec2 pp = o + vec2(hash21(jp), hash21(jp + 17.17)) * 0.92 + 0.04;
          pts[j * 3 + i] = pp;
          vec2 dv = pp - fp;
          float dd = dot(dv, dv);
          if (dd < md) { md = dd; pa = pp; ida = ip + o; }
        }
      }
      float bd = 1e9;
      vec2 bn = vec2(1.0, 0.0);
      for (int k = 0; k < 9; k++) {
        vec2 dv = pts[k] - pa;
        float l = dot(dv, dv);
        if (l > 1e-5) {
          vec2 dn = dv * inversesqrt(l);
          float dd = dot(0.5 * (pa + pts[k]) - fp, dn);
          if (dd < bd) { bd = dd; bn = dn; }
        }
      }
      Facet F;
      F.d = max(bd, 0.0);
      F.aa = max(fwidth(bd), 1e-5);
      // normals map back through the inverse transpose of (scale * rotate)
      vec2 w = bn / cellSize;
      F.n = normalize(vec2(ca * w.x - sa * w.y, sa * w.x + ca * w.y));
      F.r = hash4(ida + seed * 23.1 + 400.0);
      return F;
    }

    vec3 iceFinish(vec3 img, float phase, float I, float Ik, FoilLight FL) {
      vec2 cp = vec2(vUv.x * uCardAspect, vUv.y);
      vec2 lp = (uPointer - 0.5) * 2.0;
      vec2 ldir = normalize(vec2(0.55, 0.85) + lp * 0.9 + vec2(0.0001, 0.0002));
      vec3 iceT = mix(vec3(1.0), uIce, 0.75);
      vec3 P = srgbEnc(img); // tone-on-tone facets blend in encoded space
      float lift = 0.0;

      for (int k = 0; k < 3; k++) {
        if (k == 2 && uQuality < 0.5) break;
        float fk = float(k);
        float ang = (k == 0) ? 1.22 : ((k == 1) ? 2.18 : 0.38);
        vec2 cs = (k == 0) ? vec2(0.115, 0.30) : ((k == 1) ? vec2(0.085, 0.215) : vec2(0.058, 0.14));
        float gain = (k == 0) ? 1.00 : ((k == 1) ? 0.80 : 0.50);
        Facet F = facetLayer(cp, ang, cs, 3.0 + fk * 4.0);
        /* the facet's own tilt decides how squarely it catches the key
         * light: a lit patch of bright facets that shifts as the card tilts,
         * calm tonal relief elsewhere */
        vec2 fv = vec2(F.r.w, fract(F.r.x * 5.71 + F.r.z * 3.13)) * 2.0 - 1.0;
        float litF = lobe(FL.slope, 0.36) * FL.gate * (0.50 + 0.50 * facetCatch(FL.slope, fv, 0.22, 0.14));
        float opF = foilOpacity(litF, 0.16, 0.08, 0.80, 1.0);
        float stat = (F.r.x - 0.5) * 2.0;
        float tone = clamp(stat * 0.80 + dot((F.r.yz - 0.5) * 2.0, lp) * 0.80, -1.0, 1.0);
        float seam = smoothstep(0.0, F.aa * 1.2, F.d);       // crisp, anti-aliased crease
        float amt = Ik * gain * opF;
        P *= 1.0 + amt * seam * tone * 0.095;
        float dark = 1.0 - dot(P, vec3(0.2126, 0.7152, 0.0722));
        P += iceT * amt * seam * max(tone, 0.0) * (0.008 + 0.150 * dark * dark);
        float facing = dot(F.n, ldir);
        float rim = (1.0 - smoothstep(0.0, F.aa * 1.9, F.d)) * amt;
        P += iceT * rim * max(facing, 0.0) * (0.12 + 0.10 * max(tone, 0.0));
        P -= vec3(rim * max(-facing, 0.0) * 0.05);
        lift += max(tone, 0.0) * gain * 0.30 * opF;
      }

      vec3 lin = srgbDec(clamp(P, 0.0, 1.0));

      /* sparse pastel prism flakes */
      Shard Z = shardLayer(cp, 0.17, 0.26, 1.2, 1.0, 29.0, 0.5, 1.22, 2.0);
      if (Z.a > 0.003) {
        vec3 pA = vec3(1.0000, 0.3424, 0.6739);
        vec3 pB = vec3(0.2957, 0.7874, 1.0000);
        vec3 pC = vec3(0.5382, 0.4200, 1.0000);
        float pk = fract(Z.r.x + phase * 0.08 + Z.t * 0.12) * 3.0;
        vec3 prism = (pk < 1.0) ? mix(pA, pB, smoothstep(0.0, 1.0, pk))
                   : ((pk < 2.0) ? mix(pB, pC, smoothstep(1.0, 2.0, pk))
                                 : mix(pC, pA, smoothstep(2.0, 3.0, pk)));
        /* a prism flake flashes when ITS tilt bisects light and eye */
        float catchZ = facetCatch(FL.slope, Z.fn, 0.25, 0.12);
        float opZ = foilOpacity(lobe(FL.slope, 0.40) * FL.gate * (0.30 + 0.70 * catchZ), 0.10, 0.08, 0.80, 1.2);
        float pflash = catchZ * catchZ;
        prism = mix(prism, vec3(1.7, 1.7, 1.8), pflash * 0.8);
        lin = mix(lin, prism, Z.a * 0.40 * Ik * opZ);
        lin += mix(vec3(1.0), prism, 0.35) * Z.rim * (0.30 + 0.70 * max(dot(Z.n, ldir), 0.0)) * 0.8 * Ik * opZ;
        lift += Z.a * 0.8 * opZ;
      }

      /* specular bloom, carried mostly by the lit facets */
      vec2 hs = FL.hs;
      vec3 hotCol = mix(vec3(1.0), uIce, 0.45) * vec3(0.95, 1.0, 1.05);
      lin += hotCol * (hs.x * 1.35 + hs.y * 0.14) * (0.06 + 0.94 * min(lift, 1.0)) * I;
      return srgbEnc(lin);
    }

    /* ================================================================== *
     * STAR - sparse, flat, angular foil flakes with open gaps
     *
     * gold.jpg: a handful of large flat polygons (triangles, kites, thin
     * quads) scattered over the print with the art showing between them.
     * Luminous pink, magenta, cyan, mint, lime and orange; some flakes
     * glassy and pale. Each flake is blended TOWARD its colour (never added
     * to a dark print, which is what turned it to olive mud), has a bright
     * rim, and flashes hot white when the card tilts through its angle.
     * ================================================================== */

    /** .rgb luminous flake colour, .a its opacity: pale glass pinks dominate
     *  (translucent, they lighten the print), saturated cyan / mint / orange
     *  are the rare opaque ones */
    vec4 starRamp(float x) {
      vec4 s0 = vec4(vec3(1.0000, 0.0946, 0.3672), 0.58); // hot pink
      vec4 s1 = vec4(vec3(1.0000, 0.6038, 0.8073), 0.42); // pale glass
      vec4 s2 = vec4(vec3(1.0000, 0.1626, 0.5071), 0.60); // pink
      vec4 s3 = vec4(vec3(0.9114, 0.0331, 0.6383), 0.68); // magenta
      vec4 s4 = vec4(vec3(0.6383, 0.3931, 1.0000), 0.46); // lilac glass
      vec4 s5 = vec4(vec3(0.0100, 0.7106, 1.0000), 0.88); // cyan
      vec4 s6 = vec4(vec3(1.0000, 0.7106, 0.8900), 0.40); // pale glass
      vec4 s7 = vec4(vec3(0.0946, 1.0000, 0.3424), 0.84); // mint
      vec4 s8 = vec4(vec3(1.0000, 0.2957, 0.0174), 0.80); // orange
      vec4 s9 = vec4(vec3(1.0000, 0.1193, 0.3424), 0.56); // pink
      float u = fract(x) * 10.0;
      float f = fract(u);
      f = f * f * (3.0 - 2.0 * f);
      return (u < 1.0) ? mix(s0, s1, f) : (u < 2.0) ? mix(s1, s2, f)
           : (u < 3.0) ? mix(s2, s3, f) : (u < 4.0) ? mix(s3, s4, f)
           : (u < 5.0) ? mix(s4, s5, f) : (u < 6.0) ? mix(s5, s6, f)
           : (u < 7.0) ? mix(s6, s7, f) : (u < 8.0) ? mix(s7, s8, f)
           : (u < 9.0) ? mix(s8, s9, f) : mix(s9, s0, f);
    }

    vec3 starFinish(vec3 img, float phase, float I, float Ik, FoilLight FL) {
      vec2 cp = vec2(vUv.x * uCardAspect, vUv.y);
      vec2 lp = (uPointer - 0.5) * 2.0;
      vec2 ldir = normalize(vec2(0.50, 0.80) + lp * 0.9 + vec2(0.0001, 0.0002));
      vec3 lin = img;
      float lift = 0.0;
      vec3 warm = mix(vec3(1.0), uStarA, 0.35);

      for (int k = 0; k < 3; k++) {
        if (k == 2 && uQuality < 0.5) break;
        float fk = float(k);
        float cell = (k == 0) ? 0.165 : ((k == 1) ? 0.112 : 0.078);
        float dens = (k == 0) ? 0.60 : ((k == 1) ? 0.50 : 0.30);
        float slim = (k == 2) ? 1.5 : 1.8;
        Shard S = shardLayer(cp, cell, dens, slim, 1.0, 3.0 + fk * 4.0, 0.0, 0.0, 2.2);
        if (S.a > 0.003) {
          vec4 rc = starRamp(S.r.x + phase * 0.07 + S.t * 0.09);
          vec3 col = rc.rgb;
          float grain = hash21(floor(vUv * vec2(360.0, 520.0)) + S.r.w * 13.0);
          col *= 0.92 + 0.18 * grain;
          /* STAR is the shy finish. A flake only shows when ITS tilt (biased
           * toward flat, a few steep) bisects light and eye: tight match
           * width, a high lo threshold and gamma 1.5 on top, over a 3 %
           * noise floor. The key light's own highlight lifts the match a
           * little (flat flakes in the hotspot are caught first). Everything
           * else stays a ghost on the print. */
          float catchS = facetCatch(FL.slope, S.fn, 0.16, 0.11);
          float zone = lobe(FL.slope, 0.28);
          float opS = foilOpacity(catchS * FL.gate * (0.65 + 0.35 * zone), 0.03, 0.25, 0.88, 1.5);
          float flash = catchS * catchS * catchS;
          col = mix(col, vec3(1.8, 1.65, 1.5), flash * 0.85);
          float a = S.a * rc.a * mix(0.80, 1.0, S.r.y) * Ik * opS;
          lin = mix(lin, col, a);
          float facing = max(dot(S.n, ldir), 0.0);
          lin += mix(vec3(1.0), col, 0.25) * S.rim * Ik * (0.28 + 0.72 * facing) * 0.9 * opS;
          lift = max(lift, S.a * rc.a * opS);
        }
      }

      vec2 hs = FL.hs;
      lin += warm * (hs.x * 1.25 + hs.y * 0.20) * (0.02 + 0.98 * lift) * I;
      return srgbEnc(lin);
    }

    /* ================================================================== *
     * SPARKLE - the holo foil's dots, without the band
     *
     * The same two helpers holoFinish layers on top of its band:
     * dotSparkle() (fine tinted dot-matrix, twinkling) and glintPoints()
     * (sparse hot orange / white points). Here they are the whole finish, so
     * the print stays untouched between the specks and the sparkle spreads
     * over the entire face instead of hugging the border. Same call
     * signatures and phase / time inputs as holoFinish, so the twinkle
     * follows the tilt identically.
     * ================================================================== */

    vec3 sparkleFinish(vec3 img, float phase, float I, float Ik, FoilLight FL) {
      float t = uTime;
      vec3 lin = img;

      float pointerGlow = 1.0 - smoothstep(0.0, 0.75, distance(vUv, uPointer));

      vec2 facet;
      vec4 sp = dotSparkle(vUv, phase * 3.0 + pointerGlow * 1.2, facet);
      vec3 pts = glintPoints(vUv, t, 0.955);

      /* the dots wake around the key light's highlight, and each dot only
       * shines when its own micro-tilt catches the light: glitter that
       * shimmers with the tilt rather than a uniform field of speckle */
      float zone = lobe(FL.slope, 0.30) * FL.gate;
      float opD = foilOpacity(zone * (0.40 + 0.60 * facetCatch(FL.slope, facet, 0.24, 0.13)), 0.10, 0.06, 0.80, 1.0);
      float opG = foilOpacity(zone, 0.10, 0.06, 0.80, 1.0);
      lin += (sp.rgb * sp.a * 1.10 * opD + pts * 0.95 * opG) * I;

      /* specular hotspot catches the dots under the highlight */
      vec2 hs = FL.hs;
      float lit = clamp(sp.a * 1.6, 0.0, 1.0) * opD;
      lin += vec3(1.0, 0.97, 0.92) * (hs.x * 0.55 + hs.y * 0.08) * (0.10 + 0.90 * lit) * I;
      return srgbEnc(lin);
    }


    /* ================================================================== *
     * METAL - clean silver / gold foil, the sub-finishes of BASE
     *
     * Deliberately minimal and distinct from every other finish: no rainbow
     * band, facets, flakes or dots, and none of the palette-driven uniforms
     * (uIce / uStarA / uFoil*) - the tints are fixed so silver stays cool and
     * gold stays warm on any art.
     *
     *   body     the print is pulled part-way into a metal-tinted tone of
     *            itself (silver: cool grey, gold: warm), colour stays legible
     *   sheen    one broad anisotropic band, a function of the light field's
     *            half-vector slope, so it glides across the card with tilt
     *   grain    very fine brushed streaks, low amplitude
     *   hotspot  silver: desaturated, blows toward white; gold: restrained,
     *            shifting pale-gold at the core, never saturated
     *
     * Opacity follows foilLight() like the others (high floor: metal always
     * reads, then brightens where it catches the light).
     * ================================================================== */

    vec3 metalFinish(vec3 img, float I, float Ik, FoilLight FL, float gold) {
      vec2 cp = vec2(vUv.x * uCardAspect, vUv.y);
      float luma = dot(img, vec3(0.2126, 0.7152, 0.0722));

      /* brushed grain: streaks stretched along the sheen direction */
      vec2 bd = normalize(vec2(0.62, 0.78));
      vec2 bn = vec2(-bd.y, bd.x);
      float grain = noise(vec2(dot(cp, bd) * 6.0, dot(cp, bn) * 240.0))
                  * 0.65 + noise(vec2(dot(cp, bd) * 14.0 + 3.1, dot(cp, bn) * 520.0)) * 0.35;

      /* broad anisotropic band + soft body of the key light's reflection */
      float across = dot(FL.slope, bn) / (0.34 * SLOPE_PER_CARD);
      float band = exp(-across * across);
      float lit = clamp(band * 0.70 + FL.hs.y * 0.55, 0.0, 1.0) * FL.gate;
      float opM = foilOpacity(lit, 0.40, 0.02, 0.85, 1.0);

      /* body: the print pulled toward a metal-tinted tone of itself */
      vec3 tintS = vec3(0.78, 0.85, 1.00);
      vec3 tintG = vec3(1.00, 0.76, 0.40);
      vec3 body = vec3(luma) * mix(tintS, tintG, gold) * 1.05;
      body += mix(vec3(0.030, 0.034, 0.042), vec3(0.044, 0.030, 0.008), gold);
      vec3 lin = mix(img, body, mix(0.34, 0.48, gold) * Ik * (0.65 + 0.35 * opM));

      /* sheen band: pale cool-white vs warm champagne that drifts with tilt */
      float drift = clamp(across * 0.5, -1.0, 1.0);
      vec3 specS = vec3(0.90, 0.94, 1.00);
      vec3 specG = mix(vec3(1.00, 0.74, 0.38), vec3(1.00, 0.88, 0.62), 0.5 + 0.5 * drift);
      vec3 spec = mix(specS, specG, gold);
      lin *= 1.0 + (grain - 0.5) * 0.07 * opM * Ik;
      lin += spec * band * (0.10 + 0.18 * (1.0 - gold * 0.25)) * (0.35 + 0.65 * luma) * opM * I;

      /* hotspot: silver goes near-white, gold stays pale gold */
      vec3 hot = mix(mix(spec, vec3(1.0), 0.40), mix(vec3(1.00, 0.80, 0.46), vec3(1.00, 0.93, 0.76), FL.hs.x), gold);
      lin += hot * (FL.hs.x * 1.05 + FL.hs.y * 0.16) * (0.20 + 0.80 * opM) * (0.85 + 0.30 * grain) * I;
      return srgbEnc(lin);
    }

    // Cover-fit: crop the source rather than squashing it into the card face.
    vec2 coverUv(vec2 uv, float imageAspect, float cardAspect) {
      float ratio = imageAspect / max(cardAspect, 0.0001);
      vec2 scale = ratio > 1.0 ? vec2(1.0 / ratio, 1.0) : vec2(1.0, ratio);
      return (uv - 0.5) * scale + 0.5;
    }

    void main() {
      vec3 n = normalize(vNormal);
      vec3 v = normalize(vViewDir);
      vec3 img = texture2D(uImage, coverUv(vUv, uImageAspect, uCardAspect)).rgb;

      float fresnel = pow(1.0 - clamp(dot(n, v), 0.0, 1.0), 3.0);
      vec3 lightDir = normalize(vec3(0.35 + (uPointer.x - 0.5) * 1.1,
                                     0.6 + (uPointer.y - 0.5) * 1.1, 0.72));
      vec3 halfVec = normalize(lightDir + v);
      float ndh = clamp(dot(n, halfVec), 0.0, 1.0);
      float spec = pow(ndh, 34.0);
      float viewShift = (1.0 - abs(dot(n, v))) * 0.6 + spec * 0.5;

      // shared phase; uPointer is damped CPU-side so drags glide
      float phase = viewShift * 2.0
                  + (uPointer.x - 0.5) * 1.35
                  + (uPointer.y - 0.5) * 0.55
                  + uTime * 0.05;

      /* ---- per-finish blend weights ---- */
      float w0 = max(0.0, 1.0 - abs(uFinish - 0.0));
      float w1 = max(0.0, 1.0 - abs(uFinish - 1.0));
      float w2 = max(0.0, 1.0 - abs(uFinish - 2.0));
      float w3 = max(0.0, 1.0 - abs(uFinish - 3.0));
      float w4 = max(0.0, 1.0 - abs(uFinish - 4.0));
      float wSum = max(w0 + w1 + w2 + w3 + w4, 0.0001);

      float I = clamp(uIntensity, 0.0, 1.5);
      float Ik = min(I, 1.0);

      /* one light field per pixel, shared by every finish in play */
      FoilLight FL = foilLight();

      /* The foil composites against the print it laminates. Every finish
       * works in LINEAR light and encodes once, so hot cores blow to white
       * like the reference photos. Branches are on uniforms, so only the
       * finishes in play are paid for. */
      vec3 P = srgbEnc(img);
      vec3 final = vec3(0.0);

      if (w0 > 0.001) {
        /* base: the card's own ink, barely lifted */
        float baseAlpha = clamp(0.02 + fresnel * 0.04, 0.0, 0.96) * uIntensity;
        vec3 baseCol = mix(P, srgbEnc(vec3(0.02) / max(0.02 + fresnel * 0.04, 0.0001)), baseAlpha);
        /* sub-finish: partition of unity over plain / silver / gold, so the
         * Forge can cross-fade. uSubFinish stays 0 everywhere else (gallery),
         * which skips both metal branches and leaves plain base bit-identical. */
        float sSilver = clamp(1.0 - abs(uSubFinish - 1.0), 0.0, 1.0);
        float sGold = clamp(1.0 - abs(uSubFinish - 2.0), 0.0, 1.0);
        if (sSilver > 0.001) baseCol = mix(baseCol, metalFinish(img, I, Ik, FL, 0.0), sSilver);
        if (sGold > 0.001) baseCol = mix(baseCol, metalFinish(img, I, Ik, FL, 1.0), sGold);
        final += baseCol * w0;
      }
      if (w1 > 0.001) final += holoFinish(img, phase, viewShift, I, Ik, FL) * w1;
      if (w2 > 0.001) final += iceFinish(img, phase, I, Ik, FL) * w2;
      if (w3 > 0.001) final += starFinish(img, phase, I, Ik, FL) * w3;
      if (w4 > 0.001) final += sparkleFinish(img, phase, I, Ik, FL) * w4;
      final /= wSum;

      if (uMode > 0.5) {
        /* ---- foil overlay, laminated over the whole face ---- */
        gl_FragColor = vec4(srgbDec(final), 1.0);
      } else {
        /* ---- base: the art itself, with the foil laminated on ---- */
        vec3 col = final;
        float vignette = 1.0 - smoothstep(0.5, 1.2, length(vUv - 0.5) * 1.5);
        col *= 0.98 + vignette * 0.08;
        col *= sin(vUv.y * 420.0) * 0.015 + 0.985;
        gl_FragColor = vec4(srgbDec(col), 1.0);
      }

      // Encode for wherever we are: identity when a composer owns the buffer,
      // linear -> sRGB when this draws straight to the canvas.
      #include <tonemapping_fragment>
      #include <colorspace_fragment>
    }
  `
);

extend({ HoloShaderMaterial });

declare module '@react-three/fiber' {
  interface ThreeElements {
    holoShaderMaterial: ThreeElement<typeof HoloShaderMaterial>;
  }
}

/* ------------------------------------------------------------------ *
 * Gyro / device tilt — the pointer for phones
 * ------------------------------------------------------------------ */

export interface DeviceTiltState {
  x: number;
  y: number;
  active: boolean;
}

const tiltState: DeviceTiltState = { x: 0.5, y: 0.5, active: false };

let orientationBound = false;
let gestureBound = false;
let permission: 'unknown' | 'pending' | 'granted' | 'denied' | 'unsupported' = 'unknown';

const clamp01 = (n: number) => (n < 0 ? 0 : n > 1 ? 1 : n);

function onDeviceOrientation(event: DeviceOrientationEvent) {
  const { beta, gamma } = event;
  if (beta == null && gamma == null) return;
  const angle = typeof screen !== 'undefined' && screen.orientation ? screen.orientation.angle ?? 0 : 0;
  const rad = (angle * Math.PI) / 180;
  const b = beta ?? 0;
  const g = gamma ?? 0;
  const x = g * Math.cos(rad) + b * Math.sin(rad);
  const y = -g * Math.sin(rad) + b * Math.cos(rad);
  tiltState.x = clamp01(0.5 + x / 70);
  tiltState.y = clamp01((y - 25) / 60);
  tiltState.active = true;
}

function bindOrientation() {
  if (orientationBound || typeof window === 'undefined' || !('DeviceOrientationEvent' in window)) return;
  orientationBound = true;
  window.addEventListener('deviceorientation', onDeviceOrientation, true);
}

/** iOS 13+ gates motion sensors behind a prompt that must run in a gesture. */
export function requestDeviceTilt() {
  if (permission !== 'unknown' || typeof window === 'undefined') return;
  const DeviceOrientation = (window as unknown as { DeviceOrientationEvent?: { requestPermission?: () => Promise<string> } })
    .DeviceOrientationEvent;
  if (!DeviceOrientation) {
    permission = 'unsupported';
    return;
  }
  if (typeof DeviceOrientation.requestPermission !== 'function') {
    permission = 'granted';
    bindOrientation();
    return;
  }
  permission = 'pending';
  Promise.resolve(DeviceOrientation.requestPermission())
    .then((result) => {
      permission = result === 'granted' ? 'granted' : 'denied';
      if (result === 'granted') bindOrientation();
    })
    .catch(() => {
      permission = 'denied';
    });
}

function bindFirstGesture() {
  if (gestureBound || typeof window === 'undefined') return;
  gestureBound = true;
  const onGesture = () => {
    window.removeEventListener('pointerdown', onGesture, true);
    requestDeviceTilt();
  };
  window.addEventListener('pointerdown', onGesture, { capture: true, passive: true });
}

export function useDeviceTilt(): DeviceTiltState {
  useEffect(() => {
    bindOrientation();
    bindFirstGesture();
  }, []);
  return tiltState;
}

/* ------------------------------------------------------------------ *
 * Pointer binding
 * ------------------------------------------------------------------ */

export interface CardPointer {
  /** live hover point in card UV space (mutated in place, no re-render) */
  pointer: THREE.Vector2;
  hovered: boolean;
  bind: {
    onPointerMove: (event: ThreeEvent<PointerEvent>) => void;
    onPointerEnter: (event: ThreeEvent<PointerEvent>) => void;
    onPointerLeave: () => void;
  };
}

/**
 * Pointer in card space. Extruded geometry carries shape-space UVs, so when the
 * card's size is known the UV is rebuilt from the local hit point instead —
 * that keeps the foil highlight exactly under the cursor.
 */
export function useCardPointer(sizeW?: number, sizeH?: number): CardPointer {
  const pointer = useMemo(() => new THREE.Vector2(0.5, 0.5), []);
  const [hovered, setHovered] = useState(false);
  const setHover = useCallback((next: boolean) => setHovered(next), []);
  const local = useMemo(() => new THREE.Vector3(), []);

  const bind = useMemo(
    () => ({
      onPointerMove: (event: ThreeEvent<PointerEvent>) => {
        event.stopPropagation();
        if (sizeW && sizeH) {
          local.copy(event.point);
          event.object.worldToLocal(local);
          pointer.set(clamp01(local.x / sizeW + 0.5), clamp01(local.y / sizeH + 0.5));
        } else if (event.uv) {
          pointer.set(event.uv.x, event.uv.y);
        }
      },
      onPointerEnter: (event: ThreeEvent<PointerEvent>) => {
        event.stopPropagation();
        setHover(true);
      },
      onPointerLeave: () => setHover(false),
    }),
    [pointer, setHover, local, sizeW, sizeH]
  );

  return { pointer, hovered, bind };
}

/* ------------------------------------------------------------------ *
 * Material component
 * ------------------------------------------------------------------ */

function textureAspect(texture: THREE.Texture | null | undefined): number {
  const image = texture?.image as
    | { width?: number; height?: number; videoWidth?: number; videoHeight?: number; naturalWidth?: number; naturalHeight?: number }
    | undefined;
  const w = image?.videoWidth ?? image?.naturalWidth ?? image?.width ?? 0;
  const h = image?.videoHeight ?? image?.naturalHeight ?? image?.height ?? 0;
  return w > 0 && h > 0 ? w / h : 1;
}

export interface HoloCardMaterialProps {
  image?: THREE.Texture | null;
  finish?: FinishName;
  /** only meaningful when finish is 'base'; omitted = plain (unchanged look) */
  subFinish?: SubFinishName;
  pointer?: THREE.Vector2 | null;
  hovered?: boolean;
  intensity?: number;
  hoverBoost?: number;
  cardAspect?: number;
  timeOffset?: number;
  /** 1 = foil overlay (transparent, mask-driven), 0 = draw the art */
  overlay?: boolean;
  /** art window rect in card UV for the overlay mask */
  mask?: [number, number, number, number];
  maskFeather?: number;
  /** foil strength outside the mask (0 = card plane only) */
  outside?: number;
  /** dynamic palette driver: the foil's orders/tints follow the artwork */
  palette?: PaletteDriver | null;
  /** 'low' drops the third layer of the shard / facet finishes (weak GPUs) */
  quality?: 'high' | 'low';
  /**
   * How far finish opacity follows the light field (tilt + fake key light):
   * 1 = full dynamic opacity (default), 0 = the old constant opacity.
   */
  lighting?: number;
}

export function HoloCardMaterial({
  image = null,
  finish = 'base',
  subFinish = 'plain',
  pointer = null,
  hovered = false,
  intensity = 1,
  hoverBoost = 1.4,
  cardAspect = 0.709,
  timeOffset = 0,
  overlay = false,
  mask = [0.0569, 0.3675, 0.9431, 0.9536],
  maskFeather = 0.012,
  outside = 0.015,
  palette = null,
  quality = 'high',
  lighting = 1,
}: HoloCardMaterialProps) {
  const materialRef = useRef<THREE.ShaderMaterial>(null);
  const gl = useThree((state) => state.gl);
  const tilt = useDeviceTilt();

  const coarsePointer = useMemo(
    () => typeof window !== 'undefined' && window.matchMedia('(pointer: coarse)').matches,
    []
  );

  const anim = useRef({
    pointer: new THREE.Vector2(0.5, 0.5),
    finish: FINISH_INDEX[finish],
    sub: SUB_FINISH_INDEX[subFinish],
    intensity,
  });

  const imageAspect = useMemo(() => textureAspect(image), [image]);

  // sRGB decode + filtering for the legacy image path.
  useLayoutEffect(() => {
    if (!image) return;
    applyProps(image, {
      colorSpace: THREE.SRGBColorSpace,
      anisotropy: Math.min(8, gl.capabilities.getMaxAnisotropy()),
      needsUpdate: true,
    });
  }, [image, gl]);

  useLayoutEffect(() => {
    const material = materialRef.current;
    if (!material) return;
    const u = material.uniforms;
    u.uImage.value = image;
    u.uImageAspect.value = textureAspect(image);
    u.uCardAspect.value = cardAspect;
    u.uMode.value = overlay ? 1 : 0;
    u.uMask.value.set(mask[0], mask[1], mask[2], mask[3]);
    u.uMaskFeather.value = maskFeather;
    u.uOutside.value = outside;
    u.uQuality.value = quality === 'low' ? 0 : 1;
    u.uLightFx.value = THREE.MathUtils.clamp(lighting, 0, 1);
    material.transparent = overlay;
    material.depthWrite = !overlay;
    // the printed face is unlit and untonemapped; the foil must match that
    // pipeline or ACES greys its hues - raw sRGB keeps the foil vivid and
    // lets hotspots blow to white like the reference photos.
    material.toneMapped = !overlay;
    if (overlay) {
      // premultiplied output: the foil ADDS its light while the print shows
      // through by (1 - alpha); ice/base emit tint*alpha so they reduce to
      // the ordinary normal blend and their pixels are unchanged.
      material.blending = THREE.CustomBlending;
      material.blendSrc = THREE.OneFactor;
      material.blendDst = THREE.OneMinusSrcAlphaFactor;
      material.blendEquation = THREE.AddEquation;
    } else {
      material.blending = THREE.NormalBlending;
    }
    material.needsUpdate = true;
  }, [image, cardAspect, overlay, mask, maskFeather, outside, quality, lighting]);

  useFrame((state, rawDelta) => {
    const material = materialRef.current;
    if (!material) return;
    const a = anim.current;
    const delta = Math.min(rawDelta, 1 / 30);
    const u = material.uniforms;

    if (u.uImage.value !== image) {
      u.uImage.value = image;
      u.uImageAspect.value = imageAspect;
    }
    u.uCardAspect.value = cardAspect;

    let targetX = 0.5;
    let targetY = 0.5;
    if (coarsePointer && tilt.active) {
      targetX = tilt.x;
      targetY = tilt.y;
    } else if (pointer) {
      targetX = pointer.x;
      targetY = pointer.y;
    }
    const k = 1 - Math.exp(-10 * delta);
    a.pointer.x += (targetX - a.pointer.x) * k;
    a.pointer.y += (targetY - a.pointer.y) * k;

    a.finish = THREE.MathUtils.damp(a.finish, FINISH_INDEX[finish], 5, delta);
    a.sub = THREE.MathUtils.damp(a.sub, SUB_FINISH_INDEX[subFinish], 6, delta);
    a.intensity = THREE.MathUtils.damp(a.intensity, intensity * (hovered ? hoverBoost : 1), 8, delta);

    u.uTime.value = state.clock.elapsedTime + timeOffset;
    u.uPointer.value.copy(a.pointer);
    u.uFinish.value = a.finish;
    u.uSubFinish.value = a.sub;
    u.uIntensity.value = a.intensity;

    /* the palette glides in the engine; the shader just tracks it */
    if (palette) {
      const sh = palette.current.shader;
      u.uFoilB.value.set(sh.foilB[0], sh.foilB[1], sh.foilB[2]);
      u.uFoilC.value.set(sh.foilC[0], sh.foilC[1], sh.foilC[2]);
      u.uFoilD.value.set(sh.foilD[0], sh.foilD[1], sh.foilD[2]);
      u.uIce.value.set(sh.ice[0], sh.ice[1], sh.ice[2]);
      u.uStarA.value.set(sh.starA[0], sh.starA[1], sh.starA[2]);
      u.uStarB.value.set(sh.starB[0], sh.starB[1], sh.starB[2]);
    }
  });

  return <holoShaderMaterial ref={materialRef} />;
}

export { HoloShaderMaterial };
