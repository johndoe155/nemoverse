'use client';
import { Component, useEffect, useState, type ReactNode } from 'react';

/**
 * True when this browser can actually create a WebGL context.
 *
 * Browsers with hardware acceleration off, a blocklisted GPU, or too many live
 * contexts return null from getContext(). Three.js then throws
 * "Error creating WebGL context", and if nothing catches it React unmounts the
 * whole tree and the user sees "This page couldn't load".
 */
export function hasWebGL(): boolean {
  try {
    const canvas = document.createElement('canvas');
    const gl =
      canvas.getContext('webgl2') ||
      canvas.getContext('webgl') ||
      canvas.getContext('experimental-webgl');
    if (!gl) return false;
    // hand the probe context back right away; browsers cap live contexts (~16)
    (gl as WebGLRenderingContext).getExtension('WEBGL_lose_context')?.loseContext();
    return true;
  } catch {
    return false;
  }
}

class WebGLBoundary extends Component<
  { fallback: ReactNode; children: ReactNode },
  { failed: boolean }
> {
  state = { failed: false };

  static getDerivedStateFromError() {
    return { failed: true };
  }

  componentDidCatch(error: unknown) {
    console.warn('[WebGLGuard] 3D scene disabled, showing fallback:', error);
  }

  render() {
    return this.state.failed ? this.props.fallback : this.props.children;
  }
}

/**
 * Wrap any react-three-fiber <Canvas> in this. It renders `fallback` when WebGL
 * is unavailable up front, or when the scene throws while mounting/rendering.
 * While the capability check runs (one effect tick) it renders nothing.
 */
export function WebGLGuard({
  children,
  fallback = null,
}: {
  children: ReactNode;
  fallback?: ReactNode;
}) {
  const [supported, setSupported] = useState<boolean | null>(null);

  useEffect(() => {
    setSupported(hasWebGL());
  }, []);

  if (supported === null) return null;
  if (!supported) return <>{fallback}</>;
  return <WebGLBoundary fallback={fallback}>{children}</WebGLBoundary>;
}
