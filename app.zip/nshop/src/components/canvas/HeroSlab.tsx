'use client';
import { useRef, useMemo } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import * as THREE from 'three';
import { useTexture } from '@react-three/drei';
import { useVaultStore } from '@/store/useVaultStore';
import { easing } from 'maath';
import '@/components/canvas/HeroHoloMaterial'; // registers heroHoloShaderMaterial via extend()

export function HeroSlab() {
  const groupRef = useRef<THREE.Group>(null);
  const matFrontRef = useRef<any>(null);
  const matBackRef = useRef<any>(null);
  const finishType = useVaultStore((s) => s.finishType);
  const nftData = useVaultStore((s) => s.nftData);
  // Touch devices: pointermove fires mid-scroll with huge positional jumps,
  // which made the slab lurch. On coarse pointers we skip pointer-driven tilt
  // and uPointer chase entirely — the auto-float carries the motion instead.
  const isCoarsePointer = useMemo(
    () => typeof window !== 'undefined' && window.matchMedia('(pointer: coarse)').matches,
    []
  );
  
  // Map finish type to shader uniform
  const finishMap = { 'base': 0, 'holo': 1, 'cracked-ice': 2, 'star': 3, 'sparkle': 4 } as const;
  
  // Default texture or NFT
  const imageUrl = nftData?.image || 'https://picsum.photos/seed/nemohero/800/800';
  const texture = useTexture(imageUrl);
  
  // Enhance texture
  useMemo(() => {
    if (texture) {
      texture.colorSpace = THREE.SRGBColorSpace;
      texture.minFilter = THREE.LinearFilter;
    }
  }, [texture]);

  useFrame((state, delta) => {
    const group = groupRef.current;
    if (!group) return;

    const time = state.clock.elapsedTime;
    // Pointer is read imperatively — never a React re-render source.
    const { pointer } = useVaultStore.getState();

    // Hero-local scroll: 0 at top -> 1 after one viewport. Read straight from
    // window.scrollY so it behaves identically under Lenis (desktop) and
    // native touch scrolling — the store's scrollProgress is Lenis-event-driven
    // and does not tick on touch, which is why the parallax felt dead on phones.
    const vh = window.innerHeight || 1;
    const local = Math.min(1, Math.max(0, (window.scrollY || 0) / vh));

    for (const m of [matFrontRef.current, matBackRef.current]) {
      if (!m) continue;
      m.uniforms.uTime.value = time;
      m.uniforms.uFinish.value = finishMap[finishType];
      if (!isCoarsePointer) {
        easing.damp2(m.uniforms.uPointer.value, [pointer.x, 1 - pointer.y], 0.2, delta);
      } else {
        easing.damp2(m.uniforms.uPointer.value, [0.5, 0.5], 0.6, delta);
      }
    }

    // RIGID SLAB: tilt/parallax apply to the GROUP so card, border, label and
    // foil move as one unit. Tilting only the card mesh made it swing outside
    // its static border box, exposing large sheets of orange-lit dark plastic
    // (the "brown flood") where the boxes intersected. Amplitudes are sized
    // for this hero-local driver (the old ones were tuned for whole-page
    // progress — ~10x too hot): max ~7deg, gentle recede, thin clean edge.
    const scrollTiltX = -local * 0.12;
    if (!isCoarsePointer) {
      const targetRotX = (pointer.y - 0.5) * 0.4 + scrollTiltX;
      const targetRotY = (pointer.x - 0.5) * -0.65;
      easing.dampE(group.rotation, [targetRotX, targetRotY, 0], 0.4, delta);
    } else {
      // Touch: scroll is the only tilt driver — inherently smooth, never jumpy
      // (unlike pointermove, which fires mid-scroll with positional jumps).
      easing.dampE(group.rotation, [scrollTiltX, 0, 0], 0.5, delta);
    }

    // Parallax: recede + slight grow — apparent size shrinks ~11% over the
    // first viewport, a true recede (the old 0.5 growth cancelled perspective,
    // which is also why it read as "no parallax").
    easing.damp(group.position, 'z', -local * 1.2, 0.5, delta);
    const s = 1 + local * 0.15;
    easing.damp3(group.scale, [s, s, s], 0.5, delta);

    // Subtle float
    group.position.y = Math.sin(time * 0.5) * 0.05;

    // Sanitary: this canvas is FIXED and sits behind every section; opaque
    // section backgrounds normally hide the slab, but during very fast scrolls
    // the compositor can present before the newly-exposed tiles are painted,
    // flashing the slab mid-page. Past the hero there is nothing to draw —
    // skip it entirely so a paint-lag frame shows only the dark page.
    group.visible = local < 0.95;
  });

  return (
    <group ref={groupRef}>
      {/* Main slab — 6-material box: dark plastic sides, holo shader on the
          front/back faces only, so tilted sides render as clean plastic. */}
      <mesh position={[0, 0, 0]} scale={1}>
        <boxGeometry args={[2.2, 3.0, 0.12]} />
        <meshPhysicalMaterial attach="material-0" color="#141414" roughness={0.35} metalness={0.25} clearcoat={0.8} clearcoatRoughness={0.25} />
        <meshPhysicalMaterial attach="material-1" color="#141414" roughness={0.35} metalness={0.25} clearcoat={0.8} clearcoatRoughness={0.25} />
        <meshPhysicalMaterial attach="material-2" color="#0f0f0f" roughness={0.35} metalness={0.25} clearcoat={0.8} clearcoatRoughness={0.25} />
        <meshPhysicalMaterial attach="material-3" color="#0f0f0f" roughness={0.35} metalness={0.25} clearcoat={0.8} clearcoatRoughness={0.25} />
        {/* @ts-ignore */}
        <heroHoloShaderMaterial attach="material-4" ref={matFrontRef} uImage={texture} uFinish={finishMap[finishType]} uIntensity={1} uTime={0} uPointer={new THREE.Vector2(0.5, 0.5)} />
        {/* @ts-ignore */}
        <heroHoloShaderMaterial attach="material-5" ref={matBackRef} uImage={texture} uFinish={finishMap[finishType]} uIntensity={1} uTime={0} uPointer={new THREE.Vector2(0.5, 0.5)} />
      </mesh>
      
      {/* Slab border - thicker plastic */}
      <mesh position={[0, 0, -0.01]} scale={[1.08, 1.06, 1]}>
        <boxGeometry args={[2.2, 3.0, 0.1]} />
        <meshPhysicalMaterial
          color="#1a1a1a"
          roughness={0.2}
          metalness={0.1}
          clearcoat={1}
          clearcoatRoughness={0.1}
          transparent
          opacity={0.9}
        />
      </mesh>
      
      {/* Label area at bottom */}
      <mesh position={[0, -1.1, 0.07]}>
        <planeGeometry args={[1.8, 0.5]} />
        <meshStandardMaterial color="#0a0a0a" roughness={0.8} />
      </mesh>
      
      {/* Foil edge */}
      <mesh position={[0, 0, 0.065]}>
        <boxGeometry args={[2.22, 3.02, 0.01]} />
        <meshBasicMaterial color="#FF4D00" transparent opacity={0.15} />
      </mesh>
    </group>
  );
}

// Simpler version for gallery
export function GallerySlab({ image, finish = 'holo', position = [0,0,0] as any, rotation = [0,0,0] as any }: any) {
  const meshRef = useRef<THREE.Mesh>(null);
  const materialRef = useRef<any>(null);
  const texture = useTexture(image);
  const finishMap = { 'base': 0, 'holo': 1, 'cracked-ice': 2, 'star': 3, 'sparkle': 4 } as const;

  useFrame((state, delta) => {
    if (!materialRef.current) return;
    materialRef.current.uniforms.uTime.value = state.clock.elapsedTime;
    materialRef.current.uniforms.uFinish.value = finishMap[finish as keyof typeof finishMap] ?? 1;
    // slow auto rotation
    if (meshRef.current) {
      meshRef.current.rotation.y += delta * 0.1;
    }
  });

  return (
    <mesh ref={meshRef} position={position} rotation={rotation}>
      <boxGeometry args={[1.6, 2.2, 0.08]} />
      {/* @ts-ignore */}
      <heroHoloShaderMaterial
        ref={materialRef}
        uImage={texture}
        uFinish={finishMap[finish as keyof typeof finishMap] ?? 1}
        uPointer={new THREE.Vector2(0.5, 0.5)}
      />
    </mesh>
  );
}
