'use client';
import { EffectComposer, DepthOfField, ToneMapping } from '@react-three/postprocessing';
import { ToneMappingMode } from 'postprocessing';

/**
 * Focal blur for the vault field: slabs sweeping past the lens go soft, the
 * middle distance stays sharp, as in the reference. Loaded on demand by
 * GalleryPitPhysics (desktop only) and wrapped there so a failure here only
 * costs the blur, never the vault.
 *
 *   focus   camera-space distance that is perfectly sharp (world units)
 *   range   how deep the sharp band is around `focus`
 *   bokeh   blur strength
 *
 * Rendering through a composer skips the renderer's tone mapping (it only
 * applies to the screen), so ACES is re-applied last to keep the slabs
 * looking exactly as they do without this pass.
 */
export default function FocalBlur({ focus, range, bokeh }: { focus: number; range: number; bokeh: number }) {
  return (
    <EffectComposer multisampling={4} enableNormalPass={false}>
      <DepthOfField worldFocusDistance={focus} worldFocusRange={range} bokehScale={bokeh} resolutionScale={0.5} />
      <ToneMapping mode={ToneMappingMode.ACES_FILMIC} />
    </EffectComposer>
  );
}
