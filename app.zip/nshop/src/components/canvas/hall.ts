/**
 * The vault hall: everything about the corridor that needs no React and no three.js.
 *
 *   planHall      anchor pose per card: a volumetric field of slabs scattered
 *                 around the -Z axis (Zero-G reference layout, shared by both modes)
 *   cardVisibility distance fade + culling (with hysteresis) for one card
 *   HallScroll    wheel / drag / key input -> damped, rubber-banded travel,
 *                 with a hand-off back to the page so the hall never traps scroll
 *   buildHallLines the architecture (bulkhead ribs, rails, the far aperture)
 *   planDrift     seeded float constants (ported from the old zero-g planner)
 *
 * World: the camera slides along -Z from z = 0. `travel` is how far it has gone,
 * so a card at anchor z is `dz = -z - travel` units ahead of the lens.
 */

const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));
const smoothstep = (e0: number, e1: number, x: number) => {
  const t = clamp((x - e0) / (e1 - e0), 0, 1);
  return t * t * (3 - 2 * t);
};

/* ------------------------------------------------------------------ *
 * Layout
 * ------------------------------------------------------------------ */

export const HALL = {
  /** distance from the lens to the first card at rest */
  entry: 3.4,
  /** keyboard / button travel: roughly three cards of the densest layout */
  nudge: 1.2,
  /** how far past the last card the camera stops */
  standOff: 3.0,
} as const;

/**
 * The field: cards are scattered through the whole cross-section of a square
 * "tunnel" around the -Z axis (not pinned to two walls). Perspective does the
 * rest: far cards bunch up small near the middle of the frame, near cards sweep
 * out to the edges big and cropped, and everything overlaps.
 */
export const FIELD = {
  /** depth (units ahead of the lens) at which the field's edge meets the frame edge */
  refDepth: 4.6,
  /** innermost ring, as a fraction of the field */
  rMin: 0.1,
  /** the lens's clear lane: a slab's centre stays outside this box (half a slab + the camera's parallax), so the camera glides past slabs, never through one */
  laneX: 0.62,
  laneY: 0.95,
  /** z gap between consecutive cards: dense on wide stages, roomier on phones */
  stepNarrow: 0.66,
  stepWide: 0.42,
  /** facing: lean toward the axis with distance from it, plus seeded jitter (rad) */
  yawLean: 0.26,
  yawJitter: 0.24,
  pitchLean: 0.14,
  pitchJitter: 0.12,
  rollJitter: 0.34,
  /** the slab's footprint, for the no-interpenetration pass */
  footW: 1.05,
  footH: 1.75,
  /** footprints this close in x/y must also be this far apart in z */
  minGapZ: 0.7,
} as const;

/** Vertical field of view for a stage aspect: portrait stages get a wider lens so the field still reads. */
export const BASE_FOV = 50;
export const fovFor = (aspect: number) => clamp(BASE_FOV + (1.2 - aspect) * 22, BASE_FOV, 66);

export interface HallLayout {
  count: number;
  /** x,y,z per card */
  pos: Float32Array;
  yaw: Float32Array;
  pitch: Float32Array;
  roll: Float32Array;
  /** -1 left of the axis, +1 right (hover feedback / HUD only) */
  side: Int8Array;
  /** z gap between consecutive cards */
  step: number;
  /** distance fade for this stage size (wide stages see further) */
  fade: HallFade;
  /** max camera travel */
  length: number;
  /** z of the last card */
  zEnd: number;
  halfW: number;
  halfH: number;
}

export interface HallFade {
  from: number;
  to: number;
  cullFar: number;
}

/** Stable per-index noise in [0,1): a card keeps its jitter when the deck is filtered. */
function hash(i: number, k: number) {
  let h = Math.imul(i + 1, 0x9e3779b1) ^ Math.imul(k + 1, 0x85ebca6b);
  h ^= h >>> 15;
  h = Math.imul(h, 0x2c1b3c6d);
  h ^= h >>> 12;
  return ((h >>> 0) % 100000) / 100000;
}

const GOLDEN_ANGLE = 2.399963229728653;

/**
 * `aspect` = stage width / height. The field is sized from the actual lens, so
 * a phone in portrait and an ultrawide both get a frame full of slabs: the
 * cross-section follows the stage aspect, and the z-spacing and draw distance
 * tighten / relax with it.
 */
export function planHall(count: number, aspect: number): HallLayout {
  const t = clamp((aspect - 0.6) / 1.4, 0, 1);
  const step = FIELD.stepNarrow + (FIELD.stepWide - FIELD.stepNarrow) * t;
  const tanH = Math.tan((fovFor(aspect) * Math.PI) / 360);
  const fieldH = tanH * FIELD.refDepth;
  const fieldW = fieldH * clamp(aspect, 0.5, 2.6);
  const layout: HallLayout = {
    count,
    pos: new Float32Array(count * 3),
    yaw: new Float32Array(count),
    pitch: new Float32Array(count),
    roll: new Float32Array(count),
    side: new Int8Array(count),
    step,
    fade: { from: 7 + 1.0 * t, to: 12.5 + 1.5 * t, cullFar: 13.5 + 1.5 * t },
    length: 0,
    zEnd: -HALL.entry,
    // the room encloses the field plus half a slab and a little air
    halfW: fieldW + 0.85,
    halfH: fieldH + 1.1,
  };

  /** square-ring placement: angle around the axis + ring fraction, kept out of the lens lane */
  const place = (i: number, bump: number) => {
    const ang = i * GOLDEN_ANGLE + (hash(i, 0) - 0.5) * 0.5 + bump;
    const ring = FIELD.rMin + (1 - FIELD.rMin) * Math.pow(hash(i, 1), 0.8);
    const c = Math.cos(ang);
    const s = Math.sin(ang);
    const m = Math.max(Math.abs(c), Math.abs(s));
    let x = (c / m) * ring * fieldW;
    let y = (s / m) * ring * fieldH;
    if (Math.abs(x) < FIELD.laneX && Math.abs(y) < FIELD.laneY) {
      if (Math.abs(x) / FIELD.laneX >= Math.abs(y) / FIELD.laneY) x = (x < 0 ? -1 : 1) * FIELD.laneX;
      else y = (y < 0 ? -1 : 1) * FIELD.laneY;
    }
    return { x, y };
  };

  for (let i = 0; i < count; i++) {
    const z = -(HALL.entry + i * step + (hash(i, 5) - 0.5) * step * 0.5);
    // nudge the angle until no earlier card's footprint is stacked too close in z
    let best = place(i, 0);
    for (let tries = 0; tries < 16; tries++) {
      const p = place(i, tries * 0.37);
      best = p;
      let clash = false;
      for (let j = 0; j < i && !clash; j++) {
        if (
          Math.abs(layout.pos[j * 3 + 2] - z) < FIELD.minGapZ &&
          Math.abs(layout.pos[j * 3] - p.x) < FIELD.footW &&
          Math.abs(layout.pos[j * 3 + 1] - p.y) < FIELD.footH
        ) clash = true;
      }
      if (!clash) break;
    }
    const xn = best.x / fieldW;
    const yn = best.y / fieldH;
    layout.side[i] = best.x < 0 ? -1 : 1;
    layout.pos[i * 3] = best.x;
    layout.pos[i * 3 + 1] = best.y;
    layout.pos[i * 3 + 2] = z;
    // lean in toward the axis, like slabs pinned around a room; jitter keeps it loose
    layout.yaw[i] = -xn * FIELD.yawLean + (hash(i, 2) - 0.5) * FIELD.yawJitter;
    layout.pitch[i] = yn * FIELD.pitchLean + (hash(i, 3) - 0.5) * FIELD.pitchJitter;
    layout.roll[i] = (hash(i, 4) - 0.5) * FIELD.rollJitter;
  }
  layout.zEnd = count > 0 ? layout.pos[(count - 1) * 3 + 2] : -HALL.entry;
  layout.length = count > 1 ? Math.max(0, -layout.zEnd - HALL.standOff) : 0;
  return layout;
}

/** 1-based index of the slab you are standing at, for the HUD. */
export function slabAt(travel: number, count: number, step: number) {
  return count === 0 ? 0 : clamp(Math.round(travel / Math.max(step, 1e-3)) + 1, 1, count);
}

/* ------------------------------------------------------------------ *
 * Distance fade + culling
 * ------------------------------------------------------------------ */

export const FADE: HallFade & { cullNear: number; hysteresis: number } = {
  /** veil starts / is fully opaque (units ahead of the lens); planHall overrides per stage size */
  from: 8,
  to: 14,
  cullFar: 15,
  /** a card that has passed the lens */
  cullNear: -1,
  /** margin before a culled card is brought back (no flicker at the edge) */
  hysteresis: 2,
};

/** `veil`: 0 = clear, 1 = dissolved into the void. `cull`: skip render + physics. */
export function cardVisibility(dz: number, wasCulled: boolean, fade: HallFade = FADE) {
  const far = smoothstep(fade.from, fade.to, dz);
  const near = 1 - smoothstep(0.3, 1.2, dz);
  const veil = Math.max(far, near);
  const cull = wasCulled
    ? !(dz < fade.cullFar - FADE.hysteresis && dz > FADE.cullNear + FADE.hysteresis * 0.5)
    : dz > fade.cullFar || dz < FADE.cullNear;
  return { veil, cull };
}

/** Entrance sweep: a front of light that travels down the hall. t01 in [0,1]. */
export function introReveal(t01: number, dz: number) {
  const e = 1 - (1 - t01) ** 3;
  return clamp((e * 38 - dz) / 10, 0, 1);
}

/* ------------------------------------------------------------------ *
 * Scroll physics
 * ------------------------------------------------------------------ */

export const SCROLL = {
  /** world units per wheel px / per finger px (the field is ~3x denser per unit than the old two-wall hall) */
  wheel: 0.005,
  drag: 0.007,
  /** critically damped follow time (s); heavier = more weight */
  smoothTime: 0.55,
  smoothTimeReduced: 0.12,
  /** how far past an end the hall can be pulled, and how hard it resists */
  overMax: 1.1,
  /** px of sustained outward push before the page takes over */
  handoffWheel: 380,
  handoffDrag: 110,
  /** gap (ms) that separates two wheel gestures */
  gestureGap: 200,
  /** a page scroll this recent (ms) keeps the whole next gesture on the page */
  pageRecent: 140,
  /** seconds without input before an overscrolled hall relaxes */
  relaxAfter: 0.09,
  momentum: 0.3,
} as const;

/** Unity-style critically damped spring: weighted, no overshoot, velocity-continuous. */
export function smoothDamp(cur: number, target: number, vel: number, smoothTime: number, dt: number) {
  const omega = 2 / Math.max(smoothTime, 1e-4);
  const x = omega * dt;
  const e = 1 / (1 + x + 0.48 * x * x + 0.235 * x * x * x);
  const change = cur - target;
  const temp = (vel + omega * change) * dt;
  return { value: target + (change + temp) * e, vel: (vel - omega * temp) * e };
}

export class HallScroll {
  pos = 0;
  target = 0;
  vel = 0;
  min = 0;
  max = 0;
  reduced = false;

  private lastInput = -1e9;
  private lastWheel = -1e9;
  private lastPage = -1e9;
  private owner: 'hall' | 'page' = 'hall';
  private pressure = 0;
  private dragVel = 0;

  setRange(max: number) {
    this.max = Math.max(0, max);
    this.target = clamp(this.target, this.min, this.max);
  }
  reset(pos = 0) {
    this.pos = pos;
    this.target = clamp(0, this.min, this.max);
    this.vel = 0;
    this.pressure = 0;
  }
  /** call from a window scroll listener */
  notePageScroll(now: number) {
    this.lastPage = now;
  }
  get progress() {
    return this.max > 0 ? clamp(this.pos / this.max, 0, 1) : 0;
  }
  /** is the target already at an end that `dir` pushes against */
  private pinned(dir: number) {
    return (dir < 0 && this.target <= this.min + 1e-3) || (dir > 0 && this.target >= this.max - 1e-3);
  }
  /** apply `units` of travel; pulling past an end meets quadratic resistance */
  private push(units: number) {
    const over = this.target < this.min ? this.min - this.target : this.target > this.max ? this.target - this.max : 0;
    const outward = (units < 0 && this.target <= this.min) || (units > 0 && this.target >= this.max);
    const k = outward ? (1 - clamp(over / SCROLL.overMax, 0, 1)) ** 2 : 1;
    this.target = clamp(this.target + units * k, this.min - SCROLL.overMax, this.max + SCROLL.overMax);
  }

  /** Wheel input in px. Returns true if the hall consumed it (caller prevents default). */
  wheel(dy: number, now: number): boolean {
    if (now - this.lastWheel > SCROLL.gestureGap) {
      this.owner = now - this.lastPage < SCROLL.pageRecent ? 'page' : 'hall';
      this.pressure = 0;
    }
    this.lastWheel = now;
    if (this.owner === 'page') return false;
    const dir = Math.sign(dy);
    if (this.pinned(dir)) {
      this.pressure += Math.abs(dy);
      if (this.pressure > SCROLL.handoffWheel) {
        this.owner = 'page';
        return false;
      }
    } else {
      this.pressure = Math.max(0, this.pressure - Math.abs(dy));
    }
    this.lastInput = now;
    this.push(dy * SCROLL.wheel);
    return true;
  }

  dragStart(now: number) {
    this.pressure = 0;
    this.dragVel = 0;
    this.lastInput = now;
  }
  /** Finger / pointer delta in px. Returns px the page should scroll instead (0 when the hall took it). */
  dragMove(dy: number, now: number, dt: number): number {
    const dir = -Math.sign(dy);
    if (this.pinned(dir) && this.pressure >= SCROLL.handoffDrag) return -dy;
    if (this.pinned(dir)) this.pressure += Math.abs(dy);
    else this.pressure = Math.max(0, this.pressure - Math.abs(dy));
    this.lastInput = now;
    const before = this.target;
    this.push(-dy * SCROLL.drag);
    const inst = (this.target - before) / Math.max(dt, 1 / 240);
    this.dragVel += (inst - this.dragVel) * 0.35;
    return 0;
  }
  dragEnd(now: number) {
    this.lastInput = now;
    this.target = clamp(this.target + this.dragVel * SCROLL.momentum, this.min, this.max);
    this.dragVel = 0;
  }
  nudge(units: number, now: number) {
    this.lastInput = now;
    this.target = clamp(this.target + units, this.min, this.max);
  }
  jumpTo(units: number, now: number) {
    this.lastInput = now;
    this.target = clamp(units, this.min, this.max);
  }

  /** advance one frame; `now` in ms */
  update(dt: number, now: number) {
    const outside = this.target < this.min || this.target > this.max;
    if (outside && now - this.lastInput > SCROLL.relaxAfter * 1000) {
      const home = clamp(this.target, this.min, this.max);
      this.target += (home - this.target) * (1 - Math.exp(-dt * 7));
    }
    const s = smoothDamp(this.pos, this.target, this.vel, this.reduced ? SCROLL.smoothTimeReduced : SCROLL.smoothTime, dt);
    this.pos = s.value;
    this.vel = s.vel;
  }
}

/* ------------------------------------------------------------------ *
 * Architecture lines
 * ------------------------------------------------------------------ */

export const RIB_PITCH = 4;
const PAPER: [number, number, number] = [0.96, 0.95, 0.94];
const ORANGE: [number, number, number] = [1, 0.302, 0];

/** Segment pairs: bulkhead ribs, four corner rails, and the orange aperture at the far end. */
export function buildHallLines(layout: HallLayout) {
  const { halfW: w, halfH: h, zEnd } = layout;
  const zNear = 6;
  const zFar = zEnd - 7;
  const pos: number[] = [];
  const col: number[] = [];
  const alp: number[] = [];
  const seg = (a: number[], b: number[], c: number[], alpha: number) => {
    pos.push(...a, ...b);
    col.push(...c, ...c);
    alp.push(alpha, alpha);
  };
  const rect = (z: number, hw: number, hh: number, c: number[], alpha: number) => {
    const p: number[][] = [[-hw, -hh, z], [hw, -hh, z], [hw, hh, z], [-hw, hh, z]];
    for (let i = 0; i < 4; i++) seg(p[i], p[(i + 1) % 4], c, alpha);
  };
  for (let z = 0; z > zFar; z -= RIB_PITCH) rect(z, w, h, PAPER, 0.1);
  for (const sx of [-1, 1]) for (const sy of [-1, 1]) seg([sx * w, sy * h, zNear], [sx * w, sy * h, zFar], PAPER, 0.07);
  rect(zEnd - 5, 1.1, 1.7, ORANGE, 0.85);
  rect(zEnd - 5, 1.02, 1.62, ORANGE, 0.25);
  return { position: new Float32Array(pos), color: new Float32Array(col), alpha: new Float32Array(alp) };
}

/* ------------------------------------------------------------------ *
 * Float (drift) constants, seeded per card
 * ------------------------------------------------------------------ */

export interface HallDrift {
  /** six channels per card: x,y,z then pitch,yaw,roll */
  accel: Float32Array;
  freq: Float32Array;
  phase: Float32Array;
}

export function planDrift(count: number, linearDamping: number, angularDamping: number): HallDrift {
  const d: HallDrift = {
    accel: new Float32Array(count * 6),
    freq: new Float32Array(count * 6),
    phase: new Float32Array(count * 6),
  };
  for (let i = 0; i < count; i++) {
    const amp = 0.6 + hash(i, 10) * 0.8;
    for (let a = 0; a < 6; a++) {
      const w = 0.35 + hash(i, 11 + a) * 0.5;
      const linear = a < 3;
      const damping = linear ? linearDamping : angularDamping;
      const dist = (linear ? 0.03 : 0.02) * amp;
      d.accel[i * 6 + a] = dist * w * Math.sqrt(w * w + damping * damping);
      d.freq[i * 6 + a] = w;
      d.phase[i * 6 + a] = hash(i, 20 + a) * Math.PI * 2;
    }
  }
  return d;
}
