'use client';
import { Component, Suspense, lazy, useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { Canvas, useFrame, useThree, type ThreeEvent } from '@react-three/fiber';
import { Physics, RigidBody, CuboidCollider, RapierRigidBody } from '@react-three/rapier';
import type { ComponentRef, MutableRefObject } from 'react';
import * as THREE from 'three';
import { Environment, Lightformer } from '@react-three/drei';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Slab } from '@/components/canvas/slab/Slab';
import { squircle } from '@/components/canvas/slab/geometry';
import { WebGLGuard } from '@/components/canvas/WebGLGuard';
import { SLAB_SPEC } from '@/components/canvas/slab/SlabSpec';
import { slabCards, type SlabCard } from '@/data/slabCards';
import { useVaultStore } from '@/store/useVaultStore';
import {
  BASE_FOV,
  HALL,
  HallScroll,
  buildHallLines,
  cardVisibility,
  fovFor,
  introReveal,
  planDrift,
  planHall,
  slabAt,
  type HallDrift,
  type HallLayout,
} from '@/components/canvas/hall';

/* depth-of-field is a progressive enhancement: loaded on demand, desktop only, and dropped
   (not fatal) if the post-processing chunk ever fails */
const FocalBlur = lazy(() => import('@/components/canvas/FocalBlur'));

/** Flip to false to ship the vault without the focal-blur pass. */
const FOCAL_BLUR = true;
/** camera-space distances (world units): sharp between focus - range/2 and focus + range/2, soft outside */
const BLUR = { focus: 6.5, range: 6, bokeh: 3 };

/* ------------------------------------------------------------------ *
 * Vault tuning
 *
 * The vault is a field now: slabs are scattered through the whole cross-section
 * of a tunnel that runs down -Z (see hall.ts, planHall), overlapping the way the
 * reference does, and scroll flies the camera through it. Every card is still a
 * Rapier body (mass, restitution, collisions, drag + toss), held to its mount by
 * a damped tether. Gravity and Zero-G share this one layout: the mode only
 * changes how tightly the tether holds and how freely the slab drifts, and it
 * blends in over a moment, so flipping the switch never moves a slab to a new place.
 * ------------------------------------------------------------------ */

const WALL = 0.5;
const BODY = {
  w: SLAB_SPEC.w * 0.98,
  h: SLAB_SPEC.h * 0.99,
  d: SLAB_SPEC.zFront * 2 * 1.05,
};
const MASS = 0.62;
const GRAVITY_Y = -2.6;
const LINEAR_DAMPING = 1.6;
const ANGULAR_DAMPING = 1.1;
/** the page's void: veils and architecture dissolve into exactly this */
const VOID = '#050505';

/** tether to the mount: stiffness (1/s²), damping (1/s). Gravity hangs tight, zero-g floats loose. */
const TETHER = {
  gravity: { k: 15, c: 4.4 },
  zeroG: { k: 5, c: 2.4 },
};
/** how fast the mode blends (1/s), and how much looser the float is in zero-g */
const MODE_BLEND = 2.6;
const FLOAT = { xy: 2.2, z: 0.8, tilt: 1.5 };
/** how quickly a card turns to its target orientation, and the cap (rad/s) */
const TURN = { rate: 7, max: 4, follow: 14 };
/** hover: fraction of the way a card turns toward the lens, and how far it steps forward out of the crowd */
const HOVER = { turn: 0.55, lift: 0.7, scale: 1.06 };
const INTRO_SECONDS = 2.2;

const DRAG = {
  stiffness: 90,
  damping: 16,
  maxToss: 15,
  mouseThreshold: 6,
  touchThreshold: 10,
  /** touch: a finger on a slab only grabs it after resting this long (ms) within `touchSlop` px;
      moving sooner scrolls the vault instead, so a screen full of slabs never traps the swipe */
  touchHold: 220,
  touchSlop: 8,
  scaleEpsilon: 0.003,
};

const _raycaster = new THREE.Raycaster();
const _ndc = new THREE.Vector2();
const _planeHit = new THREE.Vector3();
const _sample = new THREE.Vector3();
const _clamp = THREE.MathUtils.clamp;
const _euler = new THREE.Euler();
const _qCur = new THREE.Quaternion();
const _qTgt = new THREE.Quaternion();
const _qErr = new THREE.Quaternion();
const _rotErr = new THREE.Vector3();
const _v = { x: 0, y: 0, z: 0 };
const nullRaycast = () => null;

/** shared, built once: the slab's own silhouette, used as the depth veil */
let veilGeometry: THREE.ShapeGeometry | null = null;
function getVeilGeometry() {
  if (!veilGeometry) {
    veilGeometry = new THREE.ShapeGeometry(
      squircle(SLAB_SPEC.w * 0.995, SLAB_SPEC.h * 0.995, SLAB_SPEC.radius, SLAB_SPEC.cornerPower, 8)
    );
  }
  return veilGeometry;
}

/** Shortest-arc turn from `cur` to `_qTgt`, written to _rotErr as axis * angle. */
function turnToTarget(cur: { x: number; y: number; z: number; w: number }) {
  _qCur.set(cur.x, cur.y, cur.z, cur.w);
  _qErr.copy(_qTgt).multiply(_qCur.invert());
  if (_qErr.w < 0) _qErr.set(-_qErr.x, -_qErr.y, -_qErr.z, -_qErr.w);
  const s = Math.hypot(_qErr.x, _qErr.y, _qErr.z);
  if (s < 1e-6) {
    _rotErr.set(0, 0, 0);
    return 0;
  }
  const angle = 2 * Math.atan2(s, _qErr.w);
  _rotErr.set(_qErr.x, _qErr.y, _qErr.z).multiplyScalar(angle / s);
  return angle;
}

/** State the rig shares with every card and the HUD; mutated per frame, never React state. */
interface Rig {
  camX: number;
  camZ: number;
  intro: number;
  /** a card is currently in hand: the stage must not start a navigation drag */
  held: boolean;
  reduced: boolean;
}

interface Hud {
  stage: MutableRefObject<HTMLDivElement | null>;
  rail: MutableRefObject<HTMLDivElement | null>;
  count: MutableRefObject<HTMLSpanElement | null>;
}

/* ------------------------------------------------------------------ *
 * Card
 * ------------------------------------------------------------------ */

function Card({
  card,
  index,
  layout,
  drift,
  rig,
  zeroG,
  onSelect,
}: {
  card: SlabCard;
  index: number;
  layout: HallLayout;
  drift: HallDrift;
  rig: MutableRefObject<Rig>;
  zeroG: boolean;
  onSelect: () => void;
}) {
  const rigidRef = useRef<RapierRigidBody>(null);
  const colliderRef = useRef<ComponentRef<typeof CuboidCollider>>(null);
  const bodyGroup = useRef<THREE.Group>(null);
  const veilMesh = useRef<THREE.Mesh>(null);
  const veilMat = useRef<THREE.MeshBasicMaterial>(null);
  const gl = useThree((s) => s.gl);
  const camera = useThree((s) => s.camera);
  const setCursor = useVaultStore((s) => s.setCursor);

  const [dragging, setDragging] = useState(false);
  const [hovered, setHovered] = useState(false);
  const grabbed = hovered || dragging;

  // the site cursor turns into the TOSS ring over a slab, like the grid cards
  useEffect(() => {
    if (!grabbed) return;
    setCursor(true, 'TOSS');
    return () => setCursor(false);
  }, [grabbed, setCursor]);

  const mount = useMemo<[number, number, number]>(
    () => [layout.pos[index * 3], layout.pos[index * 3 + 1], layout.pos[index * 3 + 2]],
    // spawn pose only: later layout changes are followed by the tether
    // eslint-disable-next-line react-hooks/exhaustive-deps
    []
  );

  const live = useRef({
    scale: 1,
    appliedScale: NaN,
    hover: 0,
    /** 0 = gravity, 1 = zero-g; eased so the switch never snaps */
    zg: zeroG ? 1 : 0,
    culled: false,
    veil: -1,
    hovered: false,
    dragging: false,
  });
  live.current.hovered = hovered;
  live.current.dragging = dragging;

  const drag = useRef({
    active: false,
    dragging: false,
    pointerId: -1,
    moved: 0,
    planeZ: 0,
    plane: new THREE.Plane(new THREE.Vector3(0, 0, 1), 0),
    offset: new THREE.Vector3(),
    target: new THREE.Vector3(),
    prev: new THREE.Vector3(),
    velocity: new THREE.Vector3(),
    lastClient: new THREE.Vector2(),
    lastTime: 0,
    camZ: NaN,
    /** touch: finger is down on the slab but has not been held long enough to grab it */
    pending: false,
    pendingMoved: 0,
    pendingTimer: 0,
    pendingPoint: new THREE.Vector2(),
    /** this grab came from a resting finger: letting go without a drag is not a tap */
    byHold: false,
  });

  /** Pointer -> world, on the plane the card was lifted from. Re-run when the camera moves under a held card. */
  const aimTarget = useCallback(() => {
    const d = drag.current;
    const rect = gl.domElement.getBoundingClientRect();
    _ndc.set(
      ((d.lastClient.x - rect.left) / rect.width) * 2 - 1,
      -((d.lastClient.y - rect.top) / rect.height) * 2 + 1
    );
    _raycaster.setFromCamera(_ndc, camera);
    if (!_raycaster.ray.intersectPlane(d.plane, _planeHit)) return false;
    const limitX = Math.max(layout.halfW - BODY.w * 0.35, 0.35);
    const limitY = Math.max(layout.halfH - BODY.h * 0.35, 0.6);
    d.target.set(
      _clamp(_planeHit.x + d.offset.x, -limitX, limitX),
      _clamp(_planeHit.y + d.offset.y, -limitY, limitY),
      d.planeZ
    );
    d.camZ = camera.position.z;
    return true;
  }, [camera, gl, layout.halfH, layout.halfW]);

  /** Pick the slab up: lock the drag plane at its depth and start springing it to the pointer. */
  const beginGrab = (pointerId: number, pointX: number, pointY: number, clientX: number, clientY: number, byHold: boolean) => {
    const body = rigidRef.current;
    if (!body || live.current.culled) return;
    const d = drag.current;
    const t = body.translation();
    d.active = true;
    d.dragging = false;
    d.byHold = byHold;
    d.pointerId = pointerId;
    d.moved = 0;
    d.planeZ = t.z;
    d.plane.constant = -d.planeZ;
    d.offset.set(t.x - pointX, t.y - pointY, 0);
    d.target.set(t.x, t.y, t.z);
    d.prev.copy(d.target);
    d.velocity.set(0, 0, 0);
    d.lastClient.set(clientX, clientY);
    d.lastTime = performance.now();
    d.camZ = camera.position.z;
    rig.current.held = true;

    body.enableCcd(true); // the spring can move a slab fast enough to tunnel
    body.wakeUp();
    try {
      gl.domElement.setPointerCapture(pointerId);
    } catch {
      /* best effort */
    }
    setDragging(true);
  };

  const cancelPending = () => {
    const d = drag.current;
    window.clearTimeout(d.pendingTimer);
    d.pending = false;
  };

  const onPointerDown = (event: ThreeEvent<PointerEvent>) => {
    if (!rigidRef.current || live.current.culled) return;
    event.stopPropagation();
    const d = drag.current;
    if (event.pointerType === 'touch') {
      // the screen is full of slabs: a swipe must still be able to move the camera.
      // Wait for the finger to rest; if it moves first the stage takes it as a scroll.
      if (d.pending || d.active) return;
      d.pending = true;
      d.pendingMoved = 0;
      d.pointerId = event.pointerId;
      d.lastClient.set(event.clientX, event.clientY);
      d.pendingPoint.set(event.point.x, event.point.y);
      const { pointerId, clientX, clientY } = event;
      d.pendingTimer = window.setTimeout(() => {
        if (!d.pending) return;
        d.pending = false;
        beginGrab(pointerId, d.pendingPoint.x, d.pendingPoint.y, clientX, clientY, true);
      }, DRAG.touchHold);
      return;
    }
    beginGrab(event.pointerId, event.point.x, event.point.y, event.clientX, event.clientY, false);
  };

  useEffect(() => {
    const onMove = (event: PointerEvent) => {
      const d = drag.current;
      if (d.pending && event.pointerId === d.pointerId) {
        d.pendingMoved += Math.hypot(event.clientX - d.lastClient.x, event.clientY - d.lastClient.y);
        d.lastClient.set(event.clientX, event.clientY);
        if (d.pendingMoved > DRAG.touchSlop) cancelPending(); // a swipe: the stage scrolls the vault
        return;
      }
      if (!d.active || event.pointerId !== d.pointerId) return;
      d.moved += Math.hypot(event.clientX - d.lastClient.x, event.clientY - d.lastClient.y);
      d.lastClient.set(event.clientX, event.clientY);
      const threshold = event.pointerType === 'touch' ? DRAG.touchThreshold : DRAG.mouseThreshold;
      if (!d.dragging && d.moved > threshold) d.dragging = true;
      if (!aimTarget()) return;

      const now = performance.now();
      const dt = Math.max((now - d.lastTime) / 1000, 1 / 240);
      _sample.subVectors(d.target, d.prev).divideScalar(dt);
      d.velocity.lerp(_sample, 0.35);
      d.prev.copy(d.target);
      d.lastTime = now;
    };

    const release = (event: PointerEvent | null, cancelled = false) => {
      const d = drag.current;
      if (d.pending && (!event || event.pointerId === d.pointerId)) {
        // finger lifted before the hold: a tap (select) if it barely moved
        const tap = !cancelled && d.pendingMoved <= DRAG.touchSlop;
        cancelPending();
        if (tap) onSelect();
        return;
      }
      if (!d.active || (event && event.pointerId !== d.pointerId)) return;
      d.active = false;
      rig.current.held = false;
      const body = rigidRef.current;
      if (body) {
        body.enableCcd(false);
        if (d.dragging && !cancelled) {
          const mass = body.mass() || MASS;
          const current = body.linvel();
          _sample.set(current.x, current.y, 0).lerp(d.velocity, 0.8).clampLength(0, DRAG.maxToss);
          body.applyImpulse({ x: (_sample.x - current.x) * mass, y: (_sample.y - current.y) * mass, z: 0 }, true);
        }
      }
      setDragging(false);
      if (!cancelled && !d.dragging && !d.byHold) onSelect();
    };

    const onUp = (e: PointerEvent) => release(e);
    const onCancel = (e: PointerEvent) => release(e, true);
    const onBlur = () => release(null, true);
    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);
    window.addEventListener('pointercancel', onCancel);
    window.addEventListener('blur', onBlur);
    return () => {
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerup', onUp);
      window.removeEventListener('pointercancel', onCancel);
      window.removeEventListener('blur', onBlur);
      window.clearTimeout(drag.current.pendingTimer);
      drag.current.pending = false;
      if (drag.current.active) rig.current.held = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [aimTarget, onSelect, rig]);

  useFrame((state, rawDelta) => {
    const delta = Math.min(rawDelta, 1 / 30);
    const time = state.clock.elapsedTime;
    const body = rigidRef.current;
    const d = drag.current;
    const v = live.current;
    const r = rig.current;
    if (!body) return;

    /* ---- depth: fade into the void, and cull what can't be seen ---- */
    const hx = layout.pos[index * 3];
    const hy = layout.pos[index * 3 + 1];
    const hz = layout.pos[index * 3 + 2];
    const dz = r.camZ - hz;
    const vis = cardVisibility(dz, v.culled, layout.fade);
    if (vis.cull !== v.culled && !d.active) {
      v.culled = vis.cull;
      body.setEnabled(!vis.cull);
      if (bodyGroup.current) bodyGroup.current.visible = !vis.cull;
      if (vis.cull) setHovered(false);
    }
    if (v.culled) return;

    const reveal = r.reduced ? 1 : introReveal(r.intro, dz);
    const veil = Math.max(vis.veil, 1 - reveal);
    if (Math.abs(veil - v.veil) > 0.004 && veilMesh.current && veilMat.current) {
      v.veil = veil;
      veilMat.current.opacity = veil;
      veilMesh.current.visible = veil > 0.004;
    }

    const mass = body.mass() || MASS;
    const p = body.translation();

    /* ---- held: spring toward the pointer (the camera may have moved) ---- */
    if (d.active) {
      if (d.camZ !== camera.position.z) aimTarget();
      const vel = body.linvel();
      body.applyImpulse(
        {
          x: ((d.target.x - p.x) * DRAG.stiffness - vel.x * DRAG.damping) * mass * delta,
          y: ((d.target.y - p.y) * DRAG.stiffness - vel.y * DRAG.damping) * mass * delta,
          z: ((d.target.z - p.z) * DRAG.stiffness - vel.z * DRAG.damping) * mass * delta,
        },
        true
      );
    }

    /* ---- mode blend: 0 = gravity, 1 = zero-g. Gravity itself stays on for every free
           body; zero-g is an equal and opposite force scaled by `zg`, so the switch eases
           over about a second and the slab never snaps or jumps. ---- */
    v.zg = THREE.MathUtils.damp(v.zg, zeroG ? 1 : 0, MODE_BLEND, delta);
    const zg = v.zg;

    /* ---- hover blend: 0 on its mount, 1 turned to the lens and stepped forward ---- */
    v.hover = THREE.MathUtils.damp(v.hover, v.hovered && !r.reduced ? 1 : 0, 6, delta);

    /* ---- tether: a damped spring to the mount. Gravity hangs it tight and sags are
           pre-compensated; zero-g loosens it and lets the card float. Both modes aim
           at the same mount, so they sit in the same place. ---- */
    if (!d.active) {
      const k = TETHER.gravity.k + (TETHER.zeroG.k - TETHER.gravity.k) * zg;
      const c = TETHER.gravity.c + (TETHER.zeroG.c - TETHER.gravity.c) * zg;
      const vel = body.linvel();
      const tx = hx;
      const ty = hy + ((1 - zg) * -GRAVITY_Y) / k;
      // a hovered slab steps toward the lens, out in front of whatever overlaps it
      const tz = hz + HOVER.lift * v.hover;
      const j = index * 6;
      let ax = (tx - p.x) * k - vel.x * c;
      let ay = (ty - p.y) * k - vel.y * c + -GRAVITY_Y * zg;
      let az = (tz - p.z) * k - vel.z * c;
      if (!r.reduced) {
        // slow zero-mean turbulence; calmer when hung, looser and wider in zero-g
        const f = drift.freq, ph = drift.phase, a = drift.accel;
        const g = 0.3 + 0.7 * zg;
        const gxy = g * (1 + (FLOAT.xy - 1) * zg);
        const gz = g * (1 + (FLOAT.z - 1) * zg);
        ax += a[j] * Math.sin(f[j] * time + ph[j]) * gxy;
        ay += a[j + 1] * Math.sin(f[j + 1] * time + ph[j + 1]) * gxy;
        az += a[j + 2] * Math.sin(f[j + 2] * time + ph[j + 2]) * gz;
      }
      body.applyImpulse({ x: ax * mass * delta, y: ay * mass * delta, z: az * mass * delta }, true);
    }

    /* ---- orientation: the field's lean, easing toward the lens on hover or in hand ---- */
    const faceYaw = Math.atan2(r.camX - p.x, r.camZ - p.z);
    const k = d.active ? 1 : v.hover * HOVER.turn;
    const yaw = layout.yaw[index] + (faceYaw - layout.yaw[index]) * k;
    let pitch = layout.pitch[index];
    let roll = layout.roll[index];
    if (!r.reduced) {
      const j = index * 6;
      const g = (0.3 + 0.7 * zg) * (1 + (FLOAT.tilt - 1) * zg);
      pitch += Math.sin(drift.freq[j + 3] * time + drift.phase[j + 3]) * 0.05 * g;
      roll += Math.sin(drift.freq[j + 5] * time + drift.phase[j + 5]) * 0.04 * g;
    }
    _euler.set(pitch, yaw, roll, 'YXZ');
    _qTgt.setFromEuler(_euler);
    const angle = turnToTarget(body.rotation());
    const turn = angle > 1e-6 ? Math.min(angle * TURN.rate, TURN.max) / angle : 0;
    const w = body.angvel();
    const blend = 1 - Math.exp(-TURN.follow * delta);
    _v.x = w.x + (_rotErr.x * turn - w.x) * blend;
    _v.y = w.y + (_rotErr.y * turn - w.y) * blend;
    _v.z = w.z + (_rotErr.z * turn - w.z) * blend;
    body.setAngvel(_v, true);

    /* ---- hover lift: the collider follows the scale so hit and contact stay honest ---- */
    v.scale = THREE.MathUtils.damp(v.scale, grabbed ? HOVER.scale : 1, 8, delta);
    const collider = colliderRef.current;
    if (collider && Math.abs(v.scale - v.appliedScale) > DRAG.scaleEpsilon) {
      v.appliedScale = v.scale;
      collider.setHalfExtents({
        x: (BODY.w / 2) * v.scale,
        y: (BODY.h / 2) * v.scale,
        z: (BODY.d / 2) * v.scale,
      });
    }
  });

  // the nearest slab under the ray wins; culled slabs never take events
  const over = (e: ThreeEvent<PointerEvent>) => {
    if (live.current.culled) return;
    e.stopPropagation();
    setHovered(true);
  };
  const out = () => setHovered(false);

  return (
    <RigidBody
      ref={rigidRef}
      position={mount}
      colliders={false}
      linearDamping={dragging ? 4.5 : LINEAR_DAMPING}
      angularDamping={ANGULAR_DAMPING}
      mass={MASS}
      restitution={0.42}
      friction={0.62}
      gravityScale={dragging ? 0 : 1}
      canSleep={false}
      ccd={false}
    >
      <CuboidCollider ref={colliderRef} args={[BODY.w / 2, BODY.h / 2, BODY.d / 2]} />
      <group ref={bodyGroup} onPointerOver={over} onPointerOut={out}>
        <Slab
          card={card}
          quality="cheap"
          intensity={0.95}
          active={grabbed}
          upgradeGlass={grabbed}
          timeOffset={index * 1.7}
          cardHandlers={{ onPointerDown }}
        >
          {/* depth veil: the slab's silhouette in the page's void colour. Opacity is
              the distance fade; materials are shared across slabs, so it is per card. */}
          <mesh
            ref={veilMesh}
            geometry={getVeilGeometry()}
            dispose={null}
            position={[0, 0, SLAB_SPEC.zFront + 0.006]}
            raycast={nullRaycast}
          >
            <meshBasicMaterial ref={veilMat} color={VOID} transparent opacity={1} depthWrite={false} toneMapped={false} />
          </mesh>
        </Slab>
        {/* collider-sized hover target: the shell is thin, this is not */}
        <mesh visible={false} onPointerDown={onPointerDown} onPointerOver={over} onPointerOut={out}>
          <boxGeometry args={[BODY.w * 1.04, BODY.h * 1.02, BODY.d * 1.6]} />
        </mesh>
      </group>
    </RigidBody>
  );
}

/* ------------------------------------------------------------------ *
 * Hall: shell colliders + architecture
 * ------------------------------------------------------------------ */

function HallShell({ layout }: { layout: HallLayout }) {
  const { halfW: w, halfH: h, zEnd } = layout;
  const zNear = 5;
  const zFar = zEnd - 8;
  const cz = (zNear + zFar) / 2;
  const hl = (zNear - zFar) / 2;
  return (
    <>
      <RigidBody type="fixed" position={[0, -(h + WALL), cz]}>
        <CuboidCollider args={[w + WALL * 2, WALL, hl]} />
      </RigidBody>
      <RigidBody type="fixed" position={[0, h + WALL, cz]}>
        <CuboidCollider args={[w + WALL * 2, WALL, hl]} />
      </RigidBody>
      <RigidBody type="fixed" position={[-(w + WALL), 0, cz]}>
        <CuboidCollider args={[WALL, h + WALL * 2, hl]} />
      </RigidBody>
      <RigidBody type="fixed" position={[w + WALL, 0, cz]}>
        <CuboidCollider args={[WALL, h + WALL * 2, hl]} />
      </RigidBody>
      <RigidBody type="fixed" position={[0, 0, zFar - WALL]}>
        <CuboidCollider args={[w + WALL, h + WALL, WALL]} />
      </RigidBody>
      <RigidBody type="fixed" position={[0, 0, zNear + WALL]}>
        <CuboidCollider args={[w + WALL, h + WALL, WALL]} />
      </RigidBody>
    </>
  );
}

const LINE_VERT = /* glsl */ `
  attribute vec3 aColor;
  attribute float aAlpha;
  varying vec3 vColor;
  varying float vAlpha;
  varying float vDepth;
  void main() {
    vec4 mv = modelViewMatrix * vec4(position, 1.0);
    vDepth = -mv.z;
    vColor = aColor;
    vAlpha = aAlpha;
    gl_Position = projectionMatrix * mv;
  }
`;
/* the architecture dissolves with the slabs, a little further out (range follows the stage, see layout.fade) */
const LINE_FRAG = /* glsl */ `
  uniform float uFrom;
  uniform float uTo;
  varying vec3 vColor;
  varying float vAlpha;
  varying float vDepth;
  void main() {
    float f = (1.0 - smoothstep(uFrom, uTo, vDepth)) * smoothstep(0.4, 2.5, vDepth);
    gl_FragColor = vec4(vColor, vAlpha * f);
  }
`;

/** Bulkhead ribs, corner rails and the orange aperture: one draw call, faded in the shader. */
function HallLines({ layout }: { layout: HallLayout }) {
  const geometry = useMemo(() => {
    const { position, color, alpha } = buildHallLines(layout);
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(position, 3));
    g.setAttribute('aColor', new THREE.BufferAttribute(color, 3));
    g.setAttribute('aAlpha', new THREE.BufferAttribute(alpha, 1));
    return g;
  }, [layout]);
  useEffect(() => () => geometry.dispose(), [geometry]);
  const uniforms = useMemo(
    () => ({ uFrom: { value: layout.fade.from + 1.5 }, uTo: { value: layout.fade.cullFar * 1.9 } }),
    [layout.fade.from, layout.fade.cullFar]
  );
  return (
    <lineSegments geometry={geometry} frustumCulled={false} raycast={nullRaycast}>
      <shaderMaterial vertexShader={LINE_VERT} fragmentShader={LINE_FRAG} uniforms={uniforms} transparent depthWrite={false} />
    </lineSegments>
  );
}

/** A small studio for the hall: cheap glass still needs something to reflect. */
function PitEnvironment() {
  return (
    <Environment resolution={128} frames={1} environmentIntensity={0.75}>
      <Lightformer form="rect" intensity={2.4} color="#ffffff" position={[0, 4, -5]} scale={[10, 2, 1]} />
      <Lightformer form="rect" intensity={1.4} color="#dce8ff" position={[-5, 0, 2]} scale={[8, 2, 1]} />
      <Lightformer form="rect" intensity={1.2} color="#ffe6d6" position={[5, 0, 2]} scale={[8, 2, 1]} />
      <Lightformer form="ring" intensity={2.6} color="#FF4D00" position={[-3, 2, 1]} scale={2.4} target={[0, 0, 0]} />
    </Environment>
  );
}

/* ------------------------------------------------------------------ *
 * Rig: scroll -> camera, HUD, and re-picking under a still pointer
 * ------------------------------------------------------------------ */

function HallRig({
  scroll,
  rig,
  layout,
  hud,
}: {
  scroll: HallScroll;
  rig: MutableRefObject<Rig>;
  layout: HallLayout;
  hud: Hud;
}) {
  const hudState = useRef({ index: -1, mode: '', p: -1, entered: false, frame: 0 });

  useFrame((state, rawDelta) => {
    const delta = Math.min(rawDelta, 1 / 30);
    const r = rig.current;
    const now = performance.now();
    scroll.update(delta, now);

    r.intro = Math.min(1, r.intro + delta / INTRO_SECONDS);
    r.camZ = -scroll.pos;
    // a breath of parallax from the pointer; the lens never turns, so the corridor stays square
    const px = r.reduced ? 0 : state.pointer.x * 0.16;
    r.camX = THREE.MathUtils.damp(r.camX, px, 3, delta);
    const cam = state.camera;
    cam.position.set(r.camX, r.reduced ? 0 : state.pointer.y * 0.08, r.camZ);

    // keep hover honest while the world slides under a still pointer
    const hs = hudState.current;
    if (Math.abs(scroll.vel) > 0.05 && (hs.frame++ & 1) === 0) {
      (state.events as { update?: () => void }).update?.();
    }

    // HUD: imperative, no React per frame
    const p = Math.round(scroll.progress * 1000) / 1000;
    if (p !== hs.p && hud.rail.current) {
      hs.p = p;
      hud.rail.current.style.setProperty('--p', String(p));
    }
    const idx = slabAt(Math.max(scroll.pos, 0), layout.count, layout.step);
    if (idx !== hs.index && hud.count.current) {
      hs.index = idx;
      const pad = (n: number) => String(n).padStart(2, '0');
      hud.count.current.textContent = `${pad(idx)} / ${pad(layout.count)}`;
    }
    if (scroll.pos > 1) hs.entered = true;
    const mode =
      layout.length > 2 && scroll.pos > layout.length - 0.35 ? 'end' : !hs.entered && scroll.pos < 0.6 ? 'enter' : 'off';
    if (mode !== hs.mode && hud.stage.current) {
      hs.mode = mode;
      hud.stage.current.dataset.hall = mode;
    }
  }, -10);

  return null;
}

/** Keeps a failed optional pass (the focal blur) from taking the whole vault down with it. */
class OptionalPass extends Component<{ children: ReactNode }, { failed: boolean }> {
  state = { failed: false };
  static getDerivedStateFromError() {
    return { failed: true };
  }
  componentDidCatch(error: unknown) {
    console.warn('[Vault] focal blur disabled:', error);
  }
  render() {
    return this.state.failed ? null : this.props.children;
  }
}

function Scene({
  cards,
  zeroG,
  scroll,
  rig,
  hud,
  blur,
}: {
  cards: SlabCard[];
  zeroG: boolean;
  scroll: HallScroll;
  rig: MutableRefObject<Rig>;
  hud: Hud;
  /** depth-of-field on (desktop, motion allowed) */
  blur: boolean;
}) {
  const size = useThree((s) => s.size);
  const camera = useThree((s) => s.camera);
  const aspect = size.width / Math.max(size.height, 1);

  // portrait stages get a wider lens so the field still reads (same curve the layout is sized from)
  useEffect(() => {
    const cam = camera as THREE.PerspectiveCamera;
    cam.fov = fovFor(aspect);
    cam.updateProjectionMatrix();
  }, [aspect, camera]);

  // bucket the aspect so a window drag doesn't rebuild the hall every pixel
  const aspectKey = Math.round(aspect * 10) / 10;
  const layout = useMemo(() => planHall(cards.length, aspectKey), [cards.length, aspectKey]);
  const drift = useMemo(() => planDrift(cards.length, LINEAR_DAMPING, ANGULAR_DAMPING), [cards.length]);

  const started = useRef(false);
  useEffect(() => {
    scroll.setRange(layout.length);
    if (!started.current) {
      started.current = true;
      // arrive: the lens starts just outside the entrance and glides in
      scroll.reset(rig.current.reduced ? 0 : -1.3);
    }
  }, [layout.length, scroll, rig]);

  const onSelect = useCallback(() => document.getElementById('forge')?.scrollIntoView({ behavior: 'smooth' }), []);

  return (
    <>
      <ambientLight intensity={0.7} />
      <directionalLight position={[5, 6, 6]} intensity={0.9} />
      <directionalLight position={[-5, -2, 3]} intensity={0.35} color="#FF4D00" />
      <PitEnvironment />
      <HallRig scroll={scroll} rig={rig} layout={layout} hud={hud} />
      <HallLines layout={layout} />
      {/* world gravity stays constant; zero-g is an opposing force each card blends in (see Card) */}
      <Physics gravity={[0, GRAVITY_Y, 0]}>
        <HallShell key={`${layout.halfW}|${layout.zEnd}`} layout={layout} />
        {cards.map((card, i) => (
          <Card
            key={card.id}
            card={card}
            index={i}
            layout={layout}
            drift={drift}
            rig={rig}
            zeroG={zeroG}
            onSelect={onSelect}
          />
        ))}
      </Physics>
      {blur && (
        <OptionalPass>
          <Suspense fallback={null}>
            <FocalBlur focus={BLUR.focus} range={BLUR.range} bokeh={BLUR.bokeh} />
          </Suspense>
        </OptionalPass>
      )}
    </>
  );
}

/* ------------------------------------------------------------------ *
 * Stage: owns the input, the HUD and the canvas
 * ------------------------------------------------------------------ */

export default function GalleryPitPhysics({
  cards = slabCards,
  zeroG = false,
}: {
  cards?: SlabCard[];
  /** true: no gravity, slabs float loose on their tethers. false: normal gravity. */
  zeroG?: boolean;
}) {
  const [mounted, setMounted] = useState(false);
  /** touch / small screens: cap the pixel ratio and skip the blur pass to stay smooth on phones */
  const [lite, setLite] = useState(false);
  const [calm, setCalm] = useState(false);
  const stageRef = useRef<HTMLDivElement | null>(null);
  const railRef = useRef<HTMLDivElement | null>(null);
  const countRef = useRef<HTMLSpanElement | null>(null);
  const hud = useMemo<Hud>(() => ({ stage: stageRef, rail: railRef, count: countRef }), []);
  const scroll = useMemo(() => new HallScroll(), []);
  const rig = useRef<Rig>({ camX: 0, camZ: 0, intro: 0, held: false, reduced: false });

  useEffect(() => {
    const coarse = window.matchMedia('(pointer: coarse)');
    const narrow = window.matchMedia('(max-width: 767px)');
    const motion = window.matchMedia('(prefers-reduced-motion: reduce)');
    const apply = () => {
      setLite(coarse.matches || narrow.matches);
      setCalm(motion.matches);
    };
    apply();
    const qs = [coarse, narrow, motion];
    qs.forEach((q) => q.addEventListener('change', apply));
    return () => qs.forEach((q) => q.removeEventListener('change', apply));
  }, []);

  useEffect(() => {
    let refresh = 0;
    const swap = requestAnimationFrame(() => {
      setMounted(true);
      refresh = requestAnimationFrame(() => ScrollTrigger.refresh());
    });
    return () => {
      cancelAnimationFrame(swap);
      cancelAnimationFrame(refresh);
    };
  }, []);

  // input: wheel / touch-drag / keys -> HallScroll. Mounted with the stage.
  useEffect(() => {
    const stage = stageRef.current;
    if (!stage) return;
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    const applyMotion = () => {
      rig.current.reduced = mq.matches;
      scroll.reduced = mq.matches;
    };
    applyMotion();
    mq.addEventListener('change', applyMotion);

    const onWheel = (e: WheelEvent) => {
      if (e.ctrlKey || Math.abs(e.deltaX) > Math.abs(e.deltaY)) return; // pinch-zoom / horizontal: not ours
      const unit = e.deltaMode === 1 ? 16 : e.deltaMode === 2 ? window.innerHeight : 1;
      if (scroll.wheel(e.deltaY * unit, performance.now())) {
        e.preventDefault();
        e.stopPropagation(); // keep Lenis from also moving the page
      }
    };
    stage.addEventListener('wheel', onWheel, { passive: false });

    const nav = { id: -1, y: 0, t: 0 };
    const onDown = (e: PointerEvent) => {
      if (rig.current.held || nav.id !== -1) return; // a slab is in hand
      if ((e.target as Element).closest('[data-hall-ui]')) return;
      if (e.pointerType === 'mouse' && e.button !== 0) return;
      nav.id = e.pointerId;
      nav.y = e.clientY;
      nav.t = performance.now();
      scroll.dragStart(nav.t);
      stage.dataset.drag = 'true';
    };
    const onMove = (e: PointerEvent) => {
      if (e.pointerId !== nav.id) return;
      const now = performance.now();
      if (rig.current.held) {
        // a resting finger turned into a grab (touch): the slab owns this pointer now
        nav.id = -1;
        delete stage.dataset.drag;
        scroll.dragEnd(now);
        return;
      }
      const leftover = scroll.dragMove(e.clientY - nav.y, now, (now - nav.t) / 1000);
      if (leftover !== 0) window.scrollBy(0, leftover); // hall is at its end: the page takes over
      nav.y = e.clientY;
      nav.t = now;
    };
    const onUp = (e: PointerEvent) => {
      if (e.pointerId !== nav.id) return;
      nav.id = -1;
      delete stage.dataset.drag;
      scroll.dragEnd(performance.now());
    };
    stage.addEventListener('pointerdown', onDown);
    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);
    window.addEventListener('pointercancel', onUp);

    const onKey = (e: KeyboardEvent) => {
      if (e.altKey || e.ctrlKey || e.metaKey) return;
      const now = performance.now();
      const big = 3 * HALL.nudge;
      switch (e.key) {
        case 'ArrowDown': scroll.nudge(HALL.nudge, now); break;
        case 'ArrowUp': scroll.nudge(-HALL.nudge, now); break;
        case 'PageDown': scroll.nudge(big, now); break;
        case 'PageUp': scroll.nudge(-big, now); break;
        case ' ': scroll.nudge(e.shiftKey ? -big : big, now); break;
        case 'Home': scroll.jumpTo(0, now); break;
        case 'End': scroll.jumpTo(scroll.max, now); break;
        default: return;
      }
      e.preventDefault();
    };
    stage.addEventListener('keydown', onKey);

    const onPageScroll = () => scroll.notePageScroll(performance.now());
    window.addEventListener('scroll', onPageScroll, { passive: true });

    return () => {
      mq.removeEventListener('change', applyMotion);
      stage.removeEventListener('wheel', onWheel);
      stage.removeEventListener('pointerdown', onDown);
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerup', onUp);
      window.removeEventListener('pointercancel', onUp);
      stage.removeEventListener('keydown', onKey);
      window.removeEventListener('scroll', onPageScroll);
    };
  }, [mounted, scroll]);

  // the rail is a scrubber: press or drag to glide to a depth
  const scrub = (e: React.PointerEvent<HTMLDivElement>) => {
    const track = e.currentTarget.getBoundingClientRect();
    const f = _clamp((e.clientY - track.top) / track.height, 0, 1);
    scroll.jumpTo(f * scroll.max, performance.now());
  };

  if (!mounted) {
    return (
      <div className="w-full h-[70vh] bg-[#050505] border border-[#1A1A1A] grid place-items-center">
        <div className="font-mono text-[10px] tracking-widest text-[#F5F3EF]/30">INITIALIZING RAPIER • BUILDING THE VAULT...</div>
      </div>
    );
  }

  return (
    <div
      ref={stageRef}
      data-hall="enter"
      tabIndex={0}
      role="group"
      aria-label="The vault: a field of slabs. Scroll, swipe or use the arrow keys to fly through it."
      className="vault-stage w-full h-[72svh] min-h-[420px] md:h-[75vh] relative border border-[#1A1A1A] bg-[#050505] overflow-hidden cursor-none select-none"
    >
      <WebGLGuard
        fallback={
          <div className="absolute inset-0 grid place-items-center p-8 text-center">
            <div className="font-mono text-[10px] tracking-widest text-[#F5F3EF]/50 leading-relaxed">
              THE VAULT NEEDS WEBGL<br />
              <span className="text-[#F5F3EF]/30">Turn on hardware acceleration in your browser, or switch to GRID view.</span>
            </div>
          </div>
        }
      >
        <Canvas
          camera={{ position: [0, 0, 0], fov: BASE_FOV, near: 0.1, far: 60 }}
          dpr={[1, lite ? 1.5 : 2]}
          gl={{ antialias: true, alpha: true }}
        >
          <Scene cards={cards} zeroG={zeroG} scroll={scroll} rig={rig} hud={hud} blur={FOCAL_BLUR && !lite && !calm} />
        </Canvas>
      </WebGLGuard>

      {/* atmosphere: the hall closes in toward the edges and the far end falls into the void */}
      <div className="vault-haze absolute inset-0 pointer-events-none" aria-hidden="true" />

      <div className="absolute top-0 left-0 right-0 p-2 sm:p-3 flex justify-between gap-2 pointer-events-none">
        <div className="min-w-0 truncate font-mono text-[9px] sm:text-[10px] tracking-widest text-[#F5F3EF]/60 bg-black/70 px-2 sm:px-3 py-1.5 border border-white/10 backdrop-blur">
          THE VAULT • {cards.length} SLABS<span className="hidden md:inline"> • MASS {MASS}</span> • {zeroG ? 'ZERO-G' : `GRAVITY ${GRAVITY_Y}`}
        </div>
        <div className="hidden sm:block shrink-0 font-mono text-[10px] text-[#FF4D00] bg-black/70 px-3 py-1.5 border border-[#FF4D00]/30 backdrop-blur">
          ● SCROLL • DRAG • TOSS • CLICK → FORGE
        </div>
      </div>

      {/* depth rail: where you are in the hall. Press or drag to glide. */}
      <div
        data-hall-ui
        className="vault-rail-hit absolute right-2 top-1/2 -translate-y-1/2 w-8 py-3 flex justify-center cursor-none touch-none"
        onPointerDown={(e) => {
          e.currentTarget.setPointerCapture(e.pointerId);
          scrub(e);
        }}
        onPointerMove={(e) => {
          if (e.currentTarget.hasPointerCapture(e.pointerId)) scrub(e);
        }}
        aria-hidden="true"
      >
        <div ref={railRef} className="vault-rail relative">
          <span className="vault-rail-fill" />
          <span className="vault-rail-thumb" />
        </div>
      </div>

      <div className="absolute bottom-0 left-0 right-0 p-2 sm:p-3 bg-gradient-to-t from-black/80 to-transparent pointer-events-none">
        <div className="relative flex justify-between items-end gap-3 font-mono text-[8px] sm:text-[9px] text-[#F5F3EF]/40">
          <span className="tabular shrink-0">
            SLAB <span ref={countRef} className="text-[#F5F3EF]/70">01 / {String(cards.length).padStart(2, '0')}</span>
          </span>
          <span className="vault-hint" data-for="enter">Scroll to enter the vault</span>
          <span className="vault-hint" data-for="end">End of the hall • keep scrolling to leave</span>
          <span className="text-right text-[#F5F3EF]/60">
            <span className="hidden sm:inline">Drag a slab to toss it • tap to forge one like it</span>
            <span className="sm:hidden">Swipe to fly • hold to grab • tap to forge</span>
          </span>
        </div>
      </div>
    </div>
  );
}
