// Hero-only foil material: the ORIGINAL holo shader, unchanged.
// The Forge preview and the gallery pit use the shared, reworked shader in
// HoloMaterial.tsx (registered as <holoShaderMaterial>). The hero slab keeps
// this one, registered under its own element name so the two never collide.
'use client';
import * as THREE from 'three';
import { shaderMaterial } from '@react-three/drei';
import { extend } from '@react-three/fiber';

const HeroHoloShaderMaterial = shaderMaterial(
  {
    uTime: 0,
    uPointer: new THREE.Vector2(0.5, 0.5),
    uImage: null,
    uFinish: 0, // 0 base, 1 holo, 2 cracked, 3 star, 4 sparkle
    uIntensity: 1,
  },
  // vertex
  `
    varying vec2 vUv;
    varying vec3 vNormal;
    varying vec3 vViewDir;
    void main() {
      vUv = uv;
      vec4 mvPos = modelViewMatrix * vec4(position, 1.0);
      vNormal = normalize(normalMatrix * normal);
      vViewDir = normalize(-mvPos.xyz);
      gl_Position = projectionMatrix * mvPos;
    }
  `,
  // fragment
  `
    uniform float uTime;
    uniform vec2 uPointer;
    uniform sampler2D uImage;
    uniform float uFinish;
    uniform float uIntensity;
    
    varying vec2 vUv;
    varying vec3 vNormal;
    varying vec3 vViewDir;

    // Simplex noise
    float random(vec2 st) {
      return fract(sin(dot(st.xy, vec2(12.9898,78.233))) * 43758.5453123);
    }

    float noise(vec2 st) {
      vec2 i = floor(st);
      vec2 f = fract(st);
      float a = random(i);
      float b = random(i + vec2(1.0, 0.0));
      float c = random(i + vec2(0.0, 1.0));
      float d = random(i + vec2(1.0, 1.0));
      vec2 u = f * f * (3.0 - 2.0 * f);
      return mix(a, b, u.x) + (c - a)* u.y * (1.0 - u.x) + (d - b) * u.x * u.y;
    }

    vec3 holoGradient(float t) {
      vec3 c1 = vec3(1.0, 0.3, 0.0); // orange
      vec3 c2 = vec3(0.0, 0.9, 1.0); // cyan
      vec3 c3 = vec3(1.0, 0.9, 0.0); // yellow
      vec3 c4 = vec3(1.0, 0.0, 0.9); // magenta
      float t2 = fract(t);
      if(t2 < 0.33) return mix(c1, c2, t2/0.33);
      else if(t2 < 0.66) return mix(c2, c3, (t2-0.33)/0.33);
      else return mix(c3, c4, (t2-0.66)/0.34);
    }

    void main() {
      vec2 uv = vUv;
      vec2 pointer = uPointer;
      
      // Base image
      vec4 img = texture2D(uImage, uv);
      
      // Fresnel
      float fresnel = pow(1.0 - max(dot(vNormal, vViewDir), 0.0), 3.0);
      
      // Pointer influence
      float dist = distance(uv, pointer);
      float pointerGlow = 1.0 - smoothstep(0.0, 0.6, dist);
      
      vec3 finalColor = img.rgb;
      
      if(uFinish > 0.5 && uFinish < 1.5) {
        // HOLO
        float angle = atan(uv.y - pointer.y, uv.x - pointer.x);
        float holo = sin(angle * 6.0 + uTime * 0.5 + dist * 10.0) * 0.5 + 0.5;
        vec3 holoCol = holoGradient(holo + uTime * 0.05 + pointer.x);
        float holoMask = fresnel * 0.8 + pointerGlow * 0.6 + 0.1;
        holoMask *= (0.5 + noise(uv * 8.0 + uTime * 0.1) * 0.5);
        finalColor = mix(finalColor, holoCol, holoMask * 0.7 * uIntensity);
        finalColor += holoCol * fresnel * 0.4 * uIntensity;
      } 
      else if(uFinish > 1.5 && uFinish < 2.5) {
        // CRACKED ICE
        vec2 crackedUv = uv * 12.0;
        float n = noise(crackedUv);
        float cracks = smoothstep(0.3, 0.31, fract(n * 10.0));
        vec3 ice = vec3(0.8, 0.9, 1.0);
        float iceMask = (1.0 - cracks) * 0.3 + fresnel * 0.5;
        finalColor = mix(finalColor, ice, iceMask * 0.4);
        // Add crack lines white
        finalColor += vec3(1.0) * (1.0 - cracks) * 0.15 * pointerGlow;
        finalColor += vec3(1.0) * fresnel * 0.3;
      }
      else if(uFinish > 2.5 && uFinish < 3.5) {
        // STAR
        vec3 star1 = vec3(1.0, 0.84, 0.0);
        vec3 star2 = vec3(0.85, 0.65, 0.13);
        vec3 starGrad = mix(star2, star1, sin(uv.y * 3.0 + uTime * 0.2) * 0.5 + 0.5);
        float starMask = fresnel * 0.9 + pointerGlow * 0.5;
        starMask += noise(uv * 20.0) * 0.1;
        finalColor = mix(finalColor, starGrad, starMask * 0.5 * uIntensity);
        finalColor += starGrad * fresnel * 0.6;
      }
      else if(uFinish > 3.5) {
        // SPARKLE: fine dot-matrix of twinkling foil specks (same idea as the
        // shared shader's dotSparkle() + glintPoints()), art left untouched
        vec2 g = uv * vec2(120.0, 170.0);
        vec2 id = floor(g);
        vec2 f = fract(g) - 0.5;
        vec2 jr = vec2(random(id + 1.7), random(id + 5.1)) - 0.5;
        float shape = 1.0 - smoothstep(0.20, 0.46, length(f - jr * 0.35));
        float h1 = random(id);
        float h2 = random(id + 7.31);
        float tw = 0.5 + 0.5 * sin(uTime * 1.0 + pointerGlow * 3.6 + h1 * 6.2831);
        float spark = shape * (0.03 + 0.97 * h2 * h2 * (0.25 + 0.75 * tw));
        vec3 pal = 0.55 + 0.45 * cos(6.2831 * (h2 + uTime * 0.05 + vec3(0.0, 0.33, 0.67)));
        vec3 tint = mix(vec3(1.0), pal * pal, step(0.74, h1) * 0.85);
        finalColor += tint * spark * (0.25 + 0.75 * pointerGlow + fresnel) * uIntensity;

        vec2 gg = uv * vec2(90.0, 130.0);
        vec2 gid = floor(gg);
        float gh = random(gid + 3.7);
        float gtw = 0.5 + 0.5 * sin(uTime * 2.6 + gh * 40.0);
        float spot = 1.0 - smoothstep(0.10, 0.40, length(fract(gg) - 0.5));
        vec3 gcol = mix(vec3(1.0, 0.55, 0.15), vec3(1.0), step(0.5, random(gid + 8.2)));
        finalColor += gcol * step(0.975, gh) * spot * (0.3 + 1.2 * gtw) * uIntensity;
      }
      
      // Vignette + micro scratches
      float vignette = 1.0 - smoothstep(0.5, 1.2, length(uv - 0.5) * 1.5);
      finalColor *= 0.85 + vignette * 0.15;
      
      // Subtle scanline
      float scan = sin(uv.y * 800.0) * 0.02 + 0.98;
      finalColor *= scan;
      
      gl_FragColor = vec4(finalColor, 1.0);
    }
  `
);

extend({ HeroHoloShaderMaterial });

declare module '@react-three/fiber' {
  interface ThreeElements {
    // untyped on purpose, like the original declaration: the uniforms are set as
    // props (uImage is a Texture, its default is null) and this keeps every
    // call site type-checking exactly as before
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    heroHoloShaderMaterial: any;
  }
}

export { HeroHoloShaderMaterial };
