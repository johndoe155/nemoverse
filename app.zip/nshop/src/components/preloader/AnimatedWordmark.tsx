'use client';

import { forwardRef, useImperativeHandle, useLayoutEffect, useRef } from 'react';
import {
  WORDMARK_END_MS,
  WORDMARK_MARKUP,
  WORDMARK_START_MS,
  WORDMARK_VIEWBOX,
} from './wordmarkMarkup';

/**
 * Colour override for the first stroke of the sequence (`nwm-s0`, the outline that draws around
 * the whole mark). The artwork authors it as #030202, which is effectively invisible on the
 * preloader's #080808 (contrast ~1.03:1). A faint warm off-white (the page's #F5F3EF at 40%)
 * renders as ~#666564 there: ~3.4:1, readable but still quiet next to the orange strokes.
 *
 * Kept here, not in wordmarkMarkup.ts, because that file is generated. A class selector beats
 * the stroke="" presentation attribute; opacity keyframes are untouched, so it fades out on
 * the original schedule and the finished wordmark is pixel-identical.
 */
const STROKE_OVERRIDE_CSS = '<style>.nwm-s0{stroke:#F5F3EF;stroke-opacity:.4}</style>';
const MARKUP = WORDMARK_MARKUP + STROKE_OVERRIDE_CSS;

export interface AnimatedWordmarkHandle {
  /**
   * Put the wordmark at `p` (0..1) of its timeline. Pure scrub: idempotent, can be called every
   * frame, never starts playback and can never loop - the animation only ever moves when told to.
   */
  seek(p: number): void;
}

interface Props {
  /** Layout classes only. Keep the size classes identical to the <img> this replaces. */
  className?: string;
}

/**
 * Inline animated wordmark (replaces <img src="/logo-wordmark.svg">).
 *
 * - Inline (not <img>) so the CSS animations are reachable by the Web Animations API; an <img>
 *   SVG is a sealed document that self-plays and loops and cannot be scrubbed.
 * - The markup is authored `paused` + single iteration, so the very first paint is the
 *   frame-0 state: no autoplay flash, no loop, and nothing to flash-of-unstyled.
 * - `aspect-ratio` 5:1 (= viewBox 200x40) reserves the exact box before anything is drawn, so
 *   swapping the asset in causes no layout shift.
 */
export const AnimatedWordmark = forwardRef<AnimatedWordmarkHandle, Props>(function AnimatedWordmark(
  { className = '' },
  ref,
) {
  const svgRef = useRef<SVGSVGElement>(null);
  const animsRef = useRef<Animation[]>([]);
  const lastRef = useRef(-1);

  // Before the first paint: take ownership of every animation inside this SVG and freeze it.
  useLayoutEffect(() => {
    const svg = svgRef.current;
    if (!svg) return;

    if (typeof svg.getAnimations !== 'function') {
      // Very old browser: no scrubbing possible -> show the finished wordmark, still no loop.
      svg.classList.add('nwm-static');
      return;
    }

    const anims = svg.getAnimations({ subtree: true });
    for (const a of anims) {
      a.pause();
      a.currentTime = 0;
    }
    animsRef.current = anims;
    lastRef.current = -1;
  }, []);

  useImperativeHandle(ref, () => ({
    seek(p: number) {
      const anims = animsRef.current;
      if (!anims.length) return; // reduced-motion / static fallback: CSS already shows the end state
      const clamped = p < 0 ? 0 : p > 1 ? 1 : p;
      // 0 -> first visible movement, 1 -> last visible movement (see wordmarkMarkup.ts).
      const t = WORDMARK_START_MS + clamped * (WORDMARK_END_MS - WORDMARK_START_MS);
      if (t === lastRef.current) return;
      lastRef.current = t;
      for (const a of anims) {
        // Scrubbing a paused animation: the playhead moves, the clock never does.
        a.currentTime = t;
      }
    },
  }), []);

  return (
    <svg
      ref={svgRef}
      xmlns="http://www.w3.org/2000/svg"
      viewBox={WORDMARK_VIEWBOX}
      role="img"
      aria-label="Nemo's Card Shop"
      // `block` + 5:1 box: same intrinsic geometry the static <img> had, reserved up front.
      className={`block shrink-0 w-auto aspect-[5/1] ${className}`}
      dangerouslySetInnerHTML={{ __html: MARKUP }}
    />
  );
});
