'use client';
import { useEffect, type ReactNode, type RefObject } from 'react';
import { useVaultStore } from '@/store/useVaultStore';
import { attachLetterDrag } from '@/lib/letterDrag';

/**
 * The footer's giant "NEMO'S / VAULT" watermark, split into individually draggable letters.
 *
 * Rendering: three identical copies of the two lines are stacked, letter for letter (see .wm-* in globals.css):
 *   fill  in flow, sizes the block. Dull cream; `.is-lit` fades a letter up to its bright state.
 *   ko    the knock-out layer. Every letter in white with `mix-blend-mode: difference`, so wherever two letters
 *         overlap the colours cancel to black; an SVG filter (#wm-xray-hole) turns exactly those black pixels into
 *         opaque footer-coloured pixels and everything else transparent. Laid over the fill, that cuts a hole
 *         through both letters wherever they overlap.
 *   hit   Syne outline (transparent fill, text stroke) that fades in on overlapping letters, plus the only layer
 *         that takes pointer events. This is what you see through the hole: the X-ray.
 * Every layer's letter i shares one transform (written by lib/letterDrag.ts), so the three never drift apart and
 * nothing but `transform` ever changes, which keeps layout stable.
 *
 * The two lines keep their original fit: "NEMO'S" is sized so its ink is exactly as wide as "VAULT", and both are
 * optically centred. The numbers are measured per glyph (the letters are separate boxes, so pair kerning is gone)
 * and handed to the lines as CSS variables so every layer copy gets them.
 *
 * `mascot` (FooterMascot) is painted last, over all three layers, and never takes pointer events, so it stands in
 * front of the lettering while every letter under it stays draggable. It is a child of the root on purpose: it
 * shares the watermark's box and its scroll parallax. `has-mascot` only makes room above the lettering for the
 * part of the mascot that rises past it (see .wm-root.has-mascot in globals.css).
 */

const LINES = [
  { key: 'nemo', text: "NEMO'S", offset: 0 },
  { key: 'vault', text: 'VAULT', offset: 6 },
] as const;

type Layer = 'fill' | 'ko' | 'hit';
const LAYERS: Layer[] = ['fill', 'ko', 'hit'];

function WatermarkLayer({ layer }: { layer: Layer }) {
  return (
    <div
      data-wm-layer={layer}
      aria-hidden="true"
      className={`wm-layer wm-${layer} ${layer === 'fill' ? '' : 'absolute inset-0 '}flex flex-col items-center`}
    >
      {LINES.map((line) => (
        <span
          key={line.key}
          data-wm-line={line.key}
          className="wm-line block w-max whitespace-nowrap"
        >
          {Array.from(line.text).map((ch, k) => (
            <span key={k} data-wm-i={line.offset + k} className="wm-ch">
              <span className="wm-g">{ch}</span>
            </span>
          ))}
        </span>
      ))}
    </div>
  );
}

export function FooterWatermark({
  rootRef,
  boundsRef,
  mascot,
}: {
  /** The block itself; Footer animates it (scroll parallax), so Footer owns the ref. */
  rootRef: RefObject<HTMLDivElement | null>;
  /** Horizontal containment for dragged letters (the footer element). */
  boundsRef: RefObject<HTMLElement | null>;
  /** Optional figure painted in front of the lettering (see the note above). */
  mascot?: ReactNode;
}) {
  const setCursor = useVaultStore((s) => s.setCursor);

  // Make "NEMO'S" exactly as wide as "VAULT" (ink-to-ink) and optically centre both lines (sizes are vw/em, so no
  // resize handling is needed). Results go to CSS variables on the root: --wm-nemo-fs, --wm-*-shift.
  useEffect(() => {
    const root = rootRef.current;
    const vault = root?.querySelector<HTMLElement>('[data-wm-line="vault"]');
    if (!root || !vault) return;
    let cancelled = false;

    const fit = () => {
      const ctx = document.createElement('canvas').getContext('2d');
      if (!ctx) return;
      const cs = getComputedStyle(vault);
      ctx.font = `${cs.fontWeight} 1000px ${cs.fontFamily}`;
      const TRACK = -0.05; // tracking-tighter, in em

      // Glyph by glyph, because each letter is its own box.
      const measure = (text: string) => {
        const chars = Array.from(text);
        let x = 0;
        let left = 0;
        let right = 0;
        chars.forEach((ch, k) => {
          const m = ctx.measureText(ch);
          if (k === 0) left = x - m.actualBoundingBoxLeft / 1000;
          right = x + m.actualBoundingBoxRight / 1000;
          x += m.width / 1000 + TRACK;
        });
        return { width: right - left, shift: (left + right) / 2 - x / 2 };
      };

      const v = measure('VAULT');
      const n = measure("NEMO'S");
      root.style.setProperty('--wm-nemo-fs', `${(18 * v.width) / n.width}vw`);
      root.style.setProperty('--wm-vault-shift', `${-v.shift}`);
      root.style.setProperty('--wm-nemo-shift', `${-n.shift}`);
    };

    const cs = getComputedStyle(vault);
    const fonts = document.fonts;
    if (!fonts) {
      fit();
      return;
    }
    fonts
      .load(`${cs.fontWeight} 100px ${cs.fontFamily}`)
      .then(() => fonts.ready)
      .then(() => { if (!cancelled) fit(); })
      .catch(() => { if (!cancelled) fit(); });
    return () => { cancelled = true; };
  }, [rootRef]);

  // Per-letter drag, brightness and X-ray rings. Everything it adds (listeners, timers, frames) is removed on unmount.
  useEffect(() => {
    const root = rootRef.current;
    const bounds = boundsRef.current;
    if (!root || !bounds) return;
    return attachLetterDrag(root, {
      bounds,
      onHoverChange: (on) => (on ? setCursor(true, 'DRAG') : setCursor(false)),
    });
  }, [rootRef, boundsRef, setCursor]);

  return (
    <div
      ref={rootRef}
      className={`wm-root${mascot ? ' has-mascot' : ''} relative mt-12 font-display font-black leading-none tracking-tighter select-none pointer-events-none uppercase will-change-transform`}
    >
      <span className="sr-only">Nemo&apos;s Vault</span>

      {/* Turns the knock-out layer's "black where letters overlap" into "footer colour where letters overlap, clear
          elsewhere": alpha' = A - R (opaque white -> 0, opaque black -> 1, anti-aliased edges stay proportional). */}
      <svg aria-hidden="true" focusable="false" width="0" height="0" className="absolute pointer-events-none">
        <filter id="wm-xray-hole" x="-50%" y="-50%" width="200%" height="200%" colorInterpolationFilters="sRGB">
          <feColorMatrix
            in="SourceGraphic"
            type="matrix"
            values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  -1 0 0 1 0"
            result="hole"
          />
          <feFlood floodColor="currentColor" result="paint" />
          <feComposite in="paint" in2="hole" operator="in" />
        </filter>
      </svg>

      {LAYERS.map((layer) => (
        <WatermarkLayer key={layer} layer={layer} />
      ))}

      {mascot}
    </div>
  );
}
