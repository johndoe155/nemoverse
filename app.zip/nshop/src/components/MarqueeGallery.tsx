'use client';
import { memo, useCallback, useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { galleryData, type GalleryCard } from '@/data/gallery';
import { useVaultStore } from '@/store/useVaultStore';
import { sounds } from '@/lib/sounds';
import { smoothScrollToY } from '@/lib/smoothScroll';

/** Interleave so each row keeps a similar mix of finishes and no slab appears in both rows. */
const ROW_A = galleryData.filter((_, i) => i % 2 === 0);
const ROW_B = galleryData.filter((_, i) => i % 2 === 1);

/**
 * Per-row motion. Durations are for one full loop (one group width) and deliberately differ for depth.
 * At desktop sizes that is roughly 55 px/s (row 1) and 45 px/s (row 2): a slow, steady drift.
 * `delay` is negative so row 2 starts mid-loop instead of mirroring row 1's first frame.
 */
const ROWS = [
  { cards: ROW_A, dir: 'left', duration: 104, delay: 0 },
  { cards: ROW_B, dir: 'right', duration: 126, delay: -38 },
] as const;

/** Hover slows a row to a stop (and back) instead of freezing it; time constant in seconds. */
const HOVER_TAU = 0.28;

/** After a touch interaction (no pointerleave on touch) the row eases back to full speed after this long. */
const TOUCH_RESUME_MS = 1800;

/** The transient "pop" on a card: total length, and the point (0-1) at which it peaks. Instant rise, long settle. */
const POP_MS = 760;
const POP_PEAK_AT = 0.28;

/**
 * Click-to-open sequence (a click or hold on a card in the active row):
 *   press   -> the card pops to its peak at once and stays there; its row slows to CLICK_SLOW_RATE
 *   held    -> after HOLD_MS the row stops completely, for as long as the card is held
 *   release -> the pop settles, then (only once it has fully settled) the page glides to the gallery grid
 * A plain click keeps the pop for CLICK_POP_MS in total; a longer hold keeps it until release.
 */
const CLICK_POP_MS = 2000;
const CLICK_RISE_MS = 220;
const CLICK_SETTLE_MS = 520;
/** Press length that turns a click into a hold (row stops completely). */
const HOLD_MS = 450;
/** Row speed during a click pop, as a fraction of normal. Hover stops a row; this deliberately overrides that. */
const CLICK_SLOW_RATE = 0.12;
/** Where the glide lands: the first gallery card sits this far below the top of the viewport. */
const GALLERY_TOP_GAP = (vh: number) => Math.max(96, vh * 0.14);

/** Only one click sequence can be live at a time; starting another aborts the previous one. */
interface Sequence { abort: () => void }
let liveSequence: Sequence | null = null;

/** Eased scroll to the first card of the gallery grid (or the gallery section when the grid isn't showing). */
function scrollToGalleryStart() {
  const target = document.querySelector<HTMLElement>('#gallery [data-index="0"]')
    ?? document.getElementById('gallery');
  if (!target) return;
  const top = target.getBoundingClientRect().top + window.scrollY;
  smoothScrollToY(Math.max(0, top - GALLERY_TOP_GAP(window.innerHeight)));
}

/** Which row currently owns focus: 0 or 1, or null before the first interaction (both rows at baseline). */
type ActiveRow = 0 | 1 | null;

interface CardProps {
  card: GalleryCard;
  clone: boolean;
  /** Index of the row this card lives in. */
  row: number;
  /** Stable callback: makes `row` the active (dominant) row. No-op when it already is. */
  onActivate: (row: number) => void;
  /** Stable callback: override a row's speed (fraction of normal) or hand control back with null. */
  onRowSpeed: (row: number, rate: number | null) => void;
}

const Card = memo(function Card({ card, clone, row, onActivate, onRowSpeed }: CardProps) {
  const setCursor = useVaultStore((s) => s.setCursor);
  const cardRef = useRef<HTMLDivElement>(null);
  const innerRef = useRef<HTMLDivElement>(null);
  const popRef = useRef<Animation | null>(null);
  const seqRef = useRef<Sequence | null>(null);

  // The transient highlight. Row tiers live on the CSS `scale` property (see .mq-card-inner); the pop is a
  // Web Animation on `transform`, which composes with `scale`, so a pop never fights a row-state transition and
  // can be restarted at any moment. Both run on the compositor: no layout, no paint, no per-frame JS.
  const pop = useCallback(() => {
    const outer = cardRef.current;
    const inner = innerRef.current;
    if (!outer || !inner) return;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    if (seqRef.current) return; // a click sequence owns this card's scale until it finishes

    // Multiplier is a CSS variable so it can shrink on small screens (see globals.css).
    const mult = parseFloat(getComputedStyle(inner).getPropertyValue('--mq-s-pop')) || 1.15;

    popRef.current?.cancel();
    outer.dataset.pop = ''; // lifts the card above its neighbours while it is surging
    const anim = inner.animate(
      [
        { transform: 'scale(1)', easing: 'cubic-bezier(0.2, 0.9, 0.25, 1)' },
        { transform: `scale(${mult})`, offset: POP_PEAK_AT, easing: 'cubic-bezier(0.33, 0, 0.2, 1)' },
        { transform: 'scale(1)' },
      ],
      { duration: POP_MS, easing: 'linear' },
    );
    popRef.current = anim;
    anim.onfinish = () => {
      if (popRef.current !== anim) return;
      popRef.current = null;
      delete outer.dataset.pop;
    };
  }, []);

  useEffect(() => () => {
    popRef.current?.cancel();
    seqRef.current?.abort();
  }, []);

  const engage = useCallback(() => {
    onActivate(row);
    pop();
  }, [onActivate, row, pop]);

  const isRowActive = useCallback(
    () => cardRef.current?.closest('.mq-row')?.getAttribute('data-state') === 'active',
    [],
  );

  // Click / hold on a card of the active row. Same two layers as the hover pop (CSS `scale` for the row tier,
  // a Web Animation on `transform` for the pop), so it stays compositor-only. The only timers are the hold
  // threshold and the settle delay; the scroll starts from the settle animation's own finish event.
  const beginSequence = useCallback(() => {
    const outer = cardRef.current;
    const inner = innerRef.current;
    if (!outer || !inner) return;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

    liveSequence?.abort();
    popRef.current?.cancel();
    popRef.current = null;

    const mult = parseFloat(getComputedStyle(inner).getPropertyValue('--mq-s-pop')) || 1.15;
    const startedAt = performance.now();
    let released = false;
    let done = false;
    let userScrolled = false;
    let holdTimer = 0;
    let settleTimer = 0;
    let settle: Animation | null = null;

    outer.dataset.pop = '';
    const rise = inner.animate(
      [{ transform: 'scale(1)' }, { transform: `scale(${mult})` }],
      { duration: CLICK_RISE_MS, easing: 'cubic-bezier(0.2, 0.9, 0.25, 1)', fill: 'forwards' },
    );
    onRowSpeed(row, CLICK_SLOW_RATE);
    holdTimer = window.setTimeout(() => { if (!released) onRowSpeed(row, 0); }, HOLD_MS);

    const onUp = () => release();
    const onKeyUp = (e: KeyboardEvent) => { if (e.key === 'Enter' || e.key === ' ') release(); };
    // A touch that turns into a page scroll is cancelled by the browser: abort instead of hijacking the scroll.
    const onCancel = () => teardown();
    // Scrolling by hand while the pop is running cancels the automatic scroll.
    const onWheel = () => { userScrolled = true; };

    const teardown = () => {
      if (done) return;
      done = true;
      window.clearTimeout(holdTimer);
      window.clearTimeout(settleTimer);
      window.removeEventListener('pointerup', onUp);
      window.removeEventListener('pointercancel', onCancel);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('blur', onUp);
      window.removeEventListener('wheel', onWheel);
      rise.cancel();
      settle?.cancel();
      delete outer.dataset.pop;
      onRowSpeed(row, null);
      if (liveSequence === seq) liveSequence = null;
      if (seqRef.current === seq) seqRef.current = null;
    };

    const startSettle = () => {
      const anim = inner.animate(
        [{ transform: `scale(${mult})` }, { transform: 'scale(1)' }],
        { duration: CLICK_SETTLE_MS, easing: 'cubic-bezier(0.65, 0, 0.35, 1)', fill: 'forwards' },
      );
      settle = anim;
      // The pop is over exactly when this fires; only now does the page start to move.
      anim.onfinish = () => {
        const go = !userScrolled;
        teardown();
        if (go) scrollToGalleryStart();
      };
    };

    function release() {
      if (released || done) return;
      released = true;
      window.clearTimeout(holdTimer);
      onRowSpeed(row, CLICK_SLOW_RATE);
      // Plateau lasts until the 2s mark (a click) or until release (a longer hold), whichever is later.
      const now = performance.now();
      const settleAt = Math.max(startedAt + CLICK_POP_MS - CLICK_SETTLE_MS, now);
      settleTimer = window.setTimeout(startSettle, settleAt - now);
    }

    const seq: Sequence = { abort: teardown };
    liveSequence = seq;
    seqRef.current = seq;
    window.addEventListener('pointerup', onUp);
    window.addEventListener('pointercancel', onCancel);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('blur', onUp);
    window.addEventListener('wheel', onWheel, { passive: true });
  }, [row, onRowSpeed]);


  return (
    <div
      ref={cardRef}
      className="mq-card group relative cursor-none"
      // A held press must not select text or open the touch callout / context menu.
      style={{ userSelect: 'none', WebkitTouchCallout: 'none' }}
      onContextMenu={(e) => { if (seqRef.current) e.preventDefault(); }}
      tabIndex={clone ? -1 : 0}
      role={clone ? undefined : 'button'}
      aria-label={clone ? undefined : `View ${card.name}`}
      onMouseEnter={() => {
        setCursor(true, 'VIEW');
        sounds.hover();
      }}
      onMouseLeave={() => setCursor(false)}
      // Mouse/pen: hover. Touch has no hover, so the first finger-down is the interaction.
      onPointerEnter={(e) => { if (e.pointerType !== 'touch') engage(); }}
      // A press on a card of the already-active row starts the click sequence (a touch on an inactive row
      // only activates it, as before). Hover has normally made the row active by the time a mouse presses.
      onPointerDown={(e) => {
        const wasActive = isRowActive();
        if (wasActive && (e.pointerType === 'touch' || e.button === 0)) beginSequence();
        else if (e.pointerType === 'touch') engage();
      }}
      // Keyboard focus only (a mouse click also focuses, but hover already handled it).
      onFocus={(e) => { if (e.currentTarget.matches(':focus-visible')) engage(); }}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          if (e.repeat) return;
          if (isRowActive()) beginSequence();
          else engage();
          sounds.click();
        }
      }}
      onClick={() => {
        engage(); // re-fires the pop on an already-active row; never changes anything else
        sounds.click();
      }}
    >
      <div ref={innerRef} className="mq-card-inner">
      <div className="slab-frame aspect-[3/4] bg-[#111]">
        <div className="absolute top-0 left-0 right-0 z-10 flex justify-between p-2">
          <span className="font-mono text-[8px] px-1.5 py-0.5 bg-[#FF4D00] text-white">{card.style.toUpperCase()}</span>
          <span className="font-mono text-[8px] text-white/50">{card.id}</span>
        </div>
        {/* Explicit box (aspect-ratio parent + absolute fill) so image decode never moves anything. */}
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={card.image}
          alt={clone ? '' : card.name}
          width={240}
          height={320}
          decoding="async"
          draggable={false}
          className="absolute inset-0 w-full h-full object-cover select-none group-hover:scale-105 transition-transform duration-700"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-60" />
        <div className="absolute bottom-0 left-0 right-0 p-3">
          <div className="font-bold text-[12px] leading-tight truncate">{card.name}</div>
          <div className="font-mono text-[9px] text-white/50 truncate">{card.collection}</div>
        </div>
        {/* Holo overlay */}
        <div
          className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 mix-blend-overlay"
          style={{ background: 'linear-gradient(105deg, transparent 20%, rgba(255,77,0,0.3), rgba(0,229,255,0.3), transparent 80%)' }}
        />
      </div>
      </div>
    </div>
  );
});

export function MarqueeGallery() {
  const sectionRef = useRef<HTMLElement>(null);
  const rowRefs = useRef<(HTMLDivElement | null)[]>([]);
  /** Per-row speed override, installed by the hover-easing effect below. */
  const rowSpeed = useRef<Array<{ setOverride: (rate: number | null) => void } | null>>([]);
  const setRowSpeed = useCallback((r: number, rate: number | null) => {
    rowSpeed.current[r]?.setOverride(rate);
  }, []);

  // Sticky row focus: set by the first interaction with a row, and only ever changed by interacting with the
  // other row. Rendering is cheap: cards are memoised with stable props, and the visual change is driven purely
  // by the `data-state` attribute on each row (CSS custom properties), so no card re-renders on a swap.
  const [activeRow, setActiveRow] = useState<ActiveRow>(null);
  const activate = useCallback((r: number) => {
    setActiveRow((prev) => (prev === r ? prev : (r as 0 | 1)));
  }, []);

  // One restrained entrance (header drops in, the two rows rise in a short stagger), fired once.
  // It targets the row wrappers, never the tracks: the tracks' `transform` belongs to the CSS loop.
  useEffect(() => {
    if (!sectionRef.current) return;
    gsap.registerPlugin(ScrollTrigger);
    const ctx = gsap.context(() => {
      gsap.fromTo('.marquee-head',
        { y: 24, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.8, ease: 'power3.out',
          scrollTrigger: { trigger: sectionRef.current, start: 'top 90%', once: true } }
      );
      gsap.fromTo('.mq-row',
        { y: 40, opacity: 0 },
        { y: 0, opacity: 1, duration: 1.1, ease: 'power3.out', delay: 0.15, stagger: 0.14,
          scrollTrigger: { trigger: sectionRef.current, start: 'top 88%', once: true } }
      );
    }, sectionRef);
    return () => ctx.revert();
  }, []);

  // Hover easing. The loop is a plain CSS animation; on pointer hover we only ramp that animation's
  // playbackRate toward 0 (and back to 1) with exponential smoothing. The rAF loop runs only while a
  // ramp is in flight, so at steady state (moving or stopped) there is zero per-frame JS.
  useEffect(() => {
    const cleanups: Array<() => void> = [];

    rowRefs.current.forEach((row, r) => {
      const track = row?.querySelector<HTMLElement>('.mq-track');
      if (!row || !track) return;

      let base = 1; // what hover / touch / focus ask for
      let override: number | null = null; // a click sequence, which wins while it runs
      let target = 1;
      let rate = 1;
      let raf = 0;
      let last = 0;

      const step = (now: number) => {
        const dt = Math.min((now - last) / 1000, 0.05);
        last = now;
        rate += (target - rate) * (1 - Math.exp(-dt / HOVER_TAU));
        if (Math.abs(target - rate) < 0.002) rate = target;
        // Re-query every frame: cheap, and survives the browser re-creating the CSSAnimation.
        track.getAnimations().forEach((a) => { a.playbackRate = rate; });
        raf = rate === target ? 0 : requestAnimationFrame(step);
      };

      const retarget = () => {
        target = override ?? base;
        if (raf) return;
        last = performance.now();
        raf = requestAnimationFrame(step);
      };
      const ramp = (to: number) => {
        base = to;
        retarget();
      };
      rowSpeed.current[r] = {
        setOverride: (v) => {
          override = v;
          retarget();
        },
      };

      let touchTimer = 0;
      const onEnter = (e: PointerEvent) => { if (e.pointerType === 'mouse') ramp(0); };
      const onLeave = (e: PointerEvent) => { if (e.pointerType === 'mouse') ramp(1); };
      // Touch has no leave event: slow on finger-down and resume after a short beat.
      const onDown = (e: PointerEvent) => {
        if (e.pointerType !== 'touch') return;
        ramp(0);
        window.clearTimeout(touchTimer);
        touchTimer = window.setTimeout(() => ramp(1), TOUCH_RESUME_MS);
      };
      // Keyboard: a focused card holds its row still until focus leaves the row.
      const onFocusIn = () => ramp(0);
      const onFocusOut = (e: FocusEvent) => {
        if (!row.contains(e.relatedTarget as Node | null)) ramp(1);
      };

      row.addEventListener('pointerenter', onEnter);
      row.addEventListener('pointerleave', onLeave);
      row.addEventListener('pointerdown', onDown);
      row.addEventListener('focusin', onFocusIn);
      row.addEventListener('focusout', onFocusOut);
      cleanups.push(() => {
        row.removeEventListener('pointerenter', onEnter);
        row.removeEventListener('pointerleave', onLeave);
        row.removeEventListener('pointerdown', onDown);
        row.removeEventListener('focusin', onFocusIn);
        row.removeEventListener('focusout', onFocusOut);
        window.clearTimeout(touchTimer);
        rowSpeed.current[r] = null;
        if (raf) cancelAnimationFrame(raf);
      });
    });

    return () => cleanups.forEach((fn) => fn());
  }, []);

  return (
    <section ref={sectionRef} className="relative py-6 border-y border-[#1A1A1A] overflow-hidden bg-[#0a0a0a]">
      <div className="marquee-head flex flex-wrap items-center gap-x-4 gap-y-2 px-6 md:px-12 mb-6">
        <div className="font-mono text-[10px] tracking-[0.3em] text-[#FF4D00]">RECENT FORGES • LIVE FROM THE VAULT</div>
        <div className="h-[1px] flex-1 bg-gradient-to-r from-[#FF4D00]/50 to-transparent" />
        <div className="font-mono text-[10px] text-[#F5F3EF]/30 tabular">{galleryData.length} SLABS • 2023–2024</div>
      </div>

      <div className="mq flex flex-col">
        {ROWS.map((row, r) => (
          <div
            key={row.dir}
            ref={(el) => { rowRefs.current[r] = el; }}
            className="mq-row"
            data-state={activeRow === null ? 'idle' : activeRow === r ? 'active' : 'inactive'}
          >
            <div
              className="mq-track"
              data-dir={row.dir}
              style={{
                '--mq-duration': `${row.duration}s`,
                '--mq-delay': `${row.delay}s`,
              } as React.CSSProperties}
            >
              {[false, true].map((clone) => (
                <div key={String(clone)} className="mq-group" aria-hidden={clone || undefined}>
                  {row.cards.map((card) => (
                    <Card key={card.id} card={card} clone={clone} row={r} onActivate={activate} onRowSpeed={setRowSpeed} />
                  ))}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
