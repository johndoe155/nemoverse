'use client';
import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { AnimatedWordmark, type AnimatedWordmarkHandle } from './preloader/AnimatedWordmark';
import { trackLoadProgress } from '@/lib/loadProgress';

/** Eased catch-up when loading finishes before the wordmark has played out (ms). */
const FINISH_MIN_MS = 450;
const FINISH_SPAN_MS = 1350;
/** How closely the wordmark/bar follow the real progress while loading is still in flight. */
const FOLLOW_TAU_S = 0.18;
/** Beat on the finished wordmark before the curtain lifts (s). */
const EXIT_HOLD_S = 0.2;

export function Preloader({ onComplete }: { onComplete: () => void }) {
  const containerRef = useRef<HTMLDivElement>(null);
  const textRef = useRef<HTMLDivElement>(null);
  const wordmarkRef = useRef<AnimatedWordmarkHandle>(null);
  const barRef = useRef<HTMLDivElement>(null);
  const pctRef = useRef<HTMLSpanElement>(null);

  // Displayed progress (0..1). Lives in a ref - not state - so it is not reset by React 19
  // StrictMode's mount/unmount/mount in dev, and so 60fps updates never re-render the tree.
  const shownRef = useRef(0);
  // Set once the exit has been scheduled. Guarantees the wordmark finishes - and the exit
  // fires - exactly once per Preloader instance, however many times effects re-run.
  const doneRef = useRef(false);
  const onCompleteRef = useRef(onComplete);
  useEffect(() => {
    onCompleteRef.current = onComplete;
  }, [onComplete]);

  // Real load progress -> eased display value -> wordmark timeline + bar + counter.
  useEffect(() => {
    if (doneRef.current) return;

    const tracker = trackLoadProgress();
    let raf = 0;
    let last = performance.now();
    let finish: { from: number; t0: number; dur: number } | null = null;

    const paint = (v: number) => {
      wordmarkRef.current?.seek(v);
      if (barRef.current) barRef.current.style.width = `${v * 100}%`;
      if (pctRef.current) pctRef.current.textContent = String(Math.min(100, Math.floor(v * 100)));
    };

    const tick = (now: number) => {
      const dt = Math.min(0.1, (now - last) / 1000);
      last = now;

      const target = tracker.get();
      let v = shownRef.current;

      if (target >= 1) {
        // Loading is done. Never snap: ease the remaining distance, taking longer the further
        // the wordmark still has to go, so even an instant load plays its final frames through.
        if (!finish) {
          finish = { from: v, t0: now, dur: FINISH_MIN_MS + FINISH_SPAN_MS * (1 - v) };
        }
        const k = Math.min(1, (now - finish.t0) / finish.dur);
        v = Math.max(v, finish.from + (1 - finish.from) * (1 - Math.pow(1 - k, 3)));
      } else {
        // Still loading: glide toward the real value, never ahead of it.
        v = Math.min(target, v + (target - v) * (1 - Math.exp(-dt / FOLLOW_TAU_S)));
      }

      v = v >= 0.9995 ? 1 : v;
      shownRef.current = v;
      paint(v);

      if (v >= 1) {
        doneRef.current = true;
        tracker.stop();
        gsap
          .timeline({ delay: EXIT_HOLD_S, onComplete: () => onCompleteRef.current() })
          .to(containerRef.current, { yPercent: -100, duration: 1.2, ease: 'power4.inOut' });
        return; // stop the loop: nothing left that could replay the wordmark
      }
      raf = requestAnimationFrame(tick);
    };

    paint(shownRef.current);
    raf = requestAnimationFrame(tick);

    return () => {
      cancelAnimationFrame(raf);
      tracker.stop();
    };
  }, []);

  // GSAP intro
  useEffect(() => {
    gsap.fromTo(textRef.current?.children || [],
      { y: 100, opacity: 0 },
      { y: 0, opacity: 1, duration: 1, stagger: 0.08, ease: 'power4.out', delay: 0.2 }
    );
  }, []);

  return (
    <div ref={containerRef} className="fixed inset-0 z-[100] bg-[#080808] flex flex-col items-center justify-center">
      {/* Grid */}
      <div className="absolute inset-0 opacity-[0.03]" style={{
        backgroundImage: `linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)`,
        backgroundSize: '80px 80px'
      }} />

      <div ref={textRef} className="relative z-10 text-center">
        {/* Logo stamp animation with real assets */}
        <div className="mb-12 flex justify-center">
          <div className="relative">
            <div className="w-24 h-24 border border-[#FF4D00] bg-[#F5F3EF] grid place-items-center p-3 animate-pulse">
              <img src="/logo-mark-orange.svg" alt="Nemo's" className="w-full h-full object-contain" />
            </div>
            <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-[#FF4D00]" />
            <img src="/mascot/stamping.png" alt="Nemo stamping" className="absolute -top-8 -right-12 w-16 h-16 object-contain rotate-12 hidden md:block" />
          </div>
        </div>

        <div className="overflow-hidden">
          <div className="flex justify-center mb-4">
            <AnimatedWordmark ref={wordmarkRef} className="h-12 md:h-16" />
          </div>
          <h1 className="font-display font-black text-[14vw] md:text-[10vw] leading-[0.85] tracking-tighter text-[#F5F3EF]">
            <span className="block">NEMO'S</span>
            <span className="block font-light italic">CARD SHOP</span>
          </h1>
        </div>
        
        <div className="mt-8 flex items-center justify-center gap-4 overflow-hidden">
          <div className="h-[1px] w-12 bg-[#FF4D00]" />
          <span className="font-mono text-[10px] tracking-[0.3em] text-[#F5F3EF]/50">FORGING PHYSICAL GRAILS</span>
          <div className="h-[1px] w-12 bg-[#FF4D00]" />
        </div>
      </div>

      {/* Progress */}
      <div className="absolute bottom-0 left-0 right-0 p-8 flex items-end justify-between">
        <div className="font-mono text-[10px] text-[#F5F3EF]/30">
          LOADING ASSETS • <span ref={pctRef}>0</span>%<br/>
          <span className="text-[#FF4D00]">SHADERS • TEXTURES • PHYSICS</span>
        </div>
        <div className="w-48 h-[2px] bg-[#1A1A1A] overflow-hidden">
          <div ref={barRef} className="h-full bg-[#FF4D00]" style={{ width: '0%' }} />
        </div>
      </div>

      {/* Corner marks */}
      <div className="absolute top-8 left-8 w-4 h-4 border-l border-t border-[#F5F3EF]/20" />
      <div className="absolute top-8 right-8 w-4 h-4 border-r border-t border-[#F5F3EF]/20" />
      <div className="absolute bottom-8 left-8 w-4 h-4 border-l border-b border-[#F5F3EF]/20" />
      <div className="absolute bottom-8 right-8 w-4 h-4 border-r border-b border-[#F5F3EF]/20" />
    </div>
  );
}
