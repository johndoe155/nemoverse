'use client';
import { Fragment, useRef, useEffect } from 'react';
import gsap from 'gsap';
import { useVaultStore } from '@/store/useVaultStore';
import { sounds } from '@/lib/sounds';
import { useMagnetic } from '@/lib/magnetic';
import { FooterWordmark } from '@/components/FooterWordmark';
import { FooterStamp } from '@/components/FooterStamp';
import { FooterWatermark } from '@/components/FooterWatermark';
import { FooterMascot } from '@/components/FooterMascot';

export function Footer() {
  const setCursor = useVaultStore((s) => s.setCursor);

  // Subtle magnetic pull for the footer "N" stamp (shared delegated manager in lib/magnetic.ts; no-op on touch).
  const markMagnetRef = useMagnetic({ radius: 140, strengthX: 0.14, strengthY: 0.14 });

  const goForge = () => {
    sounds.click();
    document.getElementById('forge')?.scrollIntoView({ behavior: 'smooth' });
  };
  const footerRef = useRef<HTMLElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);
  const watermarkRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!ctaRef.current) return;
    
    const ctx = gsap.context(() => {
      // Watermark parallax
      gsap.to(watermarkRef.current, {
        yPercent: -20,
        ease: 'none',
        scrollTrigger: {
          trigger: ctaRef.current,
          start: 'top bottom',
          end: 'bottom top',
          scrub: 1,
        }
      });

      // CTA magnetic
      const cta = ctaRef.current;
      if (!cta) return;
      
      const xTo = gsap.quickTo(cta, 'x', { duration: 0.6, ease: 'power3' });
      const yTo = gsap.quickTo(cta, 'y', { duration: 0.6, ease: 'power3' });
      
      const onMove = (e: MouseEvent) => {
        const rect = cta.getBoundingClientRect();
        const x = e.clientX - (rect.left + rect.width / 2);
        const y = e.clientY - (rect.top + rect.height / 2);
        const dist = Math.sqrt(x*x + y*y);
        if (dist < 400) {
          xTo(x * 0.15);
          yTo(y * 0.15);
        }
      };
      
      window.addEventListener('mousemove', onMove);
      return () => window.removeEventListener('mousemove', onMove);
    }, ctaRef);
    
    return () => ctx.revert();
  }, []);

  return (
    <footer ref={footerRef} className="relative bg-[#050505] border-t border-[#1A1A1A] px-6 md:px-12 xl:px-24 py-16 md:py-24 overflow-hidden">
      {/* Physics CTA Banner */}
      <div ref={ctaRef} onClick={goForge} role="link" aria-label="Commission a card"
           onMouseEnter={() => setCursor(true, "FORGE")}
           onMouseLeave={() => setCursor(false)}
           className="max-w-[1600px] mx-auto mb-16 border border-[#FF4D00]/20 bg-[#FF4D00]/5 p-8 md:p-12 relative overflow-hidden group hover:border-[#FF4D00]/40 transition-colors cursor-none">
        <div className="absolute inset-0 opacity-20 group-hover:opacity-30 transition-opacity">
          <div className="absolute inset-0" style={{
            backgroundImage: `repeating-linear-gradient(45deg, transparent, transparent 10px, rgba(255,77,0,0.1) 10px, rgba(255,77,0,0.1) 11px)`
          }} />
        </div>
        
        <div className="relative z-10 flex flex-wrap items-center justify-between gap-8">
          <div>
            <div className="font-mono text-[10px] tracking-[0.3em] text-[#FF4D00] mb-2 flex items-center gap-2">
              <span className="w-2 h-2 bg-[#FF4D00] rounded-full animate-pulse" />
              PHYSICS HOVER • MAGNETIC • TRY MOVING CURSOR CLOSE
            </div>
            <div className="font-display font-black text-[32px] md:text-[48px] leading-[0.9] tracking-tighter uppercase">
              Ready To<br/>
              <span className="foil-text">Forge Yours?</span>
            </div>
            <div className="font-mono text-[11px] text-[#F5F3EF]/50 mt-3">
              True WebGL • Rapier Physics • GLSL Shaders • 60FPS • 2,847 slabs and counting
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="hidden md:block text-right font-mono text-[10px] leading-relaxed text-[#F5F3EF]/30">
              <div>MODEL: NMO-VAULT-01</div>
              <div>FINISH: ALL • PHYSICS: RAPIER</div>
              <div className="text-[#FF4D00]">● LIVE • INTERACTIVE</div>
            </div>
            <div className="w-20 h-20 bg-[#FF4D00] rounded-full grid place-items-center font-black text-2xl text-white group-hover:scale-110 group-hover:rotate-12 transition-transform duration-500">
              →
            </div>
          </div>
        </div>

        {/* Floating orbs for physics feel */}
        <div className="absolute top-4 right-20 w-2 h-2 bg-[#FF4D00]/30 rounded-full animate-[float_3s_ease-in-out_infinite]" />
        <div className="absolute bottom-8 right-40 w-1 h-1 bg-[#00E5FF]/50 rounded-full animate-[float_4s_ease-in-out_infinite_0.5s]" />
        <div className="absolute top-12 left-1/2 w-1.5 h-1.5 bg-[#FFE600]/40 rounded-full animate-[float_3.5s_ease-in-out_infinite_1s]" />
      </div>

      <div className="max-w-[1600px] mx-auto">
        <div>
          <div className="flex items-center gap-3 mb-6 ml-4 md:ml-6">
            {/* Same "N" stamp as the Preloader (1px orange outline, cream tile, solid orange corner square), scaled to
                48px (1/2 size -> 1/8-size corner square). The wrapper is the magnetic target so tile + corner move
                together; it is purely decorative, so pointer-events-none keeps it from ever blocking neighbours.
                FooterStamp renders the tile, outline trail and corner square, and scrubs them in on scroll (see
                FooterStamp.tsx); once finished it is exactly the static markup this used to be. */}
            <div ref={markMagnetRef as React.RefObject<HTMLDivElement | null>} className="relative shrink-0 pointer-events-none will-change-transform">
              <FooterStamp />
            </div>
            <div className="leading-none">
              <div className="font-mono text-[9px] tracking-[0.2em] opacity-60">TOUCH GRASS. TOUCH SLABS.</div>
            </div>
          </div>
          <p className="font-body text-[13px] leading-relaxed text-[#F5F3EF]/50 max-w-[320px]">
            Turning NFTs into museum-grade slabs since 2023. Now with Rapier physics, true GLSL, and Nemo that follows you when idle. Not affiliated with PSA, but we have better foil and better physics.
          </p>
          <div className="mt-6 flex items-center justify-between gap-6">
            <div className="flex gap-2">
              <a href="https://x.com/nemoscardshop" target="_blank" rel="noopener noreferrer" onMouseEnter={() => setCursor(true, "X")} onMouseLeave={() => setCursor(false)} className="w-8 h-8 bg-[#1A1A1A] border border-[#2A2A2A] grid place-items-center font-mono text-[10px] hover:border-[#FF4D00]/50 hover:text-[#FF4D00] transition-colors cursor-none">X</a>
              <a href="#" onClick={(e) => e.preventDefault()} onMouseEnter={() => setCursor(true, "SOON")} onMouseLeave={() => setCursor(false)} className="w-8 h-8 bg-[#1A1A1A] border border-[#2A2A2A] grid place-items-center font-mono text-[10px] hover:border-[#FF4D00]/50 hover:text-[#FF4D00] transition-colors cursor-none">IG</a>
              <a href="#" onClick={(e) => e.preventDefault()} onMouseEnter={() => setCursor(true, "SOON")} onMouseLeave={() => setCursor(false)} className="w-8 h-8 bg-[#1A1A1A] border border-[#2A2A2A] grid place-items-center font-mono text-[10px] hover:border-[#FF4D00]/50 hover:text-[#FF4D00] transition-colors cursor-none">DC</a>
              <a href="https://github.com/johndoe155/cardshop" target="_blank" rel="noopener noreferrer" onMouseEnter={() => setCursor(true, "REPO")} onMouseLeave={() => setCursor(false)} className="w-8 h-8 bg-[#FF4D00] border border-[#FF4D00] grid place-items-center font-mono text-[10px] text-white hover:scale-110 transition-transform cursor-none">GH</a>
            </div>
            <FooterWordmark className="h-8 sm:h-10 md:h-14" />
          </div>
        </div>

        <div className="mt-16 pt-8 border-t border-[#1A1A1A] flex flex-wrap items-center justify-between gap-4">
          <div className="font-mono text-[10px] tracking-widest text-[#F5F3EF]/20">
            ©2024 NEMO'S CARD SHOP • BUILT IN THE VAULT • OHIO + INTERNET • PHYSICS • GLSL • 60FPS
          </div>
        </div>

        {/* Draggable letters; the fit (NEMO'S as wide as VAULT), drag physics, X-ray overlap and brightness live in
            FooterWatermark / lib/letterDrag. This block is still the scroll-parallax target. Nemo stands in front of
            it (FooterMascot); he is inside the block, so he rides the same parallax, and he never blocks the letters. */}
        <FooterWatermark rootRef={watermarkRef} boundsRef={footerRef} mascot={<FooterMascot />} />

        <nav aria-label="Legal" className="mt-8 md:mt-10 flex items-center justify-center gap-6 md:gap-10">
          {['Terms', 'IP Policy'].map((label, i) => (
            <Fragment key={label}>
              {i > 0 && <span aria-hidden="true" className="w-px h-3 bg-[#F5F3EF]/20" />}
              <a href="#" onClick={(e) => e.preventDefault()} onMouseEnter={() => setCursor(true, "VAULT")} onMouseLeave={() => setCursor(false)}
                 className="group relative py-2 font-display font-bold text-[12px] md:text-[13px] leading-none tracking-[0.28em] uppercase text-[#F5F3EF]/80 hover:text-[#F5F3EF] transition-colors duration-500 cursor-none">
                {label}
                <span aria-hidden="true" className="absolute left-0 right-[0.28em] bottom-0 h-px bg-[#FF4D00] origin-left scale-x-0 group-hover:scale-x-100 transition-transform duration-500 ease-out" />
              </a>
            </Fragment>
          ))}
        </nav>
      </div>

      <style jsx>{`
        @keyframes float {
          0%, 100% { transform: translateY(0) rotate(0); }
          50% { transform: translateY(-10px) rotate(5deg); }
        }
      `}</style>
    </footer>
  );
}
