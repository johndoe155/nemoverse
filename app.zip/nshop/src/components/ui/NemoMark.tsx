import { MARK_BASE, MARK_HILITE, MARK_INK } from "./nemoMarkPaths";

/**
 * The "N" mark as inline SVG (same geometry as /logo-mark-orange.svg). Drawn un-blended on top of the
 * blended N tile in the Navbar.
 */
export function NemoMark({
  className,
  title = "Nemo's",
  ref,
}: {
  className?: string;
  title?: string;
  /** Exposes the root <svg> so callers can animate the glyph alone (React 19: `ref` is a plain prop). */
  ref?: React.Ref<SVGSVGElement>;
}) {
  const body = "#FF4D00";
  return (
    <svg
      ref={ref}
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 40 40"
      className={className}
      role="img"
      aria-label={title}
      focusable="false"
    >
      <g transform="translate(-0.006521 -6.48619) scale(0.043306)" fillRule="evenodd" strokeWidth={0.25} strokeLinejoin="round">
        <path d={MARK_BASE} fill={body} stroke={body} />
        <path d={MARK_HILITE} fill="#ffffff" stroke="#ffffff" />
        <path d={MARK_INK} fill="#010101" stroke="#010101" />
      </g>
    </svg>
  );
}
