'use client';
import { useState, useMemo, useRef, useEffect, useLayoutEffect, useCallback } from 'react';
import { galleryData, collections, styles } from '@/data/gallery';
import { slabCards } from '@/data/slabCards';
import { useVaultStore } from '@/store/useVaultStore';
import { SlabFrame } from './ui/SlabFrame';
import { MagneticButton } from './ui/MagneticButton';
import { sounds } from '@/lib/sounds';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import dynamic from 'next/dynamic';

// Dynamic import for physics pit to avoid SSR
const GalleryPitPhysics = dynamic(() => import('./canvas/GalleryPitPhysics'), { ssr: false });

// ─── Card stack ──────────────────────────────────────────────────────────────
// Un-revealed slabs sit in a nested pile behind the last revealed slab ("pivot").
// They are absolutely positioned (out of grid flow, so they reserve no space) and
// posed with GSAP transforms only. Revealing a batch is a FLIP: each card flies
// from its pile pose to its natural grid cell.
const STACK_TILT = [-3.2, 2.4, -1.5, 3.4, -2.6, 1.8, -3.6]; // unique per card, so edges peek out
const STACK_PEEK_LAYERS = 3; // layers drawn behind the pivot; deeper cards are hidden
const STACK_EASE = 'power4.out';
const CONTROL_SPACE = 200; // px reserved under the last row for the unstack control

function stackPose(index: number, depth: number, px: number, py: number, pw: number) {
  const layer = Math.min(depth, STACK_PEEK_LAYERS - 1);
  const tilt = STACK_TILT[index % STACK_TILT.length];
  const step = Math.min(15, Math.max(9, pw * 0.045));
  return {
    x: px + tilt * 2.2,
    y: py + (layer + 1) * step,
    rotation: tilt,
    scale: 1 - (layer + 1) * 0.02,
    opacity: depth < STACK_PEEK_LAYERS ? 1 : 0,
    shade: 0.38 + layer * 0.2,
    step,
  };
}

function columnsFor(width: number) {
  return width >= 1280 ? 4 : width >= 1024 ? 3 : width >= 768 ? 2 : 1;
}

export function Gallery() {
  const setCursor = useVaultStore((s) => s.setCursor);
  const [filterType, setFilterType] = useState<'all' | 'collection' | 'style'>('all');
  const [selectedCollection, setSelectedCollection] = useState('all');
  const [selectedStyle, setSelectedStyle] = useState('all');
  const [viewMode, setViewMode] = useState<'grid' | 'pit'>('grid');
  const [isDragging, setIsDragging] = useState(false);
  const [zeroG, setZeroG] = useState(false);
  const gridRef = useRef<HTMLDivElement>(null);
  const ctrlRef = useRef<HTMLDivElement>(null);
  const cardRefs = useRef<(HTMLDivElement | null)[]>([]);
  const intent = useRef<{ from: number; to: number } | null>(null);
  const busy = useRef(false);
  const lastKey = useRef('');
  const live = useRef({ revealed: 1, batch: 4, total: 0 });

  // Columns -> batch size. Batches are whole rows (4 / 4 / 6 / 4 cards).
  const [cols, setCols] = useState(() => (typeof window === 'undefined' ? 4 : columnsFor(window.innerWidth)));
  const batch = cols === 3 ? 6 : 4;
  const [revealed, setRevealed] = useState(1);
  const [armed, setArmed] = useState(false); // first scroll reveal has happened
  const [layoutTick, setLayoutTick] = useState(0);

  const filtered = useMemo(() => {
    return galleryData.filter(card => {
      if (selectedCollection !== 'all' && card.collection !== selectedCollection) return false;
      if (selectedStyle !== 'all' && card.style !== selectedStyle) return false;
      return true;
    });
  }, [selectedCollection, selectedStyle]);

  // The pit renders the layered slab model (acrylic case + foil), so it takes
  // SlabCard records. They use the same collection / finish vocabulary as
  // galleryData, so the same filters apply.
  const pitCards = useMemo(() => {
    return slabCards.filter(card => {
      if (selectedCollection !== 'all' && card.collection !== selectedCollection) return false;
      if (selectedStyle !== 'all' && card.style !== selectedStyle) return false;
      return true;
    });
  }, [selectedCollection, selectedStyle]);

  // Changing a filter restacks the pile: first batch revealed right away
  // (the visitor is already engaged), the rest nested behind it.
  const filterKey = `${selectedCollection}|${selectedStyle}`;
  const [prevFilterKey, setPrevFilterKey] = useState(filterKey);
  if (prevFilterKey !== filterKey) {
    setPrevFilterKey(filterKey);
    setRevealed(armed ? Math.min(batch, filtered.length) : 1);
  }

  useLayoutEffect(() => {
    live.current = { revealed, batch, total: filtered.length };
  });

  // Viewport columns (batch size follows the grid)
  useEffect(() => {
    const queries = [1280, 1024, 768].map((w) => window.matchMedia(`(min-width: ${w}px)`));
    const update = () => setCols(columnsFor(window.innerWidth));
    queries.forEach((q) => q.addEventListener('change', update));
    return () => queries.forEach((q) => q.removeEventListener('change', update));
  }, []);

  // Re-pose the pile when the grid's width changes (height changes are ours).
  useEffect(() => {
    const grid = gridRef.current;
    if (viewMode !== 'grid' || !grid) return;
    let w = grid.clientWidth;
    const ro = new ResizeObserver(() => {
      if (grid.clientWidth !== w) {
        w = grid.clientWidth;
        setLayoutTick((t) => t + 1);
      }
    });
    ro.observe(grid);
    return () => ro.disconnect();
  }, [viewMode]);

  const unstack = useCallback(() => {
    const { revealed: r, batch: b, total } = live.current;
    if (busy.current || r >= total) return;
    const next = Math.min(total, r < b ? b : r + b);
    busy.current = true;
    intent.current = { from: r, to: next };
    setArmed(true);
    setRevealed(next);
    window.setTimeout(() => { busy.current = false; }, 2600); // safety net
  }, []);

  // Pose every card: revealed cards sit in the grid, the rest form the pile
  // behind the last revealed one. Runs before paint, so nothing ever flashes.
  useLayoutEffect(() => {
    const grid = gridRef.current;
    if (viewMode !== 'grid' || !grid) return;
    const total = filtered.length;
    const shown = Math.min(revealed, total);
    const els = Array.from({ length: total }, (_, i) => cardRefs.current[i]).filter((e): e is HTMLDivElement => !!e);
    if (els.length !== total) return;
    const ctrl = ctrlRef.current;
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const it = intent.current;
    intent.current = null;
    const animate = !!it && !reduce;
    const shadeOf = (el: HTMLElement) => el.querySelector<HTMLElement>('.gstack-shade');

    gsap.killTweensOf(els);
    if (ctrl) gsap.killTweensOf(ctrl);
    busy.current = false;

    // 1. Cards in grid flow. Anything before `flyFrom` is already settled.
    const flyFrom = it ? Math.min(it.from, shown) : shown;
    for (let i = 0; i < shown; i++) {
      const el = els[i];
      el.style.width = '';
      el.style.zIndex = '';
      if (i < flyFrom) {
        gsap.set(el, { x: 0, y: 0, rotation: (i % 3 - 1) * 1.5, scale: 1, opacity: 1 });
        const sh = shadeOf(el);
        if (sh) gsap.set(sh, { opacity: 0 });
      }
    }

    // 2. Newly revealed cards: FLIP from their pile pose to their grid cell.
    const flyers: { el: HTMLDivElement; x: number; y: number; r: number; s: number; o: number; base: number }[] = [];
    for (let i = flyFrom; i < shown; i++) {
      const el = els[i];
      const base = (i % 3 - 1) * 1.5;
      const sh = shadeOf(el);
      if (!animate) {
        gsap.set(el, { x: 0, y: 0, rotation: base, scale: 1, opacity: 1 });
        if (sh) gsap.set(sh, { opacity: 0 });
        continue;
      }
      flyers.push({
        el,
        x: (gsap.getProperty(el, 'x') as number) - el.offsetLeft,
        y: (gsap.getProperty(el, 'y') as number) - el.offsetTop,
        r: gsap.getProperty(el, 'rotation') as number,
        s: gsap.getProperty(el, 'scale') as number,
        o: gsap.getProperty(el, 'opacity') as number,
        base,
      });
    }
    if (flyers.length) {
      busy.current = true;
      const tl = gsap.timeline({
        onComplete: () => {
          flyers.forEach((f) => { f.el.style.zIndex = ''; });
          busy.current = false;
        },
      });
      flyers.forEach((f, k) => {
        f.el.style.zIndex = '0'; // above the pile, below settled cards: slabs slide out from behind
        const at = k * 0.07;
        tl.fromTo(f.el,
          { x: f.x, y: f.y, rotation: f.r, scale: f.s },
          { x: 0, y: 0, rotation: f.base, scale: 1, duration: 1.15, ease: STACK_EASE }, at);
        tl.fromTo(f.el, { opacity: f.o }, { opacity: 1, duration: 0.4, ease: 'power1.out' }, at);
        const sh = shadeOf(f.el);
        if (sh) tl.to(sh, { opacity: 0, duration: 0.9, ease: 'power2.out' }, at);
      });
    }

    // 3. The pile: nested, smaller, tilted, behind the pivot.
    if (shown > 0 && shown < total) {
      const pivot = els[shown - 1];
      const px = pivot.offsetLeft;
      const py = pivot.offsetTop;
      const pw = pivot.offsetWidth;
      const ph = pivot.offsetHeight;
      let step = 12;
      for (let i = shown; i < total; i++) {
        const el = els[i];
        const d = i - shown;
        const pose = stackPose(i, d, px, py, pw);
        step = pose.step;
        const sh = shadeOf(el);
        el.style.width = `${pw}px`;
        el.style.zIndex = String(-1 - Math.min(d, STACK_PEEK_LAYERS));
        if (animate) {
          gsap.to(el, { x: pose.x, y: pose.y, rotation: pose.rotation, scale: pose.scale, duration: 1.15, ease: 'power3.inOut' });
          gsap.to(el, { opacity: pose.opacity, duration: 0.5, ease: 'power1.out' });
          if (sh) gsap.to(sh, { opacity: pose.shade, duration: 0.9, ease: 'power2.out' });
        } else {
          gsap.set(el, { x: pose.x, y: pose.y, rotation: pose.rotation, scale: pose.scale, opacity: pose.opacity });
          if (sh) gsap.set(sh, { opacity: pose.shade });
        }
      }
      // 4. Unstack control, under the pivot.
      if (ctrl) {
        const cy = py + ph + step * STACK_PEEK_LAYERS + 36;
        ctrl.style.width = `${pw}px`;
        if (animate) {
          gsap.fromTo(ctrl, { x: px, y: cy + 16, opacity: 0 }, { x: px, y: cy, opacity: 1, duration: 0.8, delay: 0.75, ease: 'power3.out' });
        } else {
          gsap.set(ctrl, { x: px, y: cy, opacity: armed ? 1 : 0 });
        }
      }
    } else if (ctrl) {
      gsap.set(ctrl, { opacity: 0 });
    }

    if (!flyers.length) busy.current = false;

    // Filter change: a short settle-in for the cards now showing.
    if (lastKey.current !== filterKey) {
      lastKey.current = filterKey;
      if (!reduce && shown > 0) {
        gsap.fromTo(els.slice(0, shown), { opacity: 0, y: 24 }, { opacity: 1, y: 0, duration: 0.8, stagger: 0.05, ease: 'power3.out' });
      }
    }
  }, [revealed, filtered, filterKey, viewMode, armed, layoutTick, cols]);

  // First reveal: when the first slab is fully in view, fan out the first batch.
  useEffect(() => {
    if (viewMode !== 'grid' || armed || filtered.length < 2) return;
    const trigger = cardRefs.current[0];
    if (!trigger) return;
    const st = ScrollTrigger.create({
      trigger,
      start: 'bottom bottom-=32',
      end: 'max',
      onEnter: () => unstack(),
    });
    return () => st.kill();
  }, [viewMode, armed, filterKey, filtered.length, unstack]);

  // Grid <-> pit swap (and filtering) changes the document height by thousands
  // of px. Every ScrollTrigger on the page (HowItWorks step reveals, line
  // draw, footer parallax) measured its start/end against the old layout —
  // without a re-measure the HowItWorks steps keep their fromTo initial state
  // (opacity 0) and the section renders as a giant empty gap under its header.
  useEffect(() => {
    let raf2 = 0;
    const raf1 = requestAnimationFrame(() => {
      raf2 = requestAnimationFrame(() => ScrollTrigger.refresh());
    });
    // Fallback for the async dynamic-import chunk (pit mounts late)
    const fallback = setTimeout(() => ScrollTrigger.refresh(), 400);
    // Unstacking changes the grid height; re-measure once the flight has landed.
    const landed = setTimeout(() => ScrollTrigger.refresh(), 1700);
    return () => {
      cancelAnimationFrame(raf1);
      cancelAnimationFrame(raf2);
      clearTimeout(fallback);
      clearTimeout(landed);
    };
  }, [viewMode, filtered.length, pitCards.length, revealed]);

  // Physics drag handlers for grid mode (fake physics)
  const handleDragStart = (e: React.DragEvent, index: number) => {
    setIsDragging(true);
    sounds.foil();
    const target = e.currentTarget as HTMLElement;
    const rect = target.getBoundingClientRect();
    const offsetX = e.clientX - rect.left;
    const offsetY = e.clientY - rect.top;
    
    // Store offset
    target.dataset.offsetX = offsetX.toString();
    target.dataset.offsetY = offsetY.toString();
    
    // Ghost image
    const ghost = target.cloneNode(true) as HTMLElement;
    ghost.style.position = 'absolute';
    ghost.style.top = '-1000px';
    ghost.style.transform = 'rotate(5deg) scale(1.1)';
    ghost.style.opacity = '0.8';
    document.body.appendChild(ghost);
    e.dataTransfer.setDragImage(ghost, offsetX, offsetY);
    setTimeout(() => ghost.remove(), 0);
  };

  const handleDragEnd = (e: React.DragEvent) => {
    setIsDragging(false);
    const target = e.currentTarget as HTMLElement;
    // Toss effect
    gsap.fromTo(target,
      { rotation: Math.random() * 20 - 10, scale: 1.1, z: 50 },
      { rotation: (parseInt(target.dataset.index || '0') % 3 - 1) * 2, scale: 1, z: 0, duration: 0.8, ease: 'elastic.out(1, 0.6)' }
    );
    sounds.slabClack();
  };

  return (
    <section id="gallery" className="relative py-24 md:py-32 px-6 md:px-12 xl:px-24 bg-[#080808]">
      <div className="max-w-[1600px] mx-auto mb-16">
        <div className="flex flex-wrap items-end justify-between gap-8">
          <div>
            <div className="flex items-center gap-3 mb-6">
              <span className="font-mono text-[10px] tracking-[0.3em] text-[#FF4D00]">02 / GALLERY • THE VAULT</span>
              <div className="w-12 h-[1px] bg-[#FF4D00]" />
              <span className="font-mono text-[9px] px-2 py-0.5 bg-[#FF4D00] text-white animate-pulse">RAPIER • LIVE</span>
            </div>
            <h2 className="font-display font-black leading-[0.85] tracking-tighter uppercase" style={{ fontSize: 'var(--fs-h2)' }}>
              The<br />
              <span className="font-light italic lowercase">Card Shop</span> Archive
            </h2>
          </div>
          <div className="max-w-[360px]">
            <p className="font-body text-[14px] leading-relaxed text-[#F5F3EF]/60">
              Every slab tells a story. Walk the hall, drag one off its mount and toss it. Filter by collection or finish. Each one was a JPEG once. Now it's a grail.
            </p>
            <div className="mt-4 flex items-center gap-3">
              <div className="font-mono text-[10px] text-[#F5F3EF]/30 tabular">
                {filtered.length} SLABS • {galleryData.filter(c => c.type === '1/1').length} 1/1 • {galleryData.filter(c => c.type === 'batch').length} BATCH
              </div>
              <div className="flex gap-1 ml-auto">
                <button
                  onClick={() => setViewMode('grid')}
                  onMouseEnter={() => setCursor(true, 'GRID')}
                  onMouseLeave={() => setCursor(false)}
                  className={`px-3 py-1 font-mono text-[10px] tracking-widest border transition-colors ${viewMode === 'grid' ? 'bg-[#F5F3EF] text-black border-[#F5F3EF]' : 'bg-[#1A1A1A] text-[#F5F3EF]/50 border-[#2A2A2A]'}`}
                >
                  GRID
                </button>
                <button
                  onClick={() => { setViewMode('pit'); sounds.success(); }}
                  onMouseEnter={() => setCursor(true, 'VAULT')}
                  onMouseLeave={() => setCursor(false)}
                  className={`px-3 py-1 font-mono text-[10px] tracking-widest border transition-colors ${viewMode === 'pit' ? 'bg-[#FF4D00] text-white border-[#FF4D00]' : 'bg-[#1A1A1A] text-[#F5F3EF]/50 border-[#2A2A2A]'}`}
                >
                  THE VAULT
                </button>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-12 flex flex-wrap gap-2 border-y border-[#1A1A1A] py-4">
          <div className="flex items-center gap-2 mr-6">
            <span className="font-mono text-[10px] tracking-widest text-[#F5F3EF]/40">FILTER:</span>
            <div className="flex gap-1">
              {[
                { id: 'all', label: 'All' },
                { id: 'collection', label: 'Collection' },
                { id: 'style', label: 'Finish' },
              ].map(f => (
                <button
                  key={f.id}
                  onClick={() => setFilterType(f.id as any)}
                  onMouseEnter={() => setCursor(true, 'FILTER')}
                  onMouseLeave={() => setCursor(false)}
                  className={`px-3 py-1 font-mono text-[10px] tracking-widest uppercase border transition-colors ${filterType === f.id ? 'bg-[#F5F3EF] text-black border-[#F5F3EF]' : 'bg-transparent text-[#F5F3EF]/50 border-[#2A2A2A] hover:text-[#F5F3EF] hover:border-[#F5F3EF]/20'}`}
                >
                  {f.label}
                </button>
              ))}
            </div>
          </div>

          {filterType === 'collection' && (
            <div className="flex flex-wrap gap-1">
              {collections.map(c => (
                <button
                  key={c}
                  onClick={() => setSelectedCollection(c)}
                  onMouseEnter={() => setCursor(true, 'FILTER')}
                  onMouseLeave={() => setCursor(false)}
                  className={`px-3 py-1 font-mono text-[10px] tracking-widest uppercase border transition-colors ${selectedCollection === c ? 'bg-[#FF4D00] text-white border-[#FF4D00]' : 'bg-[#1A1A1A] text-[#F5F3EF]/60 border-[#2A2A2A] hover:text-[#F5F3EF]'}`}
                >
                  {c}
                </button>
              ))}
            </div>
          )}

          {filterType === 'style' && (
            <div className="flex flex-wrap gap-1">
              {styles.map(s => (
                <button
                  key={s}
                  onClick={() => setSelectedStyle(s)}
                  onMouseEnter={() => setCursor(true, 'FILTER')}
                  onMouseLeave={() => setCursor(false)}
                  className={`px-3 py-1 font-mono text-[10px] tracking-widest uppercase border transition-colors ${selectedStyle === s ? 'bg-[#FF4D00] text-white border-[#FF4D00]' : 'bg-[#1A1A1A] text-[#F5F3EF]/60 border-[#2A2A2A] hover:text-[#F5F3EF]'}`}
                >
                  {s}
                </button>
              ))}
            </div>
          )}

          {(selectedCollection !== 'all' || selectedStyle !== 'all') && (
            <button
              onClick={() => { setSelectedCollection('all'); setSelectedStyle('all'); }}
              onMouseEnter={() => setCursor(true, 'CLEAR')}
              onMouseLeave={() => setCursor(false)}
              className="ml-auto font-mono text-[10px] tracking-widest text-[#FF4D00] hover:text-white transition-colors"
            >
              CLEAR ×
            </button>
          )}
        </div>
      </div>

      <div className="max-w-[1600px] mx-auto">
        {viewMode === 'pit' ? (
          <div className="space-y-6">
            <div className="p-4 bg-[#FF4D00]/10 border border-[#FF4D00]/20 flex flex-wrap items-center justify-between gap-4">
              <div className="font-mono text-[11px] leading-relaxed">
                <span className="text-[#FF4D00] font-bold">VAULT HALL ACTIVE • RAPIER 3D</span><br/>
                <span className="text-[#F5F3EF]/60">Scroll or swipe to fly through the field • Drag a slab (hold, on touch) and toss it • It has mass, friction, restitution and drifts back to its place</span>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  role="switch"
                  aria-checked={zeroG}
                  aria-label="Toggle zero gravity"
                  onClick={() => setZeroG((z) => !z)}
                  className="flex items-center gap-2 font-mono text-[9px] px-2 py-1 min-h-[32px] md:min-h-0 bg-[#1A1A1A] border border-[#2A2A2A] hover:border-[#FF4D00]/60 transition-colors cursor-pointer"
                >
                  <span className="text-[#F5F3EF]/60">ZERO-G</span>
                  <span className={`relative inline-block w-7 h-3.5 rounded-full transition-colors ${zeroG ? 'bg-[#FF4D00]' : 'bg-[#2A2A2A]'}`}>
                    <span className={`absolute top-0.5 left-0.5 w-2.5 h-2.5 rounded-full bg-white transition-transform ${zeroG ? 'translate-x-3.5' : ''}`} />
                  </span>
                  <span className={zeroG ? 'text-[#FF4D00]' : 'text-[#F5F3EF]/40'}>{zeroG ? 'ON' : 'OFF'}</span>
                </button>
                <span className="font-mono text-[9px] px-2 py-1 bg-[#1A1A1A] border border-[#2A2A2A]">GRAVITY: {zeroG ? '0' : '-2.6'}</span>
                <span className="font-mono text-[9px] px-2 py-1 bg-[#1A1A1A] border border-[#2A2A2A]">MASS: 0.62</span>
                <span className="font-mono text-[9px] px-2 py-1 bg-[#FF4D00] text-white">60FPS</span>
              </div>
            </div>
            <GalleryPitPhysics cards={pitCards} zeroG={zeroG} />
          </div>
        ) : (
          <div
            ref={gridRef}
            className={`relative isolate grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 md:gap-8 ${isDragging ? 'cursor-grabbing' : ''}`}
            style={{
              paddingBottom: filtered.length - revealed > 0 ? CONTROL_SPACE : 0,
              transition: 'padding-bottom 0.9s cubic-bezier(0.76, 0, 0.24, 1)',
            }}
          >
            {filtered.map((card, index) => {
              const isRevealed = index < revealed;
              return (
              <div
                key={card.id}
                ref={(el) => { cardRefs.current[index] = el; }}
                data-index={index}
                draggable={isRevealed}
                inert={!isRevealed}
                aria-hidden={!isRevealed}
                onDragStart={(e) => handleDragStart(e, index)}
                onDragEnd={handleDragEnd}
                className={`gstack-card group select-none ${isRevealed ? 'relative z-[1]' : 'gstack-card--stacked'}`}
                onMouseEnter={() => setCursor(true, 'TOSS')}
                onMouseLeave={() => setCursor(false)}
              >
                <SlabFrame label={`${card.collection} • ${card.year}`} foil interactive>
                  <div className="aspect-[3/4] relative overflow-hidden bg-[#0a0a0a]">
                    <img
                      src={index < revealed + batch ? card.image : undefined}
                      alt={card.name}
                      className="w-full h-full object-cover transition-transform duration-[1.2s] group-hover:scale-110"
                      loading="lazy"
                      draggable={false}
                    />
                    <div className="absolute top-3 left-3 flex gap-1">
                      <span className={`font-mono text-[9px] px-2 py-1 font-bold tracking-widest uppercase
                        ${card.style === 'holo' ? 'bg-[#00E5FF] text-black' : ''}
                        ${card.style === 'cracked-ice' ? 'bg-white text-black' : ''}
                        ${card.style === 'star' ? 'bg-[#FFD700] text-black' : ''}
                        ${card.style === 'sparkle' ? 'bg-[#FF8A3D] text-black' : ''}
                        ${card.style === 'base' ? 'bg-[#F5F3EF] text-black' : ''}
                      `}>
                        {card.style}
                      </span>
                      <span className="font-mono text-[9px] px-2 py-1 bg-black/80 text-white/70 border border-white/10">
                        {card.type}
                      </span>
                    </div>

                    <div className="absolute top-3 right-3 font-mono text-[10px] px-2 py-1 bg-[#FF4D00] text-white font-bold">
                      {card.price}
                    </div>

                    <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent opacity-60 group-hover:opacity-90 transition-opacity" />

                    <div className="absolute bottom-0 left-0 right-0 p-4 translate-y-2 group-hover:translate-y-0 transition-transform duration-500">
                      <h3 className="font-bold text-[14px] leading-tight text-white">{card.name}</h3>
                      <p className="font-mono text-[10px] text-white/60 mt-1">{card.collection} • {card.id}</p>
                      
                      {card.quote && (
                        <div className="mt-3 pt-3 border-t border-white/10">
                          <p className="font-body text-[12px] leading-snug italic text-white/80">"{card.quote}"</p>
                          <p className="font-mono text-[9px] text-[#FF4D00] mt-1">— {card.commissioner}</p>
                        </div>
                      )}

                      <div className="mt-4 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-500 delay-100">
                        <MagneticButton variant="light" size="sm" cursorLabel="FORGE" className="flex-1" onClick={() => {
                          document.getElementById('forge')?.scrollIntoView({ behavior: 'smooth' });
                          sounds.success();
                        }}>
                          Get One Like This
                        </MagneticButton>
                      </div>
                    </div>

                    {/* Drag handle */}
                    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-8 h-8 bg-black/60 border border-white/20 rounded-full grid place-items-center opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                      <span className="font-mono text-[10px]">↔</span>
                    </div>
                  </div>
                </SlabFrame>

                <div className="gstack-shade" aria-hidden="true" />

                <div className="gstack-badge absolute -top-2 -right-2 w-6 h-6 bg-[#080808] border border-[#2A2A2A] grid place-items-center font-mono text-[9px] text-[#F5F3EF]/40 group-hover:text-[#FF4D00] group-hover:border-[#FF4D00]/50 transition-colors">
                  {card.id}
                </div>
              </div>
              );
            })}

            {/* Unstack control: sits under the last revealed slab, in front of the pile */}
            <div
              ref={ctrlRef}
              role="group"
              aria-label="Gallery stack"
              inert={!(armed && filtered.length - revealed > 0)}
              className="gstack-ctrl"
            >
              <div className="flex items-baseline justify-between font-mono text-[10px] tracking-widest text-[#F5F3EF]/40 tabular">
                <span aria-live="polite">{Math.min(revealed, filtered.length)} / {filtered.length} SLABS</span>
                <span>{Math.max(0, filtered.length - revealed)} STACKED</span>
              </div>
              <div className="relative mt-3 h-px bg-[#2A2A2A] overflow-hidden">
                <div
                  className="absolute inset-0 bg-[#FF4D00] origin-left transition-transform duration-[1100ms] ease-[cubic-bezier(0.76,0,0.24,1)]"
                  style={{ transform: `scaleX(${filtered.length ? Math.min(revealed, filtered.length) / filtered.length : 0})` }}
                />
              </div>
              <MagneticButton
                variant="light"
                size="md"
                cursorLabel="UNSTACK"
                className="mt-4 w-full"
                onClick={() => { unstack(); sounds.slabClack(); }}
              >
                {filtered.length - revealed <= batch ? `Unstack last ${Math.max(0, filtered.length - revealed)}` : `Unstack next ${batch}`}
              </MagneticButton>
            </div>
          </div>
        )}

        {filtered.length === 0 && (
          <div className="py-24 text-center">
            <div className="font-mono text-[12px] tracking-widest text-[#F5F3EF]/30">NO SLABS MATCH • TRY CLEARING FILTERS</div>
          </div>
        )}
      </div>

      <div className="max-w-[1600px] mx-auto mt-24 border border-[#1A1A1A] p-8 md:p-12 flex flex-wrap items-center justify-between gap-8 bg-[#0a0a0a] group hover:border-[#FF4D00]/20 transition-colors">
        <div>
          <div className="font-mono text-[10px] tracking-[0.3em] text-[#FF4D00] mb-2">WANT YOURS IN THE VAULT?</div>
          <div className="font-display font-black text-[32px] md:text-[40px] leading-none tracking-tighter uppercase group-hover:translate-x-1 transition-transform">Your JPEG<br/>Deserves Better</div>
        </div>
        <MagneticButton size="lg" variant="orange" cursorLabel="FORGE" onClick={() => document.getElementById('forge')?.scrollIntoView({ behavior: 'smooth' })}>
          Start Forging — $25
        </MagneticButton>
      </div>
    </section>
  );
}
