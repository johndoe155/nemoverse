#!/usr/bin/env python3
"""Checks the footer-mascot frame set: 8 frames x 2 tiers, one canvas, one export profile, 01 registered to 02 on the eye line.
Usage: python3 scripts/mascot/verify_frames.py   (needs numpy, scipy, opencv-python, pillow). Exits 1 on any failure."""
import re, sys, pathlib
import numpy as np, cv2
from PIL import Image
from scipy import ndimage as ndi
root = pathlib.Path(__file__).resolve().parents[2]
D = root / 'public/mascot/frames'
ids = re.findall(r"'(\d\d)'", re.search(r"FRAME_IDS = \[(.*?)\]", (root/'src/lib/mascotScrub.ts').read_text()).group(1))
SIZES = {1280: (1280, 1130), 800: (800, 706)}
fails = []
def check(ok, msg):
    print(('PASS ' if ok else 'FAIL ') + msg); ok or fails.append(msg)
check(ids == [f'{i:02d}' for i in range(1, 9)], f'FRAME_IDS = {ids}')
load = lambda i, t: np.array(Image.open(D/f'nemo-{i}-{t}.webp').convert('RGBA'))
def qidx(path):  # VP8 y_ac_qi from the bitstream header
    d = path.read_bytes(); i = d.index(b'VP8 ') + 8 + 10; v = (d[i] << 8) | d[i+1]; p = i + 2; r = 255; bits = 0
    def rb():
        nonlocal v, r, bits, p
        sp = 1 + (((r-1)*128) >> 8); big = sp << 8
        if v >= big: b = 1; r -= sp; v -= big
        else: b = 0; r = sp
        while r < 128:
            r <<= 1; v <<= 1; bits += 1
            if bits == 8: bits = 0; v |= d[p] if p < len(d) else 0; p += 1
        return b
    lit = lambda n: sum(rb() << (n-1-k) for k in range(n))
    rb(); rb()
    if rb():
        um = rb(); ud = rb()
        if ud:
            rb()
            for _ in range(4):
                if rb(): lit(7); rb()
            for _ in range(4):
                if rb(): lit(6); rb()
        if um:
            for _ in range(3):
                if rb(): lit(8)
    rb(); lit(6); lit(3)
    if rb() and rb():
        for _ in range(8):
            if rb(): lit(6); rb()
    lit(2); return lit(7)
for t, (w, h) in SIZES.items():
    for i in ids:
        f = D/f'nemo-{i}-{t}.webp'
        check(f.exists() and Image.open(f).size == (w, h), f'{f.name} is {w}x{h}')
        check(qidx(f) == 21 and b'ALPH' in f.read_bytes()[:64], f'{f.name} export profile (VP8 q-index 21, alpha plane)')
def eyes(a):
    lum = a[..., :3].astype(float).mean(2); lab, n = ndi.label((lum < 45) & (a[..., 3] > 200)); out = []
    s = a.shape[1] / 1280
    for k in range(1, n+1):
        m = ndi.binary_fill_holes(lab == k)
        if 2500*s*s < m.sum() < 12000*s*s:
            ys, xs = np.nonzero(m)
            if ys.mean() < 0.5*a.shape[0]: out.append((xs.mean(), ys.mean(), xs.min(), xs.max(), ys.min(), ys.max()))
    return sorted(out)
for t, (w, h) in SIZES.items():
    a, b = load('01', t), load('02', t); s = w/1280
    ea, eb = eyes(a), eyes(b)
    ra, rb_ = ea[-1], eb[-1]; la, lb = ea[0], eb[0]
    check(max(abs(np.array(ra[2:]) - np.array(rb_[2:]))) <= 1, f'[{t}] right-eye bbox 01 vs 02 within 1px: {[int(x) for x in ra[2:]]} / {[int(x) for x in rb_[2:]]}')
    check(abs(la[5]-lb[5]) <= 1 and abs(la[3]-lb[3]) <= 1, f'[{t}] left-eye lower edge / outer edge within 1px')
    y0, y1, x0, x1 = [int(v*s) for v in (560, 1050, 300, 1100)]
    win = np.zeros((h, w), np.float32); win[y0:y1, x0:x1] = 1
    g = lambda z: cv2.cvtColor(z[..., :3], cv2.COLOR_RGB2GRAY).astype(np.float32)*win
    (sx, sy), _ = cv2.phaseCorrelate(g(a), g(b), win)
    check(abs(sx) < 0.25 and abs(sy) < 0.25, f'[{t}] face/hoodie phase shift ({sx:+.3f}, {sy:+.3f}) px < 0.25')
    m = (a[..., 3] > 250) & (b[..., 3] > 250); m[:y0] = 0; m[y1:] = 0
    check(np.abs(a[..., 3].astype(int)-b[..., 3].astype(int))[int(520*s):].max() < 128, f'[{t}] silhouette below the eyes matches')
print('\nALL CHECKS PASSED' if not fails else f'\n{len(fails)} CHECK(S) FAILED'); sys.exit(1 if fails else 0)
